# vc4infer-dev

Headers and build-system files for the VideoCore IV engine.

```c
#include <vc4infer.h>

vc4_ctx *ctx;
if (vc4_init(&ctx, NULL, 0) != VC4_OK) { ... }
```

- `pkg-config --cflags --libs vc4infer`
- CMake: `find_package(vc4infer 1.2 REQUIRED)` then link `vc4infer::vc4infer`

The engine runs unprivileged through `/run/vc4d.sock` when
`VC4INFER_DAEMON=1` is set (the vc4-toolkit `/etc/profile.d/vc4.sh` does that);
otherwise it needs root and `/dev/mem`.  Every float operation runs on the
QPUs; unsupported ops return `VC4_ERR_UNSUPPORTED` and there is no CPU
fallback.
