# vc4inferConfig.cmake - CMake package for the VideoCore IV engine.
#
#   find_package(vc4infer 1.2 REQUIRED)
#   target_link_libraries(myapp PRIVATE vc4infer::vc4infer)
#
# The engine needs libm and pthread at link time; both are attached to the
# imported target so a caller does not have to know.

get_filename_component(_vc4_prefix "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

set(VC4INFER_VERSION "1.2.2")
set(VC4INFER_INCLUDE_DIR "${_vc4_prefix}/include")
set(VC4INFER_LIBRARY "${_vc4_prefix}/lib/aarch64-linux-gnu/libvc4infer.so")

if(NOT EXISTS "${VC4INFER_LIBRARY}" AND NOT EXISTS "${VC4INFER_LIBRARY}.1")
  message(FATAL_ERROR "vc4infer: ${VC4INFER_LIBRARY} is missing (install the vc4infer package)")
endif()

if(NOT TARGET vc4infer::vc4infer)
  add_library(vc4infer::vc4infer SHARED IMPORTED)
  set_target_properties(vc4infer::vc4infer PROPERTIES
    IMPORTED_LOCATION "${VC4INFER_LIBRARY}"
    INTERFACE_INCLUDE_DIRECTORIES "${VC4INFER_INCLUDE_DIR}"
    INTERFACE_LINK_LIBRARIES "m")
endif()

set(vc4infer_FOUND TRUE)
