"""The optimiser pass pipeline.

Every pass is a graph-to-graph rewrite with a switch.  The default for every
pass is **off**: a pass ships only after its operator sweep and end-to-end
parity have been measured on the board (docs/OPTIMIZER.md, "Correctness
gates").  Enable them by name:

    VC4_OPT=canonicalise           one pass
    VC4_OPT=all                    every pass in pipeline order
    VC4_OPT=all,-epilogue          all but one (a bisection)
    VC4_OPT=canonicalise,ew        explicit list

Pass names are the :attr:`Pass.key` values.  ``optimise(model, passes=...)``
takes the same grammar and overrides the environment, which is what the tests
and ``infer/tools/plan_diff.py`` use.

What a fused node records
-------------------------
Some rewrites replace several nodes with one *dispatch* while leaving the ONNX
graph valid and semantically exact for any other reader (a fused activation, a
fused SiLU pair).  Those mark the surviving node and its partner instead of
deleting a node whose output is still referenced:

    Mul     rule=silu       replaces=[/model.0/act/Sigmoid]  input=<x>
    Sigmoid rule=fused      into=<Mul name>                  (skipped at run)

Rewrites that remove nodes outright (constant folding, identity elimination,
bias folding, dead-node removal) simply delete them; the surviving node carries
the provenance.  ``Graph.summary()["fused"]`` counts marked dispatches, and the
plan printer reports node count, dispatch count and the op histogram.

Pass 1: canonicalise
    constant-fold      fold a node whose inputs are all plan-time constants
                       (including ConstantOfShape used as a weight source)
    dead-node          drop nodes whose outputs nothing reads
    identity           remove no-op Reshape/Cast/Transpose/Identity/...
    div-const          Div(x, k) -> Mul(x, 1/k), the executor's own lowering
    sub-const          Sub(x, k) -> Add(x, -k), likewise
Pass 2: ew
    silu               Mul(x, Sigmoid(x))            -> one SiLU launch
    hardswish          Mul(x, HardSigmoid(x))        -> one HardSwish launch
    affine             Add(Mul(x, a), b)             -> one AFFINE launch
Pass 3: epilogue
    conv-bias          Conv + Add(per-channel constant) -> Conv bias
    conv-activation    Conv/MatMul + Relu / Clip[0,6] / silu -> the GEMM's
                       store
Pass 4: layout
    layout             choose NHWC or NCHW for every tensor and record the map
                       on the model doc_string.  A tensor stays in the packed
                       NHWC form across elementwise/unary/gather ops, and a
                       conversion is charged only where an op has to read the
                       other form.  A 1-channel NHWC tensor has NCHW byte order
                       (pitch == W), so the pass chooses the form its consumers
                       need instead of paying a conversion for it.
"""
from __future__ import annotations

import math
import os

import numpy as np
import onnx
from onnx import TensorProto

from .ir import Graph

# Ops whose value this module can compute on the host from constants alone.
# Deliberately excludes Div, Exp, Sigmoid and the transcendentals: the device
# evaluates those with its own kernels (a Newton reciprocal, a 2^f polynomial)
# and a numpy fold would move the last bits for no gain.  Add/Sub/Mul/Neg/Abs
# are exact IEEE fp32 in both places.
FOLD_OPS = frozenset((
    "Shape", "Size", "Constant", "ConstantOfShape", "Identity", "Cast",
    "Reshape", "Flatten", "Squeeze", "Unsqueeze", "Transpose", "Concat",
    "Gather", "Slice", "Add", "Sub", "Mul", "Neg", "Abs",
))
MAX_FOLD_BYTES = 32 << 20

# The nodes the plan-time fold owns.  They produce a tensor from constants
# alone, so they are weight sources rather than runtime work, and the executor
# has no dispatch for ConstantOfShape: a graph that keeps one is refused in
# strict mode.  The runner passes its client arena as the budget, because a
# weight tensor larger than the arena cannot run however it is represented;
# the module defaults apply to callers with no arena (tests, offline probes).
PLAN_FOLD_OPS = frozenset(("ConstantOfShape",))
PLAN_FOLD_BYTES = 64 << 20


# ----------------------------------------------------------------- records
class RuleStat:
    """What one rule did, for the plan printer and the pass log."""

    __slots__ = ("rule", "matched", "removed", "added", "notes")

    def __init__(self, rule):
        self.rule = rule
        self.matched = 0
        self.removed = []
        self.added = []
        self.notes = []

    def __repr__(self):
        return "<%s matched=%d removed=%d added=%d>" % (
            self.rule, self.matched, len(self.removed), len(self.added))

    def as_dict(self):
        return {"rule": self.rule, "matched": self.matched,
                "removed": list(self.removed), "added": list(self.added),
                "notes": list(self.notes)}


class PassResult:
    """A pass's before/after plans and its per-rule records."""

    __slots__ = ("key", "title", "before", "after", "rules", "error")

    def __init__(self, key, title, before, after, rules, error=None):
        self.key = key
        self.title = title
        self.before = before
        self.after = after
        self.rules = rules
        self.error = error

    @property
    def changed(self):
        return self.before != self.after


class OptimiseResult:
    """The optimised model plus the plan of every pass that ran."""

    __slots__ = ("model", "graph", "results", "enabled")

    def __init__(self, model, graph, results, enabled):
        self.model = model
        self.graph = graph
        self.results = results
        self.enabled = enabled

    @property
    def changed(self):
        return any(r.changed for r in self.results)


# -------------------------------------------------------------------- pass
class Pass:
    key = ""
    title = ""
    default = False

    def run(self, graph, ctx=None):
        raise NotImplementedError


class _Ctx:
    """Small shared helpers for the rules."""

    def __init__(self, graph):
        self.graph = graph
        self.kept_outputs = graph.graph_outputs()

    def consumers(self):
        return self.graph.consumers()

    def producers(self):
        return self.graph.producers()

    def single_consumer(self, name):
        c = self.graph.consumers().get(name, [])
        return c[0] if len(c) == 1 else None

    def detach(self, node):
        """Remove a node and rewire its consumers to its first input."""
        src = node.proto.input[0]
        dst = node.proto.output[0]
        if dst in self.kept_outputs and src in self.kept_outputs:
            return False                 # two outputs cannot share one name
        self.graph.remove(node)
        if dst in self.kept_outputs:
            for vi in self.graph.outputs:
                if vi.name == dst:
                    vi.name = src
            for other in self.graph.nodes:
                for i, nm in enumerate(other.proto.input):
                    if nm == dst:
                        other.proto.input[i] = src
            return True
        self.graph.rename_uses(dst, src)
        return True


def fold_plan_constants(model, budget=PLAN_FOLD_BYTES,
                        limit=MAX_FOLD_BYTES):
    """Materialise constant metadata nodes before the plan is built.

    A ``ConstantOfShape`` whose shape input is a plan-time constant computes a
    tensor: it is a weight source, not a per-run activation.  Strict mode has
    no dispatch for the node, and the arena has to count the bytes it carries
    like any other initialiser, so the fold runs at load time and rewrites the
    node into an initialiser.  The value is the node's own ``value`` attribute,
    so the replacement is exact.

    The shape tensors that only fed those nodes are dropped, and a graph input
    that existed only to declare an initialiser goes with them: the ONNX test
    corpus is IR v3, where every initialiser must also be a graph input, and
    the runner admits fp32 inputs only.

    A constant fill larger than ``limit`` (one tensor) or ``budget`` (all of
    them) raises :class:`UnsupportedNode` with the tensor's shape, its byte
    count and the limit it missed.  The runner passes its client arena for
    both: weights that do not fit the arena cannot run in it, and the fold
    would copy them twice on a 1 GiB board.

    Returns ``(model, folded_node_names)``.  The input model object is
    returned unchanged when there is nothing to fold.
    """
    from .._errors import UnsupportedNode

    if not any(n.op_type in PLAN_FOLD_OPS for n in model.graph.node):
        return model, []
    graph = Graph.from_model(model)
    declared = set(graph.initializers)
    refused = []
    # An initialiser may be a graph output, so a constant fill that *is* the
    # output folds too; the value is in the initialiser table either way.
    st = _fold_constants(graph, ops=PLAN_FOLD_OPS, budget=budget,
                         limit=limit, refused=refused, keep_outputs=False)
    if refused:
        name, shape, nbytes, why = refused[0]
        raise UnsupportedNode(
            name, "ConstantOfShape",
            "constant fill %s needs %d bytes (%.1f MiB) of weights, %s"
            % ("x".join(str(d) for d in shape), nbytes, nbytes / 2.0 ** 20,
               why))
    if not st.matched:
        return model, []
    graph.drop_unused_initializers()
    used = {o.name for o in graph.outputs}
    for n in graph.nodes:
        used.update(i for i in n.proto.input if i)
    graph.inputs = [vi for vi in graph.inputs
                    if vi.name not in declared or vi.name in used]
    graph.meta["ir_version"] = max(int(graph.meta.get("ir_version") or 0), 4)
    graph.reindex()
    graph.refresh()
    return graph.to_model(), list(st.removed)


# --------------------------------------------------------------- canonical
class Canonicalise(Pass):
    key = "canonicalise"
    title = "constant folding, dead nodes, identity elimination"

    def run(self, graph, ctx=None):
        out = []
        out.append(_fold_constants(graph))
        out.append(_dead_nodes(graph))
        out.append(_identities(graph))
        out.append(_div_const(graph))
        out.append(_sub_const(graph))
        out.append(_dead_nodes(graph))
        graph.drop_unused_initializers()
        graph.reindex()
        graph.refresh()
        return out


def _fold_constants(graph, ops=FOLD_OPS, budget=MAX_FOLD_BYTES,
                    limit=MAX_FOLD_BYTES, refused=None, keep_outputs=True):
    st = RuleStat("constant-fold")
    before = len(graph.nodes)
    folded = {}
    start_budget = budget
    keep = []

    def refuse(node, shape, nbytes):
        """Record why a constant could not be folded, without materialising it."""
        if refused is None:
            return
        if nbytes > limit:
            why = ("over the %.1f MiB single-tensor limit"
                   % (limit / 2.0 ** 20))
        else:
            why = ("over the %.1f MiB plan-time fold budget "
                   "(%.1f MiB of weights folded before it)"
                   % (start_budget / 2.0 ** 20,
                      (start_budget - budget) / 2.0 ** 20))
        refused.append((node.name, list(shape), int(nbytes), why))
    for node in graph.nodes:
        op = node.op_type
        outs = [o for o in node.proto.output if o]
        if (op not in ops or not outs or len(outs) != 1 or
                any(a.type in (onnx.AttributeProto.GRAPH,
                               onnx.AttributeProto.GRAPHS)
                    for a in node.proto.attribute) or
                (keep_outputs and outs[0] in graph.graph_outputs()) or
                op == "Constant"):
            keep.append(node)
            continue
        ins = [i for i in node.proto.input if i]
        ok = bool(ins)
        for name in ins:
            if name not in folded and name not in graph.initializers and \
                    not graph.is_const(name):
                ok = False
                break
        if not ok:
            keep.append(node)
            continue
        # A constant fill's size follows from its shape input, so a tensor
        # that is over the budget is refused before it is allocated.  VGG-19's
        # 25088x4096 fill is 392 MiB: allocating it only to discard it is what
        # made the probe swap on a 1 GiB board.
        if op in PLAN_FOLD_OPS and node.proto.input and \
                graph.is_const(node.proto.input[0]):
            dims = [int(v) for v in
                    np.asarray(graph.const(node.proto.input[0])).ravel()]
            if dims and all(d >= 0 for d in dims):
                val = node.attr("value")
                itemsize = (np.asarray(val).dtype.itemsize
                            if val is not None else 4)
                nbytes = int(np.prod(dims)) * itemsize
                if nbytes > limit or nbytes > budget:
                    refuse(node, dims, nbytes)
                    keep.append(node)
                    continue
        arr = graph.eval_const(node, {**graph.initializers, **folded})
        if arr is None or arr.dtype == object:
            keep.append(node)
            continue
        if arr.dtype == np.float64:
            arr = arr.astype(np.float32)
        if arr.nbytes > limit or arr.nbytes > budget:
            refuse(node, arr.shape, arr.nbytes)
            keep.append(node)
            continue
        budget -= arr.nbytes
        name = outs[0]
        folded[name] = arr
        graph.initializers[name] = arr
        st.matched += 1
        st.removed.append(node.name)
    graph.nodes = keep
    st.notes.append("%d -> %d nodes" % (before, len(graph.nodes)))
    graph.reindex()
    graph.refresh()
    return st


def _dead_nodes(graph):
    st = RuleStat("dead-node")
    gouts = graph.graph_outputs()
    changed = True
    while changed:
        changed = False
        used = set(gouts)
        for node in graph.nodes:
            used.update(i for i in node.proto.input if i)
        keep = []
        for node in graph.nodes:
            outs = [o for o in node.proto.output if o]
            if outs and not any(o in used for o in outs):
                st.removed.append(node.name)
                st.matched += 1
                changed = True
                continue
            keep.append(node)
        graph.nodes = keep
    if st.matched:
        graph.reindex()
        graph.refresh()
    return st


def _identities(graph):
    st = RuleStat("identity")
    for node in list(graph.nodes):
        op = node.op_type
        outs = [o for o in node.proto.output if o]
        ins = [i for i in node.proto.input if i]
        if len(outs) != 1 or not ins:
            continue
        keep = None
        if op == "Identity":
            keep = True
        elif op == "Dropout":
            tm = node.attr("training_mode", 0)
            if not tm:
                keep = True
        elif op == "Cast":
            to = int(node.attr("to", TensorProto.FLOAT))
            keep = graph.dtype(ins[0]) == to
        elif op in ("Reshape", "Flatten", "Squeeze", "Unsqueeze"):
            a, b = graph.shape(ins[0]), graph.shape(outs[0])
            if a and b and a == b:
                keep = True
        elif op == "Transpose":
            perm = node.attr("perm")
            rank = len(graph.shape(ins[0]) or [])
            keep = (perm is None and rank <= 1) or (perm == list(range(rank)))
        elif op == "Pad":
            pads = node.attr("pads")
            keep = bool(pads) and all(int(v) == 0 for v in pads)
        elif op == "Concat" and len(ins) == 1:
            keep = True
        if not keep:
            continue
        before = len(graph.nodes)
        _Ctx(graph).detach(node)
        if len(graph.nodes) != before:
            st.matched += 1
            st.removed.append(node.name)
    if st.matched:
        graph.reindex()
        graph.refresh()
    return st


def _new_scalar(graph, base, value, dtype=np.float32):
    name = base
    i = 0
    while name in graph.value_names():
        i += 1
        name = "%s_%d" % (base, i)
    arr = np.asarray(value, dtype).reshape(())
    graph.initializers[name] = arr
    return name


def _const_scalar(graph, name):
    v = graph.const(name)
    if v is None:
        return None
    a = np.asarray(v)
    if a.size != 1:
        return None
    return np.float32(a.ravel()[0])


def _div_const(graph):
    """Div(x, k) -> Mul(x, 1/k); the executor already dispatches it that way."""
    st = RuleStat("div-const")
    for node in list(graph.nodes):
        if node.op_type != "Div" or len(node.proto.input) != 2:
            continue
        x, k = node.proto.input
        c = _const_scalar(graph, k)
        if c is None or graph.is_const(x):
            continue
        if graph.dtype(x) not in (TensorProto.FLOAT, TensorProto.DOUBLE):
            continue        # integer Div is a floor/truncate, not a multiply
        val = float(c)
        if val == 0.0 or not math.isfinite(val):
            continue
        recip = _new_scalar(graph, (node.raw_name or "div") + "/recip",
                            1.0 / val)
        node.proto.op_type = "Mul"
        node.proto.input[1] = recip
        st.matched += 1
        st.notes.append("%s: 1/%g" % (node.name, val))
    if st.matched:
        graph.refresh()
    return st


def _sub_const(graph):
    """Sub(x, k) -> Add(x, -k): the executor's _addconst path, one launch."""
    st = RuleStat("sub-const")
    for node in list(graph.nodes):
        if node.op_type != "Sub" or len(node.proto.input) != 2:
            continue
        x, k = node.proto.input
        c = graph.const(k)
        if c is None or graph.is_const(x):
            continue
        neg = np.negative(np.asarray(c, np.float32))
        name = (node.raw_name or "sub") + "/neg"
        i = 0
        while name in graph.value_names():
            i += 1
            name = "%s/neg_%d" % (node.raw_name or "sub", i)
        graph.initializers[name] = np.ascontiguousarray(neg)
        node.proto.op_type = "Add"
        node.proto.input[1] = name
        st.matched += 1
        st.notes.append(node.name)
    if st.matched:
        graph.refresh()
    return st


# -------------------------------------------------------------- elementwise
class ElementwiseFusion(Pass):
    key = "ew"
    title = "elementwise chains into one launch"

    def run(self, graph, ctx=None):
        out = [_fuse_silu(graph), _fuse_hardswish(graph), _fuse_affine(graph)]
        # anything that became dead after a pair fusion
        out.append(_dead_nodes(graph))
        graph.reindex()
        graph.refresh()
        return out


def _mark_skip(graph, node, target, rule):
    node.mark("fused", into=target, rule=rule)


def _fuse_silu(graph):
    st = RuleStat("silu")
    gouts = graph.graph_outputs()
    producers = graph.producers()
    consumers = graph.consumers()
    for node in list(graph.nodes):
        if node.op_type != "Mul" or len(node.proto.input) != 2 or node.fused:
            continue
        a, b = node.proto.input
        for cand, x in ((a, b), (b, a)):
            prod = producers.get(cand)
            if prod is None or prod.op_type != "Sigmoid":
                continue
            if len(prod.proto.input) != 1 or prod.proto.input[0] != x:
                continue
            if cand in gouts or len(consumers.get(cand, [])) != 1:
                continue
            node.mark("silu", replaces=[prod.name], input=x)
            prod.mark("fused", into=node.name, by="silu")
            st.matched += 1
            st.notes.append("%s <- %s" % (node.name, prod.name))
            break
    return st


def _fuse_hardswish(graph):
    st = RuleStat("hardswish")
    gouts = graph.graph_outputs()
    producers = graph.producers()
    consumers = graph.consumers()
    for node in list(graph.nodes):
        if node.op_type != "Mul" or len(node.proto.input) != 2 or node.fused:
            continue
        a, b = node.proto.input
        for cand, x in ((a, b), (b, a)):
            prod = producers.get(cand)
            if prod is None or prod.op_type != "HardSigmoid":
                continue
            if len(prod.proto.input) != 1 or prod.proto.input[0] != x:
                continue
            if cand in gouts or len(consumers.get(cand, [])) != 1:
                continue
            alpha = float(prod.attr("alpha", 0.2))
            beta = float(prod.attr("beta", 0.5))
            # AttributeProto stores float32, so compare with a tolerance: the
            # UOP_HARDSWISH body is the 0.2/0.5 form and nothing else.
            if abs(alpha - 0.2) > 1e-6 or abs(beta - 0.5) > 1e-6:
                continue
            node.mark("hardswish", replaces=[prod.name], input=x)
            prod.mark("fused", into=node.name, by="hardswish")
            st.matched += 1
            st.notes.append("%s <- %s" % (node.name, prod.name))
            break
    return st


def _fuse_affine(graph):
    """Add(Mul(x, a), b) -> one AFFINE launch when a and b are scalars.

    Only this order: (x*a) + b maps to out = x*a + b exactly.  The reversed
    order (x + b)*a would need b*a folded on the host first, which changes one
    rounding, so it is left to the executor's two launches until there is a
    measured reason to take it.
    """
    st = RuleStat("affine")
    gouts = graph.graph_outputs()
    producers = graph.producers()
    consumers = graph.consumers()
    for node in list(graph.nodes):
        if node.op_type != "Add" or len(node.proto.input) != 2 or node.fused:
            continue
        a, b = node.proto.input
        for mul_name, bias_name in ((a, b), (b, a)):
            prod = producers.get(mul_name)
            if prod is None or prod.op_type != "Mul" or prod.fused:
                continue
            if len(prod.proto.input) != 2:
                continue
            alpha = beta = None
            x = None
            c1, c2 = prod.proto.input
            s1, s2 = _const_scalar(graph, c1), _const_scalar(graph, c2)
            bias = _const_scalar(graph, bias_name)
            if bias is None:
                continue
            if s1 is not None:
                alpha, x = s1, c2
            elif s2 is not None:
                alpha, x = s2, c1
            if alpha is None or graph.is_const(x):
                continue
            if mul_name in gouts or len(consumers.get(mul_name, [])) != 1:
                continue
            if not graph.shape(x) or graph.shape(x) != graph.shape(node.outputs[0]):
                continue
            beta = bias
            node.mark("affine", replaces=[prod.name], input=x,
                      alpha=float(alpha), beta=float(beta))
            prod.mark("fused", into=node.name, by="affine")
            st.matched += 1
            st.notes.append("%s <- %s (a=%g b=%g)"
                            % (node.name, prod.name, alpha, beta))
            break
    return st


# ---------------------------------------------------------------- epilogue
class Epilogue(Pass):
    key = "epilogue"
    title = "bias and activation folded into the producing conv"

    def run(self, graph, ctx=None):
        out = [_fold_conv_bias(graph), _fuse_conv_activation(graph)]
        out.append(_dead_nodes(graph))
        graph.reindex()
        graph.refresh()
        return out


def _conv_bias_ok(graph, node):
    """The executor's NHWC conv takes a [Cout] bias; check the geometry."""
    x = graph.shape(node.proto.input[0])
    w = graph.shape(node.proto.input[1])
    if not x or not w or len(x) != 4 or len(w) != 4:
        return False
    if any(d <= 0 for d in x[:2] + w[:2]):
        return False
    ks = node.attr("kernel_shape") or [w[2], w[3]]
    st = node.attr("strides") or [1, 1]
    pd = node.attr("pads") or [0, 0, 0, 0]
    dl = node.attr("dilations") or [1, 1]
    group = int(node.attr("group", 1))
    cin, cout = int(w[1]) * group, int(w[0])
    if ks[0] != ks[1] or ks[0] not in (1, 3, 5):
        return False
    if st[0] != st[1] or st[0] not in (1, 2):
        return False
    if len(set(int(p) for p in pd)) != 1:
        return False
    if dl[0] != dl[1] or not 1 <= int(dl[0]) <= 8:
        return False
    if group != 1:
        return False
    if cin % 16 or cout % 16:
        return False
    if st[0] * cin * 4 > 8191:
        return False
    return True


def _per_channel(value, cout):
    a = np.asarray(value, np.float32)
    if a.size == 1:
        return np.full(cout, float(a.ravel()[0]), np.float32)
    if a.size != cout:
        return None
    return np.ascontiguousarray(a.ravel().astype(np.float32))


def _fold_conv_bias(graph):
    """Conv [+ bias] followed by Add(per-channel constant) -> Conv bias."""
    st = RuleStat("conv-bias")
    gouts = graph.graph_outputs()
    producers = graph.producers()
    consumers = graph.consumers()
    for node in list(graph.nodes):
        if node.op_type != "Conv" or not node.proto.output:
            continue
        out = node.proto.output[0]
        if out in gouts or len(consumers.get(out, [])) != 1:
            continue
        add = consumers[out][0]
        if add.op_type != "Add" or len(add.proto.input) != 2:
            continue
        if add.proto.output[0] in gouts and \
                len(consumers.get(add.proto.output[0], [])) != 0:
            pass
        a, b = add.proto.input
        const = b if graph.is_const(b) else a if graph.is_const(a) else None
        if const is None:
            continue
        shp = graph.shape(out)
        if not shp or len(shp) != 4:
            continue
        cout = int(shp[1])
        cval = graph.const(const)
        if cval is None:
            continue
        bias = _per_channel(cval, cout)
        if bias is None:
            continue
        if not _conv_bias_ok(graph, node):
            st.notes.append("%s: NHWC geometry refused" % node.name)
            continue
        if len(node.proto.input) > 2 and node.proto.input[2]:
            old = graph.const(node.proto.input[2])
            if old is None:
                continue
            old = np.asarray(old, np.float32).ravel()
            if old.size != cout:
                continue
            bias = (old + bias).astype(np.float32)
        name = (node.raw_name or "conv") + "/bias"
        i = 0
        while name in graph.value_names():
            i += 1
            name = "%s/bias_%d" % (node.raw_name or "conv", i)
        graph.initializers[name] = bias
        old_bias = node.proto.input[2] if len(node.proto.input) > 2 else ""
        node.set_inputs([node.proto.input[0], node.proto.input[1], name])
        node.mark("conv-bias", replaces=[add.name, old_bias] if old_bias
                  else [add.name], bias=name)
        graph.remove(add)
        graph.rename_uses(add.proto.output[0], out)
        st.matched += 1
        st.removed.append(add.name)
        st.notes.append("%s: %d-channel bias folded" % (node.name, cout))
    if st.matched:
        graph.reindex()
        graph.refresh()
    return st


def _clip_rule(graph, act):
    """`relu6` for Clip(0, 6), else None."""
    lo = act.attr("min", None)
    hi = act.attr("max", None)
    # opset 11+ carries them as optional inputs instead of attributes
    if lo is None and len(act.proto.input) > 1 and act.proto.input[1]:
        c = graph.const(act.proto.input[1])
        if c is not None and np.asarray(c).size == 1:
            lo = float(np.asarray(c).ravel()[0])
    if hi is None and len(act.proto.input) > 2 and act.proto.input[2]:
        c = graph.const(act.proto.input[2])
        if c is not None and np.asarray(c).size == 1:
            hi = float(np.asarray(c).ravel()[0])
    return "relu6" if lo in (0.0, 0) and hi in (6.0, 6) else None


def _fuse_conv_activation(graph):
    """Conv/MatMul -> Relu | Clip(0,6) | SiLU becomes one launch.

    The GEMM applies the activation to the value it stores, so the second
    pass over the output disappears.  Only the pairs the kernel can take are
    marked (`plan.epilogue_ok` is the same predicate the launch model uses):
    the NHWC conv folds all three, a MatMul relu and clip(0,6) (the asm10
    tile has one free B register, not twelve), a Gemm none.  A pair outside
    that set is left alone rather than marked for a launch that would not
    happen.

    SiLU arrives here already collapsed: the `ew` pass has replaced
    `Mul(x, Sigmoid(x))` with one node whose `silu` record names x, so the
    pattern is Conv -> Mul-with-a-silu-record.  The Sigmoid it absorbed is
    still a graph node marked `fused` (it is what keeps the graph readable),
    which is why the consumer count filters fused nodes out.
    """
    from .plan import epilogue_ok
    st = RuleStat("conv-activation")
    gouts = graph.graph_outputs()
    consumers = graph.consumers()
    for node in list(graph.nodes):
        if node.op_type not in ("Conv", "Gemm", "MatMul") or not node.proto.output:
            continue
        out = node.proto.output[0]
        if out in gouts:
            continue
        # a consumer is gone only if it carries the `fused` rule: `Node.fused`
        # is the whole provenance record, and a SiLU Mul has one
        live = [c for c in consumers.get(out, []) if not c.rule("fused")]
        if len(live) != 1:
            continue
        act = live[0]
        rule = None
        if act.op_type == "Relu":
            rule = "relu"
        elif act.op_type == "Clip":
            rule = _clip_rule(graph, act)
        elif act.op_type == "Mul":
            silu = act.rule("silu")
            if silu and silu.get("input") == out:
                rule = "silu"
        # `act.fused` is truthy for any node with a provenance record, and a
        # SiLU Mul has one (`silu`), so test the fused *rule*: only a node
        # already absorbed by another node must be skipped here.
        if rule is None or act.rule("fused"):
            continue
        if not epilogue_ok(graph, node, rule):
            st.notes.append("%s <- %s (%s): the kernel cannot fold it here"
                            % (node.name, act.name, rule))
            continue
        node.mark("activation", replaces=[act.name], act=rule)
        act.mark("fused", into=node.name, by="activation")
        st.matched += 1
        st.notes.append("%s <- %s (%s)" % (node.name, act.name, rule))
    return st


# ------------------------------------------------------------------ layout
# Ops the executor runs from a compact NCHW buffer: an NHWC operand is moved
# there by ``_to_nchw_buf`` before the op runs.  These are the sites a layout
# choice can remove.  Cast, Div, Gather, GatherElements, GatherND and Softmax
# are in the family tables (``_dispatch_extra``/``_dispatch_norm``) and all
# enter through ``_Base.ten``, which converts to NCHW, so they belong here even
# though their ONNX semantics are elementwise.
_LAYOUT_NCHW = frozenset((
    "Reshape", "Flatten", "Squeeze", "Unsqueeze", "Transpose", "MatMul",
    "Gemm", "GlobalAveragePool", "Softmax", "Cast", "Div", "Gather",
    "GatherElements", "GatherND",
))

# Ops the main table runs in place: they touch every element or move whole
# rows and keep the operand's layout and pitch.  Split, Slice and Resize are
# layout-preserving too but are handled with their own rule because their
# output inherits the input's layout.
_LAYOUT_NEUTRAL = frozenset((
    "Abs", "Neg", "Sign", "Clip", "LeakyRelu", "HardSigmoid", "HardSwish",
    "Sigmoid", "Tanh", "Exp", "Log", "Sqrt", "Reciprocal", "Erf", "Sin",
    "Cos", "Floor", "Ceil", "Round", "Softplus", "Softsign", "Elu", "Selu",
    "Gelu", "Mish", "Silu", "Add", "Sub", "Mul", "Identity", "Dropout",
    "Split", "Slice", "Resize",
))


def _maxpool_nhwc(node):
    """True when the executor takes the NHWC ring kernel for this pool."""
    ks = node.attr("kernel_shape")
    st = node.attr("strides") or [1, 1]
    pd = node.attr("pads") or [0, 0, 0, 0]
    if not ks or len(ks) < 2 or int(ks[0]) != int(ks[1]):
        return False
    n = int(ks[0])
    return (int(st[0]) == 1 and n in (3, 5) and
            [int(p) for p in pd] == [(n - 1) // 2] * 4)


def _conv_layout(node, graph, align16, conv_nhwc):
    """The output layout a conv delivers, including the trimmed-Cout pitch."""
    ins = [i for i in node.proto.input if i]
    x = graph.shape(ins[0]) if ins else None
    w = graph.shape(ins[1]) if len(ins) > 1 else None
    if not conv_nhwc(node, x, w, int(node.attr("group", 1))):
        return ("nchw", 0)
    ks = node.attr("kernel_shape") or [w[2], w[3]]
    st = node.attr("strides") or [1, 1]
    pd = node.attr("pads") or [0, 0, 0, 0]
    dl = node.attr("dilations") or [1, 1]
    wo = (int(x[3]) + int(pd[1]) + int(pd[3]) -
          int(dl[1]) * (int(ks[1]) - 1) - 1) // int(st[1]) + 1
    # The NHWC gemm writes Cout padded to 16 and the caller trims the real
    # channels back with _slice_ch, which compacts the pitch to wo.
    return ("nhwc", int(wo) if int(w[0]) % 16 else align16(wo))


def _layout_equiv(layout, shape):
    """True when NHWC storage of `shape` is byte-identical to NCHW."""
    return (layout[0] == "nhwc" and shape and len(shape) == 4 and
            int(shape[1]) == 1 and int(shape[3]) > 0 and
            int(layout[1]) == int(shape[3]))


def _layout_nchw_needed(graph):
    """Tensors whose value a later op (or the graph output) reads as NCHW.

    Seeds are the inputs of every NCHW-only op and every graph output; the
    need propagates backwards through layout-neutral ops, so a chain
    conv -> Relu -> Reshape marks the conv output as well as the Relu's.
    It stops at ops that can absorb NHWC (conv, pool, resize, concat): those
    convert at their own use site, which the pass charges.
    """
    need = set(graph.graph_outputs())
    changed = True
    while changed:
        changed = False
        for node in graph.nodes:
            op = node.op_type
            outs = [o for o in node.proto.output if o]
            if not outs:
                continue
            if op in _LAYOUT_NCHW:
                force = True
            elif op in _LAYOUT_NEUTRAL:
                force = any(o in need for o in outs)
            else:
                force = False
            if not force:
                continue
            for i in node.proto.input:
                if i and i not in graph.initializers and i not in need:
                    need.add(i)
                    changed = True
    return need


def _layout_input_need(node, k, lay, graph):
    """The form this node reads input `k` in, or None when either will do."""
    from .plan import conv_nhwc
    op = node.op_type
    if op in _LAYOUT_NCHW:
        return "nchw"
    if op == "Conv":
        if k != 0:
            return None
        ins = [i for i in node.proto.input if i]
        x = graph.shape(ins[0]) if ins else None
        w = graph.shape(ins[1]) if len(ins) > 1 else None
        return "nhwc" if conv_nhwc(node, x, w,
                                   int(node.attr("group", 1))) else "nchw"
    if op == "MaxPool":
        return "nhwc" if _maxpool_nhwc(node) else "nchw"
    if op == "Concat":
        outs = [o for o in node.proto.output if o]
        return "nhwc" if outs and lay.get(outs[0], ("nchw", 0))[0] == "nhwc" \
            else "nchw"
    if op in ("Split", "Slice", "Resize"):
        return None
    if op in _LAYOUT_NEUTRAL:
        outs = [o for o in node.proto.output if o]
        return lay.get(outs[0], ("nchw", 0))[0] if outs else None
    return None


class LayoutAssignment(Pass):
    key = "layout"
    title = "packed NHWC between compatible nodes, conversions at boundaries"

    def run(self, graph, ctx=None):
        from .plan import (align16, conv_nhwc, set_layout_record,
                           to_nchw_calls, to_nhwc_calls)

        lay = {}
        for name in graph.initializers:
            lay[name] = ("nchw", 0)
        for vi in graph.inputs:
            lay[vi.name] = ("nchw", 0)     # the ONNX boundary is NCHW
        need = _layout_nchw_needed(graph)
        st = RuleStat("layout")
        cv = RuleStat("layout-convert")
        av = RuleStat("layout-avoid")

        # 1. one forward walk: choose the layout every node delivers.
        for node in graph.nodes:
            op = node.op_type
            ins = [i for i in node.proto.input if i]
            outs = [o for o in node.proto.output if o]
            cand = ("nchw", 0)
            if op == "Conv":
                cand = _conv_layout(node, graph, align16, conv_nhwc)
            elif op == "Concat":
                ls = [lay.get(i, ("nchw", 0)) for i in ins]
                shp = graph.shape(outs[0]) if outs else None
                if ls and all(v[0] == "nhwc" for v in ls) and \
                        shp and len(shp) == 4:
                    cand = ("nhwc", int(shp[3]))
            elif op in ("Split", "Slice", "Gather", "Resize",
                        "GatherElements", "GatherND"):
                cand = lay.get(ins[0], ("nchw", 0)) if ins else ("nchw", 0)
            elif op == "MaxPool":
                src = lay.get(ins[0], ("nchw", 0)) if ins else ("nchw", 0)
                cand = src if (src[0] == "nhwc" and _maxpool_nhwc(node)) \
                    else ("nchw", 0)
            elif op in _LAYOUT_NEUTRAL:
                for i in ins:
                    if i in graph.initializers:
                        continue
                    cand = lay.get(i, ("nchw", 0))
                    break
            for o in outs:
                choice = cand
                if _layout_equiv(choice, graph.shape(o)):
                    # same bytes either way: take the form the consumers read
                    if o in need:
                        choice = ("nchw", 0)
                        av.matched += 1
                        av.notes.append(
                            "%s: chosen nchw at the producer; %d copy2d_x "
                            "calls avoided (1-channel NHWC is NCHW byte "
                            "order)" % (o, to_nchw_calls(graph.shape(o),
                                                         cand)))
                lay[o] = choice

        # 2. charge a conversion only where a reader needs the other form.
        for node in graph.nodes:
            for k, name in enumerate(node.proto.input):
                if not name or name in graph.initializers:
                    continue
                want = _layout_input_need(node, k, lay, graph)
                if want is None:
                    continue
                got = lay.get(name, ("nchw", 0))
                if got[0] == want:
                    continue
                shp = graph.shape(name)
                if want == "nchw" and _layout_equiv(got, shp):
                    lay[name] = ("nchw", 0)
                    av.matched += 1
                    av.notes.append(
                        "%s <- %s: %d copy2d_x calls avoided (1-channel NHWC "
                        "is NCHW byte order)" %
                        (node.name, name, to_nchw_calls(shp, got)))
                    continue
                cv.matched += 1
                calls = (to_nchw_calls(shp, got) if want == "nchw"
                         else to_nhwc_calls(shp, got))
                cv.notes.append("%s <- %s: %s -> %s, %d calls" %
                                (node.name, name, got[0], want, calls))

        n_nhwc = sum(1 for v in lay.values() if v[0] == "nhwc")
        st.matched = len(lay) - len(graph.initializers)
        st.notes.append("%d tensors: %d nhwc, %d nchw; %d conversions kept, "
                        "%d avoided" % (st.matched, n_nhwc,
                                        st.matched - n_nhwc, cv.matched,
                                        av.matched))
        record = {name: ("%s/%d" % v if v[0] == "nhwc" else "nchw")
                  for name, v in lay.items() if name not in graph.initializers}
        set_layout_record(graph, record)
        graph.meta["layout"] = True
        return [st, cv, av]


# --------------------------------------------------------------- pipeline
PIPELINE = (Canonicalise(), ElementwiseFusion(), Epilogue(), LayoutAssignment())
PASSES = {p.key: p for p in PIPELINE}


def resolve_passes(spec=None):
    """Turn a pass spec into the ordered list to run.

    ``None`` reads ``$VC4_OPT`` (absent or empty = no passes, the default).
    ``"all"`` enables every pass; a ``-name`` entry disables one after it.
    Unknown names raise ``ValueError`` so a typo cannot silently plan nothing.
    """
    if spec is None:
        spec = os.environ.get("VC4_OPT", "")
    if isinstance(spec, (list, tuple)):
        items = [str(s) for s in spec]
    else:
        items = [s.strip() for s in str(spec).replace(";", ",").split(",")
                 if s.strip()]
    enabled = set()
    for item in items:
        name = item[1:] if item.startswith("-") else item
        if name in ("", "none"):
            continue
        if name == "all":
            if item.startswith("-"):
                enabled.clear()
            else:
                enabled.update(PASSES)
            continue
        if name not in PASSES:
            raise ValueError("unknown optimiser pass %r (have: %s)"
                             % (name, ", ".join(PASSES)))
        if item.startswith("-"):
            enabled.discard(name)
        else:
            enabled.add(name)
    return [p for p in PIPELINE if p.key in enabled]


def optimise(model, passes=None, on_pass=None):
    """Run the enabled passes over ``model`` and return an ``OptimiseResult``.

    ``on_pass(PassResult, graph)`` is called after each pass, which is how the
    plan printer shows before/after for every rewrite; ``graph`` is the live
    IR, valid only for the duration of the call (copy it to keep it).  With no
    pass enabled the input model is returned unchanged (no copy, no inference).
    """
    enabled = resolve_passes(passes)
    if not enabled:
        graph = Graph.from_model(model, copy_model=False)
        return OptimiseResult(model, graph, [], [])
    graph = Graph.from_model(model)
    results = []
    for p in enabled:
        before = graph.summary()
        err = None
        try:
            rules = p.run(graph)
        except Exception as e:                       # noqa: BLE001
            err = e
            rules = []
        after = graph.summary()
        res = PassResult(p.key, p.title, before, after, rules, err)
        results.append(res)
        if on_pass is not None:
            on_pass(res, graph)
        if err is not None:
            raise err
    return OptimiseResult(graph.to_model(), graph, results, enabled)
