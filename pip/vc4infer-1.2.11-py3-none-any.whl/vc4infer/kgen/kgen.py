#!/usr/bin/env python3
"""kgen - QPU kernel generator for libvc4infer.

The GEMM body is the hand-written, element-verified asm3 kernel (16x16 C tile,
packed fmul+fadd, hardware rotate+replicate broadcast, both TMUs 2-deep,
39-word k loop, VPM->DMA store).  This file reuses the asm3 encoder
(qenc.py) and the proven VPM control words (vpmwords.py) unchanged, and only
generalises the *addressing* from square N x N to arbitrary M x N x K, plus two
new kernels: im2col-panel and elementwise.

No instruction encoding is invented here; every sequence is either taken
verbatim from asm3 (gemm2.py / pack.py / gen.py store path) or is a mechanical
register/stride substitution on one of those sequences.

KERNEL ABI (uniforms read in order u0..; 64 B block per QPU = 16 words)

  gemm   u0 panel bus
         u1 C bus
         u2 B bus
         u3 A row-block byte offset   (rb0 * 64*K)
         u4 A row-block byte stride   (nqpu * 64*K)
         u5 C row-block byte offset   (rb0 * 16*N*4)
         u6 C row-block byte stride   (nqpu * 16*N*4)
         u7 row blocks for this QPU
         compile-time: M/16, N/16, K, nqpu, B mode
                       (0 = row-major KxN, 1 = k-major B panel)

  pack   u0 source row length (floats)   u1 source row-block byte offset
         u2 source base bus             u3 source row-block byte stride
         u4 destination base bus        u5 row blocks for this QPU
         u6 QPU index (VPM row 16*q)    u7 destination k-block byte stride
         u8 destination row-block stride u9 k blocks (K/16)

  im2col u0 padded-plane byte pitch      u1 source row-block byte offset
         u2 padded input base bus        u3 row-block byte stride
         u4 panel base bus               u5 row blocks for this QPU
         u6 QPU index                    u7 destination k-block stride (1024)
         u8 destination row-block stride u9 ci blocks (Cin/16)
         u9  Wp*4
         compile-time: Cin, K, KH, KW (taps unrolled)

  ew     u0 a bus, u1 b bus, u2 out bus, u3 groups for this QPU,
         u4 QPU index, u5 nqpu
         a group is 16 vectors = 256 floats = one verified VPM->DMA store
"""
import os
import struct
import sys

# Self-contained: the encoder modules (qenc.py, gen.py, vpmwords.py) sit next
# to this file in an installed tree (/usr/lib/vc4infer/kgen) and in the asm3
# working tree in the original development checkout.  ASM3_DIR still wins when
# set, for a developer comparing encoders.
_HERE = os.path.dirname(os.path.abspath(__file__))
ASM3 = os.path.join(os.environ.get("ASM3_DIR") or _HERE)
sys.path.insert(0, ASM3)

import qenc
from qenc import *                                   # noqa: F401,F403
from qenc import _ops, imm as _imm, W_VPM, W_VPW_SETUP, W_VPW_ADDR
from gen import Prog
import vpmwords as V

# One kernel blob is loaded into one V3D code slot (VC4_CODE_SLOT in
# infer/src/vc4_int.h, VC4D_MAX_PROG in vc4d/proto/vc4d_proto.h).  Checking
# here, where the kernel is generated, names the kernel and the limit during a
# build instead of a launch failing on a model.
CODE_SLOT_BYTES = 16384

MUL_V8MIN = 4

# Prog.emit takes either encoded words or the dict form used everywhere below
_orig_emit = Prog.emit


def _emit(self, *ws):
    for w in ws:
        _orig_emit(self, _ops(**w) if isinstance(w, dict) else w)


Prog.emit = _emit


def imm(v):
    """qenc small immediate.  Values 48..63 are the mul-ALU vector-rotate
    encodings and are legal here, so the range is not asserted.
    48 = rotate by r5 (dynamic), 49..63 = rotate 1..15; rotate 0 has no code
    (use the plain move) and 1.0f is code 32, not 48.  As constants the same
    codes alias -16..-1."""
    return _imm(v)


def imm_small(v):
    """Small immediate for the plain ALU fields: -16..15 only."""
    assert -16 <= v <= 15, "small immediate out of range: %d" % v
    return _imm(v)


def add_or(out, a, b, ws=0):
    return dict(add_op=ADD_OR, add_out=out, ws=ws, add_a=a, add_b=b)


def add_(op, out, a, b, ws=0, sf=0):
    return dict(add_op=op, add_out=out, ws=ws, add_a=a, add_b=b, sf=sf)


def mul_fmul(out_acc, a, b):
    return dict(mul_op=MUL_FMUL, mul_out=32 + out_acc, ws=0, mul_a=a, mul_b=b)


def mul_rot(out_acc, src_acc, n):
    """Canonical v8min 16-lane rotate (see qenc.rot_inst)."""
    return qenc.rot_inst(n, src=src_acc, out=out_acc)


def rep_all(src_acc):
    return add_or(37, acc(src_acc), acc(src_acc), ws=1)


def emit_slot(p, m, a, sig=SIG_NONE):
    if sig != SIG_NONE:
        for d, k in ((m, 'mul_b'), (a, 'add_b')):
            if d and d.get(k) is not None and d[k][0] == 8:
                raise AssertionError('TMU signal cannot share a word with a small immediate')
    kw = dict(sig=sig)
    if m:
        kw.update(m)
    else:
        kw.update(mul_op=MUL_NOP, mul_out=W_NOP)
    if a:
        kw.update(a)
    else:
        kw.update(add_op=ADD_NOP, add_out=W_NOP, cond_add=COND_NEVER)
    if not m:
        kw.setdefault('cond_mul', COND_NEVER)
    p.emit(_ops(**kw))


class Builder:
    """Emits words and checks the QPU's no-forwarding rule.

    The QPU does not forward: a read of a register written in one of the two
    preceding words still sees the old value.  asm3's verified prologues keep
    three words between a write and its first dependent read; this checker
    enforces that on every kernel here except the verified k loop, where the
    intra-word read of the previous product is intentional.
    """

    def __init__(self):
        self.p = Prog()
        self.check = True
        self.last_write = {}
        self.violations = []
        self.idx = 0
        self.nops = 0
        self.last_branch = -99

    @staticmethod
    def _rfile(desc):
        if not desc:
            return None
        mux, addr = desc
        if mux == 8:            # small immediate
            return None
        if mux == REGA:
            return ('A', addr)
        if mux == REGB:
            return ('B', addr)
        return ('ACC', addr)    # 0..5 = accumulators

    def _writes(self, w):
        out = []
        sig = (w >> 60) & 0xF
        if sig == SIG_LOAD_IMMEDIATE:
            reg = (w >> 38) & 0x3F
            ws = (w >> 44) & 1
            if reg < 32:
                out.append(('A' if ws == 0 else 'B', reg))
            elif reg < 38:
                out.append(('ACC', reg - 32))
            return out
        if sig in (SIG_ALU_IMMEDIATE, SIG_NONE, SIG_LOAD_TMU0, SIG_LOAD_TMU1,
                   SIG_LOAD_COLOR, SIG_LOAD_COVERAGE, SIG_WAIT_SCORE):
            ws = (w >> 44) & 1
            aw = (w >> 38) & 0x3F
            mw = (w >> 32) & 0x3F
            if (w >> 24) & 0x1F:                 # non-nop add
                if aw < 32:
                    out.append(('A' if ws == 0 else 'B', aw))
                elif aw < 38:
                    out.append(('ACC', aw - 32))
            if (w >> 29) & 7:                    # non-nop mul
                if mw < 32:
                    out.append(('B' if ws == 0 else 'A', mw))
                elif mw < 38:
                    out.append(('ACC', mw - 32))
        return out

    def _reads(self, w):
        """Registers read by this word.

        The mux, not the operand slot, selects the file: qenc puts any A-file
        operand in raddr_a and any B-file operand in raddr_b, so a B-slot (the
        mul_b field) can address the A file and vice versa.  A word with a
        small immediate has that immediate in raddr_b, not a B-file read.
        """
        out = []
        if (w >> 24) & 0x1F or (w >> 29) & 7:
            ra = (w >> 18) & 0x3F
            rb = (w >> 12) & 0x3F
            is_imm = ((w >> 60) & 0xF) == SIG_ALU_IMMEDIATE
            for mux in ((w >> 9) & 7, (w >> 6) & 7, (w >> 3) & 7, w & 7):
                if mux == REGA:
                    if ra != NOP_ADDR:
                        out.append(('A', ra))
                elif mux == REGB:
                    if rb != NOP_ADDR and not is_imm:
                        out.append(('B', rb))
                elif mux < 6:
                    out.append(('ACC', mux))
        return out

    def _bad(self, word):
        """Return the first (reg, distance) violation for this word, or None.

        QPU general registers have no forwarding: a read needs three words
        after the write.  Accumulators have a forwarding path and may be read
        in the following word (asm3's prog_alu relies on that).  A read in the
        same word that also writes the register still sees the *previous*
        value, so a write from an earlier word must still be checked.
        """
        for r in self._reads(word):
            lw = self.last_write.get(r)
            if lw is None or lw >= self.idx:
                continue
            need = 1 if r[0] == 'ACC' else 3
            if self.idx - lw < need:
                return (r, self.idx - lw)
        return None

    def e(self, *ws):
        for w in ws:
            word = _ops(**w) if isinstance(w, dict) else w
            if self.check:
                # pad with nops so a dependent read is never closer than three
                # words (the QPU has no forwarding).  Never inside a branch's
                # delay slots.
                if self.idx - self.last_branch > 3:
                    for _ in range(4):
                        if self._bad(word) is None:
                            break
                        self.p.emit(nop())
                        self.idx += 1
                        self.nops += 1
                bad = self._bad(word)
                if bad is not None:
                    self.violations.append((self.idx, bad[0], bad[1]))
            self.p.emit(word)
            if self.check:
                for r in self._writes(word):
                    self.last_write[r] = self.idx
            if ((word >> 60) & 0xF) == SIG_BRANCH:
                self.last_branch = self.idx
            self.idx += 1

    def report(self, name):
        """Residual violations after padding (should always be 0)."""
        for idx, r, d in self.violations:
            print("  UNPADDED %s word %d: read %s%d, %d word(s) after the write"
                  % (name, idx, r[0], r[1], d), file=sys.stderr)
        return len(self.violations)

    def read_uni(self, dst, ws=0, nops=2):
        """Read the next uniform word into dst; the uniform port auto-increments."""
        self.e(dict(add_op=ADD_OR, add_out=dst, ws=ws,
                    add_a=areg(R_UNIF), add_b=areg(R_UNIF)))
        for _ in range(nops):
            self.e(nop())


def add_rr(b, op, dst, a_reg, b_reg):
    """dst = a_reg op b_reg when both live in the A file (the ALU can address
    only one A-file and one B-file register per word).  acc3 is scratch: it is
    always written before it is read in every kernel here.

    The QPU has no forwarding: a read of a register written in the previous
    word still sees the old value, so two nops are inserted (asm3's prologues
    do the same)."""
    b.e(add_or(32 + 3, areg(a_reg), areg(a_reg)))
    b.e(nop(), nop())
    b.e(add_(op, dst, acc(3), areg(b_reg)))


# =============================================================== GEMM
A_PN, A_CB, A_BB = 16, 17, 18
A_TMP = 19
A_LANE = 20
A_ARB, A_RBCNT, A_CBCNT = 21, 22, 23
A_COLC = 24
A_VPMQ = 25
A_AADR, A_BADR, A_CADR = 26, 27, 28
A_CRB, A_BOFF, A_KCNT = 29, 30, 31
A_RBIDX = 16      # current row block index (u7; A_PN is dead after ARB)

B_BST, B_NEG1, B_ASTEP, B_VPMQ7 = 20, 21, 22, 23
B_CSTEP, B_CBSTEP, B_RBST_A, B_BLANE = 24, 25, 26, 27
B_ALANE, B_RBST_C, B_BOFFSTEP = 28, 29, 30
B_NEGTR, B_NQPU = 31, 19


def emit_kloop(p, depth=3):
    """The verified 39-word k loop (asm3 gemm2.py, variant 1 head).

    Every TMU pop keeps its own instruction word, never the word that writes a
    TMU address register: that shared word is the 12-QPU corruption
    root-caused in asm3/NOTES.md.  A[r][k] is broadcast with a mul-ALU vector
    rotate plus the hardware element-0 replicate port; the MAC is one packed
    fmul+fadd word.
    """
    head = [
        (None, None, SIG_LOAD_TMU0),
        (None, add_or(32, acc(4), acc(4)), SIG_NONE),
        (None, None, SIG_LOAD_TMU1),
        (None, add_or(W_TMU0_S, areg(A_AADR), areg(A_AADR), ws=1), SIG_NONE),
        (None, add_or(W_TMU1_S, areg(A_BADR), areg(A_BADR), ws=1), SIG_NONE),
    ]
    core = [(mul_rot(1, 0, 15), rep_all(0), SIG_NONE)]
    for m in range(16):
        nxt = rep_all(1) if m < 15 else None
        core.append((mul_fmul(2, acc(5), acc(4)), nxt, SIG_NONE))
        rot = mul_rot(1, 0, 14 - m) if m < 14 else None
        core.append((rot, add_(ADD_FADD, m, areg(m), acc(2)), SIG_NONE))
    core[31] = (core[31][0], add_(ADD_ADD, A_KCNT, (REGB, B_NEG1), areg(A_KCNT), sf=1),
                SIG_NONE)

    p.label('kloop')
    for m, a, s in head:
        emit_slot(p, m, a, s)
    for m, a, s in core[:31]:
        emit_slot(p, m, a, s)
    emit_slot(p, *core[31][:2])
    p.branch_to('kloop', cond=BR_ALL_Z_CLEAR)
    emit_slot(p, *core[32][:2])                                   # delay 1
    p.emit(add_(ADD_ADD, A_AADR, areg(A_AADR), (REGB, B_ASTEP)))  # delay 2
    p.emit(add_(ADD_ADD, A_BADR, areg(A_BADR), (REGB, B_BST)))    # delay 3
    for _ in range(depth):
        p.emit(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER))
    for _ in range(depth):
        p.emit(alu(sig=SIG_LOAD_TMU1, cond_add=COND_NEVER, cond_mul=COND_NEVER))
    p.emit(nop())


def emit_store16(p, stride_bytes, cstep_reg=B_CSTEP):
    """Verified VPM->DMA store: 4 chunks of 4 rows of C (asm3 gemm2.py).

    stride_bytes is the memory stride between consecutive 16-word rows; with
    0 the four rows of a chunk are contiguous (used by the elementwise kernel,
    where a group is 256 contiguous floats).
    """
    dma = (2 << 30) | (4 << 23) | (16 << 16) | (1 << 14)
    for c in range(4):
        p.emit(ldi(0x1A00, R5, ws=1))   # R5 is out-reg 37 (acc5); a literal 5
                                         # would write B-file r5 and the ALU
                                         # read of acc(5) below would be junk
        p.emit(_ops(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
                    add_a=acc(5), add_b=areg(A_VPMQ)))
        for r in range(4):
            p.emit(add_or(W_VPM, areg(4 * c + r), areg(4 * c + r)))
        p.emit(ldi(dma, R5, ws=1))
        p.emit(_ops(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
                    add_a=acc(5), add_b=(REGB, B_VPMQ7)))
        p.emit(ldi(0xC0010000 | (stride_bytes & 0xFFFF), W_VPW_SETUP, ws=1))
        p.emit(add_or(W_VPW_ADDR, areg(A_CADR), areg(A_CADR), ws=1))
        p.emit(_ops(add_op=ADD_OR, add_out=W_NOP,
                    add_a=(REGB, R_VPW_WAIT), add_b=(REGB, R_VPW_WAIT)))
        p.emit(nop(), nop(), nop(), nop())
        p.emit(add_(ADD_ADD, A_CADR, areg(A_CADR), (REGB, cstep_reg)))


def build_gemm(M, N, K, nqpu, bmode=0, depth=3, cstride=None, act=0):
    """asm3 16x16-tile GEMM: the conv path, with an optional activation
    epilogue applied to the C tile as it is stored (`act`, kops.ACT_*)."""
    TR, TC = M // 16, N // 16
    assert M % 16 == 0 and N % 16 == 0 and K % 16 == 0, "shapes must be 16-aligned"
    assert TR >= 1 and TC >= 1 and 1 <= nqpu <= 12
    # C row pitch in floats.  The default is N (a plain [M][N] result); a
    # grouped conv passes the full output channel count so each group's GEMM
    # can write its channel block straight into one [M][Cout] image.
    CS = N if cstride is None else cstride
    assert CS >= N and CS % 16 == 0, "C stride must be >= N and 16-aligned"
    stride = (CS - 16) * 4
    tr_neg = (0 - TR) & 0xFFFFFFFF
    b = Builder()
    p = b.p

    b.e(add_or(36, imm(1), imm(1)))                        # tmu_noswap
    b.read_uni(A_PN)                                       # u0 panel
    b.read_uni(A_CB)                                       # u1 C
    b.read_uni(A_BB)                                       # u2 B
    b.read_uni(A_TMP)                                      # u3 A rb offset
    add_rr(b, ADD_ADD, A_ARB, A_PN, A_TMP)
    b.e(nop(), nop())
    b.read_uni(A_TMP)                                      # u4 A rb stride
    b.e(add_or(B_RBST_A, ws=1, a=areg(A_TMP), b=areg(A_TMP)), nop())
    b.read_uni(A_TMP)                                      # u5 C rb offset
    add_rr(b, ADD_ADD, A_CRB, A_CB, A_TMP)
    b.e(nop(), nop())
    b.read_uni(A_TMP)                                      # u6 C rb stride
    b.e(add_or(B_RBST_C, ws=1, a=areg(A_TMP), b=areg(A_TMP)), nop())
    b.read_uni(A_RBIDX)                                    # u7 first row block

    b.e(add_or(A_COLC, areg(A_CRB), areg(A_CRB)), nop(), nop())
    b.e(add_or(A_LANE, areg(R_ELEM_NUM), areg(R_ELEM_NUM)), nop(), nop())
    b.e(add_or(A_VPMQ, breg(R_QPU_NUM), breg(R_QPU_NUM)), nop(), nop())
    b.e(add_(ADD_SHL, A_VPMQ, areg(A_VPMQ), imm(2)), nop(), nop())
    b.e(add_(ADD_SHL, B_ALANE, ws=1, a=areg(A_LANE), b=imm(2)))
    b.e(add_(ADD_SHL, B_BLANE, ws=1, a=areg(A_LANE), b=imm(2)))
    b.e(ldi(N * 4 if bmode == 0 else 64, B_BST, ws=1))
    b.e(ldi(4 * CS * 4, B_CSTEP, ws=1))
    b.e(ldi(64, B_CBSTEP, ws=1))
    b.e(ldi(64, B_ASTEP, ws=1))
    # column-block stride in B: 16 floats for row-major B, a whole k-major
    # panel block (K*16 floats) when B is the packed panel (bmode=1)
    b.e(ldi(64 if bmode == 0 else 64 * K, B_BOFFSTEP, ws=1))
    b.e(ldi(0xFFFFFFFF, B_NEG1, ws=1))
    p.emit(ldi(tr_neg, B_NEGTR, ws=1))
    b.e(ldi(nqpu, B_NQPU, ws=1))
    b.e(add_(ADD_SHL, B_VPMQ7, ws=1, a=areg(A_VPMQ), b=imm(7)))
    b.e(add_or(A_BOFF, imm(0), imm(0)))
    b.e(nop(), nop())

    # The epilogue's constants live in the B registers the GEMM's own state
    # does not use (B19..B31 are the loop's: stride, counters, VPM rows),
    # loaded once here rather than per tile.
    AEP = None
    if act:
        import kops
        AEP = kops.act_setup(sys.modules[__name__], b, act,
                             list(range(0, 19)), (26, 27))

    p._builder = b
    # upper bound on the row blocks this QPU can ever own (compile-time)
    p.emit(ldi((TR + nqpu - 1) // nqpu, A_RBCNT, ws=0))
    b.e(nop(), nop())
    p.label('rb_top')
    b.e(add_(ADD_ADD, A_TMP, (REGB, B_NEGTR), areg(A_RBIDX), sf=1), nop(), nop())
    p.branch_to('rb_body', cond=BR_ALL_N_SET)      # idx < TR  <=>  idx-TR < 0
    b.e(nop(), nop(), nop())
    p.branch_to('tdone', cond=BR_ALWAYS)
    b.e(nop(), nop(), nop())
    p.label('rb_body')
    b.e(add_or(A_COLC, areg(A_CRB), areg(A_CRB)), nop())
    # B's column byte offset is advanced through the column sweep; reset it for
    # every row block (it used to carry over from the previous row block, which
    # made every row block after the first read B at the wrong columns).
    b.e(add_or(A_BOFF, imm(0), imm(0)), nop())
    p.emit(ldi(TC, A_CBCNT, ws=0))
    b.e(nop())

    p.label('cb_top')
    b.e(add_(ADD_ADD, A_AADR, areg(A_ARB), (REGB, B_ALANE)), nop())
    b.e(add_(ADD_ADD, A_BADR, areg(A_BB), (REGB, B_BLANE)))
    add_rr(b, ADD_ADD, A_BADR, A_BADR, A_BOFF)
    b.e(nop())
    b.e(add_or(A_CADR, areg(A_COLC), areg(A_COLC)))
    for r in range(16):
        b.e(add_or(r, imm(0), imm(0)))
    b.e(nop(), nop())
    for _ in range(depth):                                  # prime both TMUs
        b.e(add_or(W_TMU0_S, areg(A_AADR), areg(A_AADR), ws=1))
        b.e(add_or(W_TMU1_S, areg(A_BADR), areg(A_BADR), ws=1))
        b.e(nop(), nop())
        b.e(add_(ADD_ADD, A_AADR, areg(A_AADR), (REGB, B_ASTEP)))
        b.e(add_(ADD_ADD, A_BADR, areg(A_BADR), (REGB, B_BST)))
        b.e(nop(), nop())
    p.emit(ldi(K, A_KCNT, ws=0))
    b.e(nop(), nop())
    b.check = False          # verified asm3 k loop: intra-word product read
    emit_kloop(p, depth)
    if act:
        # the epilogue is new scheduling, so the no-forwarding checker is
        # back on for it; the last writes it knows are the tile zeroing in
        # the column block's prologue, long before the k loop
        b.check = True
        kops.act_apply(b, AEP, list(range(16)))
    b.check = False
    emit_store16(p, stride)
    b.check = True           # (the store's ldi->acc5 pattern is asm3's)
    b.e(add_(ADD_ADD, A_COLC, areg(A_COLC), (REGB, B_CBSTEP)))
    b.e(add_(ADD_ADD, A_BOFF, areg(A_BOFF), (REGB, B_BOFFSTEP)))
    b.e(add_(ADD_ADD, A_CBCNT, (REGB, B_NEG1), areg(A_CBCNT), sf=1))
    p.branch_to('cb_top', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, A_ARB, areg(A_ARB), (REGB, B_RBST_A)))
    b.e(add_(ADD_ADD, A_CRB, areg(A_CRB), (REGB, B_RBST_C)))
    b.e(add_(ADD_ADD, A_RBIDX, areg(A_RBIDX), (REGB, B_NQPU)))
    b.e(add_(ADD_ADD, A_RBCNT, (REGB, B_NEG1), areg(A_RBCNT), sf=1))
    p.branch_to('rb_top', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    p.label('tdone')
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p



















# =============================================================== GEMM (asm10)
#
# The asm10 kernel (asm10/gemm6.py): 8 rows x 64 columns of C per tile, three B
# vector sets, a 6-phase (3 k pair) k loop, 12 QPUs.  Its record on this board
# is 13.745 GFLOP/s GEMM-only / 0 mismatches / 19-of-19 clean launches, and the
# instruction schedule below is *verbatim* from it (same SETV sets, same
# FORDER/BORDER issue rows, same POP/COPY words, same prime, same store).
# Only the addressing was generalised so the engine can use it for any M,N,K:
#
#   * a tile is one 8-row block x one 64-column block, iterated as a nested
#     (row block, column block) loop with a compile-time iteration bound plus
#     an in-loop `rb < TR` guard -- the same pattern as the old asm3 kernel, so
#     a corrupted register still cannot turn the tile loop into an unbounded
#     DMA march;
#   * the A and C row-block offsets and strides come from uniforms u3..u6,
#     so no geometry has to be a power of two (asm10 shifted a tile index);
#   * K/2 % 3 == 0 (K a multiple of 48 -- the conv shapes 144/288/576, and
#     K=48) gets a *drain* group: the last 3 k pairs are emitted after the loop
#     with the last two phases' B issues and the final A pop suppressed, so
#     every TMU pop has a matching issue and nothing is left in flight.
#     asm10 asserted K/2 % 3 != 0 and had no path for it;
#   * B is row-major (bmode=1, the im2col weight panel, is gone: the conv path
#     now transposes its weights on the ARM -- a byte copy, no arithmetic --
#     and every GEMM reads B row-major).
#
# KERNEL ABI (unchanged from the asm3 kernel)
#   u0 panel bus          u1 C bus            u2 B bus
#   u3 A row-block byte offset  u4 A row-block byte stride   (re-derived
#   u5 C row-block byte offset  u6 C row-block byte stride    from M/N/K)
#   u7 first row block this QPU owns
#
# A panel (pack10 layout): PANEL[(rb*K + k)*8 + r] = A[rb*8 + r][k]
# B row-major with row stride N*4; C row-major with row stride N*4.

G10_MUL_V8MIN = 4
G10_NROWS = 8
G10_NCOLS = 64

G10_RA_AADR, G10_RA_CADR, G10_RA_CADR2, G10_RA_KCNT = 20, 21, 22, 23
G10_RA_ARB, G10_RA_RBIDX, G10_RA_TMP, G10_RA_CBOFF = 24, 25, 26, 27
G10_RA_CTMP, G10_RA_CBCNT = 30, 31
G10_RB_BST, G10_RB_NEGTR, G10_RB_RBCNT, G10_RB_CARB = 20, 21, 22, 23
G10_RB_O64, G10_RB_O128, G10_RB_O192, G10_RB_BLANE = 24, 25, 26, 27
G10_RB_TMP, G10_RB_O256 = 30, 31

# Three B vector sets.  C(j0),C(j1) live in the A file, C(j2),C(j3) in the B
# file, so v(j2),v(j3) must be B-file and v(j1) A-file; v(j0) must be A-file
# because the B issues ride on the w1 word whose fmul reads v(j0) with raddr_a.
G10_SETV = (
    {0: (0, 16), 1: (0, 17), 2: (1, 16), 3: (1, 17)},
    {0: (0, 18), 1: (0, 19), 2: (1, 18), 3: (1, 19)},
    {0: (0, 28), 1: (0, 29), 2: (1, 28), 3: (1, 29)},
)   # (file, address); file 0 = A file, 1 = B file

G10_ACC_AVEC, G10_ACC_ROT, G10_ACC_TMP, G10_ACC_BADR = 0, 1, 2, 3
G10_ACC_TMU, G10_ACC_BCAST = 4, 5
G10_ACC_TMP2 = G10_ACC_TMP
G10_ACC_SCR = 3             # same register as BADR (bumped after its last use)

G10_FORDER = (0, 2, 1, 3)      # v(j0) is A-file: w1 can host a raddr_b add op
G10_BORDER = (2, 0, 3, 1)      # v(j2) is B-file: w1 can host a raddr_a add op
G10_ISSUE_ROW = {0: 0, 2: 1, 1: 2, 3: 3}     # w1 of which row carries the issue
G10_TMU_OF = {0: 0, 2: 1, 1: 0, 3: 1}
G10_POP_RW = {0: (1, 4), 2: (3, 4), 1: (5, 4), 3: (6, 4)}
G10_COPY_RW = {0: (1, 5, 'mul'), 2: (4, 1, 'add'), 1: (5, 5, 'mul'),
               3: (7, 1, 'add')}
G10_BUMP_RW = (5, 1)
G10_APOP_RW = (7, 4)


class G10Asm:
    """Word-list assembler with an explicit-schedule hazard checker.

    This is asm10/gemm6.py's Asm class: emit_phase/emit_boundary below put two
    instructions in one word and rely on a schedule that a generic nop-padder
    would destroy, so the schedule is written out and then *verified* (check()
    for per-word legality, verify() for the RAW/TMU rules) before the blob is
    written.
    """

    def __init__(self):
        self.w = []
        self.labels = {}

    def word(self, mul=None, add=None, sig=SIG_NONE, ws=0, note=''):
        self.w.append(dict(mul=mul, add=add, sig=sig, ws=ws, note=note))
        return len(self.w) - 1

    def nop(self, note=''):
        return self.word(note=note)

    def ldi(self, value, out_reg, ws=0, note=''):
        self.w.append(dict(ldi=(value, out_reg, ws), note=note))
        return len(self.w) - 1

    def label(self, name):
        self.labels[name] = len(self.w)

    def branch_to(self, name, cond=BR_ALWAYS, note=''):
        idx = len(self.w)
        self.w.append(dict(branch=cond, target=name, note=note))
        return idx

    def put(self, idx, slot, op, ws=None, sig=None):
        d = self.w[idx]
        if d.get(slot) is not None:
            raise AssertionError('word %d (%s): %s slot already used'
                                 % (idx, d['note'], slot))
        d[slot] = op
        if ws is not None:
            if d['ws'] != ws:
                raise AssertionError('word %d (%s): ws %d != %d'
                                     % (idx, d['note'], d['ws'], ws))
            d['ws'] = ws
        if sig is not None:
            d['sig'] = sig

    def pop(self, idx, tmu, note):
        d = self.w[idx]
        if d['sig'] != SIG_NONE:
            raise AssertionError('two pops in word %d' % idx)
        if d.get('add') is not None and d['add'].get('add_b') is not None \
                and d['add']['add_b'][0] == IMM:
            raise AssertionError('pop on small-immediate word %d' % idx)
        d['sig'] = SIG_LOAD_TMU1 if tmu else SIG_LOAD_TMU0
        d['note'] += ' POP ' + note

    def words(self):
        idx = {id(d): i for i, d in enumerate(self.w)}
        out = []
        for d in self.w:
            if 'ldi' in d:
                v, o, ws = d['ldi']
                out.append(ldi(v, o, ws=ws))
                continue
            if 'branch' in d:
                o = (self.labels[d['target']] - (idx[id(d)] + 4)) * 8
                out.append(branch(o, cond=d['branch']))
                continue
            kw = dict(sig=d['sig'], ws=d['ws'])
            if d['mul']:
                kw.update(d['mul'])
            else:
                kw.update(mul_op=MUL_NOP, mul_out=W_NOP, cond_mul=COND_NEVER)
            if d['add']:
                kw.update(d['add'])
            else:
                kw.update(add_op=ADD_NOP, add_out=W_NOP, cond_add=COND_NEVER)
            try:
                out.append(_ops(**kw))
            except ValueError as ex:
                raise ValueError('word %d (%s): %s | mul=%s add=%s'
                                 % (len(out), d['note'], ex, d['mul'], d['add']))
        return out

    # ---- static checks ----------------------------------------------------
    def check(self):
        for i, d in enumerate(self.w):
            if 'branch' in d or 'ldi' in d:
                continue
            ops = [o for o in (d['mul'], d['add']) if o]
            if d['sig'] in (SIG_LOAD_TMU0, SIG_LOAD_TMU1):
                for o in ops:
                    if o.get('add_out') in (W_TMU0_S, W_TMU1_S) or \
                       o.get('mul_out') in (W_TMU0_S, W_TMU1_S):
                        raise AssertionError('word %d (%s): issue+pop' % (i, d['note']))
            if sum(1 for o in ops if o.get('add_out') in (W_TMU0_S, W_TMU1_S)) > 1:
                raise AssertionError('word %d: two issues' % i)
            if d['sig'] != SIG_NONE:
                for o in ops:
                    for k in ('add_b', 'mul_b'):
                        if o.get(k) is not None and o[k][0] == IMM:
                            raise AssertionError('word %d (%s): pop+imm' % (i, d['note']))
            wss = [o['ws'] for o in ops if 'ws' in o]
            if len(set(wss)) > 1:
                raise AssertionError('word %d (%s): ws conflict %s'
                                     % (i, d['note'], wss))
        return True

    # ---- schedule simulator ----------------------------------------------
    def verify(self):
        """Walk the program and assert every hazard rule on the schedule."""
        GP_A, GP_B, ACC = 0, 1, 2
        W = []
        for i, d in enumerate(self.w):
            rec = dict(wr=[], rd=set(), mul_wr=[], iss=None, pop=None,
                       note=d.get('note', ''))
            if 'branch' in d:
                W.append(rec)
                continue
            if 'ldi' in d:
                v, o, wsb = d['ldi']
                if 32 <= o <= 37:
                    rec['wr'].append((ACC, o - 32, 'ldi'))
                elif o < 32:
                    rec['wr'].append((GP_B if wsb else GP_A, o, 'ldi'))
                W.append(rec)
                continue
            ops = []
            if d['mul']:
                ops.append(('mul', d['mul']))
            if d['add']:
                ops.append(('add', d['add']))
            add_ws = d['add'].get('ws') if d['add'] else None
            mul_ws = d['mul'].get('ws') if d['mul'] else None
            eff = add_ws if add_ws is not None else (mul_ws if mul_ws is not None
                                                     else d['ws'])
            ports = {}
            for kind, o in ops:
                for slot in ('add_a', 'add_b', 'mul_a', 'mul_b'):
                    if o.get(slot) is not None:
                        mux, addr = o[slot]
                        if mux == IMM:
                            p, key, rd = 'rb', ('imm', addr), None
                        elif mux == REGA:
                            p, key, rd = 'ra', addr, (GP_A, addr)
                        elif mux == REGB:
                            p, key, rd = 'rb', addr, (GP_B, addr)
                        else:
                            p, key, rd = None, ('acc', mux), (ACC, mux)
                        if rd:
                            rec['rd'].add(rd)
                        if p:
                            if p in ports and ports[p] != key:
                                rec.setdefault('perr', []).append(
                                    '%s: %s vs %s' % (p, ports[p], key))
                            ports[p] = key
                out = o.get('add_out') if kind == 'add' else o.get('mul_out')
                if out is None or out == W_NOP:
                    continue
                if out == W_TMU0_S:
                    rec['iss'] = 0
                    continue
                if out == W_TMU1_S:
                    rec['iss'] = 1
                    continue
                if out >= 38:
                    continue
                if out <= 37:
                    ent = (ACC, out - 32, kind)
                elif kind == 'add':
                    ent = (GP_A if eff == 0 else GP_B, out, kind)
                else:
                    ent = (GP_B if eff == 0 else GP_A, out, kind)
                rec['wr'].append(ent)
                if kind == 'mul':
                    rec['mul_wr'].append(ent)
            if d['sig'] in (SIG_LOAD_TMU0, SIG_LOAD_TMU1):
                rec['pop'] = 0 if d['sig'] == SIG_LOAD_TMU0 else 1
            W.append(rec)

        n = len(W)
        errs = []

        # -- 0. one A-side and one B-side register port per word
        for i, rec in enumerate(W):
            if rec.get('perr'):
                errs.append('word %d (%s): raddr port conflict %s'
                            % (i, rec['note'], rec['perr']))

        # -- 1. accumulator temps: fmul write -> fadd read, 1..3 words later
        for i, rec in enumerate(W):
            for (f, a, kind) in rec['mul_wr']:
                if f != ACC or a not in (G10_ACC_TMP, G10_ACC_TMP2):
                    continue
                found = None
                for k in range(i + 1, min(i + 4, n)):
                    if (ACC, a) in W[k]['rd']:
                        found = k
                        break
                    if any(w[0] == ACC and w[1] == a for w in W[k]['wr']):
                        break
                if found is None:
                    errs.append('word %d (%s): temp r%d never consumed'
                                % (i, rec['note'], a))

        # -- 2. broadcast: rep (acc r5) write -> fmul read >= 1
        last_rep = None
        for i, rec in enumerate(W):
            if (ACC, G10_ACC_BCAST) in [w[:2] for w in rec['wr']]:
                last_rep = i
            if (ACC, G10_ACC_BCAST) in rec['rd']:
                if last_rep is None:
                    errs.append('word %d (%s): broadcast read before rep'
                                % (i, rec['note']))
                elif i - last_rep < 1:
                    errs.append('word %d (%s): broadcast read %d words after rep'
                                % (i, rec['note'], i - last_rep))

        # -- 3. rot write (acc r1) -> rep read >= 2
        for i, rec in enumerate(W):
            if (ACC, G10_ACC_ROT) in [w[:2] for w in rec['wr']]:
                for k in range(i + 1, min(i + 8, n)):
                    if (ACC, G10_ACC_ROT) in W[k]['rd']:
                        if k - i < 2:
                            errs.append('word %d: rot->rep only %d words'
                                        % (i, k - i))
                        break
                    if any(w[0] == ACC and w[1] == G10_ACC_ROT for w in W[k]['wr']):
                        break

        # -- 3b. A vector (acc r0) write -> v8min read >= 2
        for i, rec in enumerate(W):
            if (ACC, G10_ACC_AVEC) in [w[:2] for w in rec['wr']]:
                for k in range(i + 1, min(i + 8, n)):
                    if (ACC, G10_ACC_AVEC) in W[k]['rd']:
                        if k - i < 2:
                            errs.append('word %d: A copy->rot only %d words'
                                        % (i, k - i))
                        break
                    if any(w[0] == ACC and w[1] == G10_ACC_AVEC for w in W[k]['wr']):
                        break

        # -- 4. GP RAW gaps (A and B file) >= 2 words
        last = {}
        for i, rec in enumerate(W):
            for (f, a) in rec['rd']:
                if f == ACC:
                    continue
                if (f, a) in last and i - last[(f, a)] < 2:
                    errs.append('word %d (%s): GP %s%d RAW only %d words'
                                % (i, rec['note'], 'A' if f == GP_A else 'B', a,
                                   i - last[(f, a)]))
            for (f, a, kind) in rec['wr']:
                if f == ACC:
                    continue
                last[(f, a)] = i

        # -- 5. TMU: per TMU FIFO order, issue->pop >= 8, depth <= 4
        for t in (0, 1):
            q = []
            for i, rec in enumerate(W):
                if rec['iss'] == t:
                    q.append(i)
                    if len(q) > 4:
                        errs.append('word %d: %d in flight on TMU%d'
                                    % (i, len(q), t))
                if rec['pop'] == t:
                    if not q:
                        errs.append('word %d (%s): pop with empty TMU%d FIFO'
                                    % (i, rec['note'], t))
                        continue
                    a = q.pop(0)
                    if i - a < 8:
                        errs.append('word %d (%s): issue->pop only %d words'
                                    % (i, rec['note'], i - a))
            if q:
                errs.append('TMU%d left %d in flight' % (t, len(q)))

        # -- 6. every pop lands in r4: each pop's value must be copied to a GP
        #       register before the next pop on either TMU
        pops = [i for i, rec in enumerate(W) if rec['pop'] is not None]
        for k, i in enumerate(pops):
            nxt = pops[k + 1] if k + 1 < len(pops) else n
            ok = False
            for j in range(i + 1, nxt):
                if (ACC, G10_ACC_TMU) in W[j]['rd']:
                    ok = True
                    break
            if not ok:
                errs.append('word %d (%s): pop not copied before the next pop '
                            '(r4 aliasing)' % (i, W[i]['note']))

        if errs:
            raise AssertionError('schedule verify failed:\n  ' + '\n  '.join(errs))
        return True

    def write(self, path):
        ws = self.words()
        with open(path, 'wb') as f:
            for w in ws:
                f.write(struct.pack('<Q', w))
        return ws

    def listing(self):
        return '\n'.join('%3d: %s' % (i, disasm(w)) for i, w in enumerate(self.words()))


def g10_acc_addr(row, j):
    """(file, address) of C accumulator (row, j); file 0 = A file, 1 = B file."""
    return (0, 2 * row + j) if j < 2 else (1, 2 * row + (j - 2))


def g10_ref(f, addr):
    return areg(addr) if f == 0 else breg(addr)


def g10_or(out, x, y, ws=0):
    return dict(add_op=ADD_OR, add_out=out, ws=ws, add_a=x, add_b=y)


def g10_addi(op, out, x, y, ws=0, sf=0):
    return dict(add_op=op, add_out=out, ws=ws, add_a=x, add_b=y, sf=sf)


def g10_fmul(j, vec, t):
    f, addr = vec
    return dict(mul_op=MUL_FMUL, mul_out=32 + t, mul_a=acc(G10_ACC_BCAST),
                mul_b=g10_ref(f, addr))


def g10_rot(n):
    """Canonical v8min rotate of the A vector (see qenc.rot_inst)."""
    return qenc.rot_inst(n, src=G10_ACC_AVEC, out=G10_ACC_ROT)


def g10_fadd(r, j, t):
    f, addr = g10_acc_addr(r, j)
    return dict(add_op=ADD_FADD, add_out=addr, ws=f, add_a=g10_ref(f, addr),
                add_b=acc(t))


def g10_rep(ws=1):
    return dict(add_op=ADD_OR, add_out=37, ws=ws, add_a=acc(G10_ACC_ROT),
                add_b=acc(G10_ACC_ROT))


def g10_copy_add(f, addr):
    return dict(add_op=ADD_OR, add_out=addr, ws=f, add_a=acc(G10_ACC_TMU),
                add_b=acc(G10_ACC_TMU))


def g10_copy_mul(f, addr):
    """copy ACC_TMU -> GP register addr in file f, on the mul ALU (ws is
    inverted for the mul ALU)."""
    return dict(mul_op=MUL_V8MIN, mul_out=addr, ws=1 - f,
                mul_a=acc(G10_ACC_TMU), mul_b=acc(G10_ACC_TMU))


def g10_issue_b(j, tmu, ws=0):
    """issue the B request for column block j at BADR + 64j on TMU0/TMU1."""
    reg = W_TMU1_S if tmu else W_TMU0_S
    if j == 0:
        return g10_or(reg, acc(G10_ACC_BADR), acc(G10_ACC_BADR), ws=ws)
    return g10_addi(ADD_ADD, reg, acc(G10_ACC_BADR),
                    (REGB, [None, G10_RB_O64, G10_RB_O128, G10_RB_O192][j]),
                    ws=ws)


def g10_issue_a(ws=0):
    return g10_or(W_TMU0_S, areg(G10_RA_AADR), areg(G10_RA_AADR), ws=ws)


def g10_bump_badr(ws=0):
    return g10_addi(ADD_ADD, 32 + G10_ACC_BADR, acc(G10_ACC_BADR),
                    (REGB, G10_RB_BST), ws=ws)


def g10_rot_for(h, r):
    return (16 - (r + (8 if h else 0))) & 15


def g10_prime_issue(a, tag):
    for j in G10_FORDER:
        a.word(add=g10_issue_b(j, G10_TMU_OF[j]), note='%s issue j%d' % (tag, j))
    a.word(add=g10_bump_badr(), note='%s BADR bump' % tag)


def g10_prime_pop(a, s, tag):
    for j in G10_FORDER:
        a.word(sig=SIG_LOAD_TMU1 if G10_TMU_OF[j] else SIG_LOAD_TMU0,
               note='%s POP j%d' % (tag, j))
        f, addr = s[j]
        a.word(add=g10_copy_add(f, addr), note='%s copy j%d' % (tag, j))


def g10_phase(a, p, h, tag, do_pop=True, do_issue=True, a_pop=False,
              rot_next=False, a_issue=False):
    """Emit one 48-word half: 8 rows x 6 words, set (p mod 3) in use."""
    su = G10_SETV[p % 3]
    sp = G10_SETV[(p + 1) % 3]
    si = G10_SETV[(p + 2) % 3]
    idx = {}
    orders = [G10_FORDER] * G10_NROWS
    if a_issue:
        # row 6 carries the A issue: its w1 mul must read a B-file vector so
        # that raddr_a stays free for the issue
        orders[6] = G10_BORDER
    for r in range(G10_NROWS):
        o = orders[r]
        idx[(r, 0)] = a.word(add=g10_rep(ws=1), ws=1,
                             note='%s r%d w0 rep' % (tag, r))
        idx[(r, 1)] = a.word(mul=g10_fmul(o[0], su[o[0]], G10_ACC_TMP),
                             note='%s r%d w1 fmul j%d' % (tag, r, o[0]))
        idx[(r, 2)] = a.word(mul=g10_fmul(o[1], su[o[1]], G10_ACC_TMP2),
                             add=g10_fadd(r, o[0], G10_ACC_TMP),
                             note='%s r%d w2 fmul j%d|fadd j%d'
                                  % (tag, r, o[1], o[0]))
        idx[(r, 3)] = a.word(mul=g10_fmul(o[2], su[o[2]], G10_ACC_TMP),
                             add=g10_fadd(r, o[1], G10_ACC_TMP2),
                             note='%s r%d w3 fmul j%d|fadd j%d'
                                  % (tag, r, o[2], o[1]))
        idx[(r, 4)] = a.word(mul=g10_fmul(o[3], su[o[3]], G10_ACC_TMP2),
                             add=g10_fadd(r, o[2], G10_ACC_TMP),
                             note='%s r%d w4 fmul j%d|fadd j%d'
                                  % (tag, r, o[3], o[2]))
        idx[(r, 5)] = a.word(add=g10_fadd(r, o[3], G10_ACC_TMP2), ws=1,
                             note='%s r%d w5 fadd j%d' % (tag, r, o[3]))
    # rot(row i) -> mul slot of w0 of row i-1 (same word as that row's rep)
    for i in range(1, G10_NROWS):
        a.put(idx[(i - 1, 0)], 'mul', g10_rot(g10_rot_for(h, i)))
    if rot_next:
        # A vector does not change at this phase boundary
        a.put(idx[(G10_NROWS - 1, 0)], 'mul', g10_rot(g10_rot_for(1 - h, 0)))
    if do_issue:
        for j in G10_FORDER:
            a.put(idx[(G10_ISSUE_ROW[j], 1)], 'add', g10_issue_b(j, G10_TMU_OF[j]))
        a.put(idx[G10_BUMP_RW], 'add', g10_bump_badr())
    if a_issue:
        a.put(idx[(6, 1)], 'add', g10_issue_a())
    if do_pop:
        # every pop lands in r4: pop and copy in an order where each copy
        # precedes the next pop (j0 w4r1, j2 w4r3, j1 w4r5, j3 w4r6)
        for j in G10_FORDER:
            r, w = G10_POP_RW[j]
            a.pop(idx[(r, w)], G10_TMU_OF[j], '%s j%d' % (tag, j))
        for j in G10_FORDER:
            r, w, slot = G10_COPY_RW[j]
            f, addr = sp[j]
            op = g10_copy_add(f, addr) if slot == 'add' else g10_copy_mul(f, addr)
            a.put(idx[(r, w)], slot, op)
    if a_pop:
        a.pop(idx[G10_APOP_RW], 0, '%s A' % tag)
    return idx


def g10_boundary(a, p, counter=False):
    """A-vector change before phase p+1: pop, copy, rot, issue for k pair +2."""
    a.word(sig=SIG_LOAD_TMU0,
           add=g10_addi(ADD_ADD, G10_RA_AADR, areg(G10_RA_AADR),
                        (REGB, G10_RB_O64)),
           note='B%d: A pop + AADR += 64' % p)
    a.word(mul=g10_copy_mul(0, 32 + G10_ACC_AVEC),
           note='B%d: r0 = A vector' % p)
    a.nop(note='B%d: copy->rot gap' % p)
    a.word(mul=g10_rot(g10_rot_for(0, 0)), note='B%d: rot(p%d row 0)' % (p, p + 1))
    if counter:
        a.word(add=g10_addi(ADD_SUB, G10_RA_KCNT, areg(G10_RA_KCNT), imm(1), sf=1),
               note='k counter')
    else:
        a.nop(note='B%d: rot->rep gap' % p)


def g10_kloop_body(a, label):
    """One 6-phase group: 3 k pairs, 303 words."""
    a.label(label)
    a.nop(note='prologue (keeps rot->rep >= 2 across the back edge)')
    for p in range(6):
        g10_phase(a, p, p & 1, 'p%d' % p, do_pop=True, do_issue=True,
                  a_pop=(p == 5), rot_next=(p in (0, 2, 4)),
                  a_issue=(p in (0, 2, 4)))
        if p in (1, 3):
            g10_boundary(a, p, counter=(p == 3))


def g10_epilogue(a, act):
    """Activation applied in place to the 32 C vectors before the store.

    The tile is A-file r0..r15 (columns j0/j1) and B-file r0..r15 (j2/j3),
    so the answer is written back with ws=0 and ws=1 respectively.  A B-file
    vector cannot take a small immediate as its second operand (raddr_b would
    carry both the immediate and the register), so anything it needs beyond
    a register comes from an A register; an A-file vector takes the
    immediate.
    """
    if not act:
        return
    import kops
    if act not in (kops.ACT_RELU, kops.ACT_CLIP6):
        raise ValueError('kgen: gemm10 has no epilogue body for %s'
                         % (kops.ACT_NAMES[act],))
    av = [(r, j) for r in range(G10_NROWS) for j in (0, 1)]
    bv = [(r, j) for r in range(G10_NROWS) for j in (2, 3)]
    # A20 (the A tile pointer), A23 (the k counter) and B30 (the column
    # block's 4-row step) are dead from the end of the k loop until the
    # next column block re-establishes them, which is after this store.
    a.ldi(0, G10_RA_AADR, note='epilogue: 0.0f for the B-file vectors')
    if act == kops.ACT_CLIP6:
        # min(max(x,0),6): the upper bound is a real float, loaded into the
        # B file for the A-file vectors and into the A file for the B-file
        # ones.  B30 is reloaded by the next column block, so it needs no
        # restore.
        a.ldi(0x40C00000, G10_RB_TMP, ws=1, note='epilogue: 6.0f (B)')
        a.ldi(0x40C00000, G10_RA_KCNT, note='epilogue: 6.0f (A)')
    a.nop(), a.nop()
    for vec, hi in ((av, breg(G10_RB_TMP)), (bv, areg(G10_RA_KCNT))):
        for i in range(0, len(vec), 2):
            grp = vec[i:i + 2]
            for (r, j) in grp:
                f, addr = g10_acc_addr(r, j)
                lo = imm(0) if f == 0 else areg(G10_RA_AADR)
                a.word(add=g10_addi(ADD_FMAX, addr, g10_ref(f, addr), lo,
                                    ws=f),
                       note='epilogue relu r%d j%d' % (r, j))
            if act != kops.ACT_CLIP6:
                continue
            for (r, j) in grp:
                f, addr = g10_acc_addr(r, j)
                a.word(add=g10_addi(ADD_FMIN, addr, g10_ref(f, addr), hi,
                                    ws=f),
                       note='epilogue clip hi r%d j%d' % (r, j))


def g10_store(a, stride):
    """VPM->DMA store of the whole 8x64 C tile: 4 column chunks x 2 row halves.

    The VPM row base is 4*qpu, the VDW row field is that * 128 and the memory
    stride of a 16-word C row is (N-16)*4.  That stride is a 16-bit VDW field
    (vpmwords.vdw_stride), so a row pitch above 16384 floats cannot be
    written: (N-16)*4 overflows into the VDW control bits.  A compact tile
    layout is used for those shapes instead (build_gemm10's `compact`), which
    keeps the same store with a 64-float row pitch.
    """
    dma = (2 << 30) | (4 << 23) | (16 << 16) | (1 << 14)
    # r3 = 4*qpu*128 for the VDW row field, RA_TMP = 4*qpu for the vpw row
    a.word(add=g10_or(G10_RA_TMP, breg(R_QPU_NUM), breg(R_QPU_NUM)),
           note='qpu')
    a.nop(), a.nop()
    a.word(add=g10_addi(ADD_SHL, G10_RA_TMP, areg(G10_RA_TMP), imm(2)),
           note='4*qpu')
    a.nop(), a.nop()
    a.word(add=g10_addi(ADD_SHL, 32 + G10_ACC_SCR, areg(G10_RA_TMP), imm(7)),
           note='r3 = 4*qpu*128')
    a.nop()
    for j in range(4):
        for c in range(2):
            a.ldi(0x1A00, R5, ws=1, note='vpw generic row 4q')
            a.word(add=g10_addi(ADD_ADD, W_VPW_SETUP, acc(5), areg(G10_RA_TMP),
                                ws=1))
            for r in range(4):
                f, addr = g10_acc_addr(4 * c + r, j)
                a.word(add=g10_or(W_VPM, g10_ref(f, addr), g10_ref(f, addr)))
            a.ldi(dma, R5, ws=1, note='vdw 4 rows x 16 words')
            a.word(add=g10_addi(ADD_ADD, W_VPW_SETUP, acc(5), acc(G10_ACC_SCR),
                                ws=1))
            a.ldi(0xC0010000 | stride, W_VPW_SETUP, ws=1, note='stride (N-16)*4')
            base = G10_RA_CADR if c == 0 else G10_RA_CADR2
            a.word(add=g10_or(W_VPW_ADDR, areg(base), areg(base), ws=1))
            a.word(add=g10_or(W_NOP, (REGB, R_VPW_WAIT), (REGB, R_VPW_WAIT)))
            a.nop(), a.nop(), a.nop(), a.nop()
        if j != 3:
            a.word(add=g10_addi(ADD_ADD, G10_RA_CADR, areg(G10_RA_CADR),
                                (REGB, G10_RB_O64)), note='next 16 columns')
            a.word(add=g10_addi(ADD_ADD, G10_RA_CADR2, areg(G10_RA_CADR2),
                                (REGB, G10_RB_O64)), note='next 16 columns')


def g10_dump_avec(a, base_reg):
    """Store the 16 lanes of acc0 (the A vector) to memory at base_reg.

    Uses the same VPM->DMA path as the real store: 1 chunk of 4 identical rows
    of 16 words, stride 0, VPM row 0 (single-QPU probe only).
    """
    dma = (2 << 30) | (4 << 23) | (16 << 16) | (1 << 14)
    a.ldi(0x1A00, R5, ws=1, note='probe vpw')
    a.word(add=g10_addi(ADD_ADD, W_VPW_SETUP, acc(5), acc(5), ws=1))
    for _ in range(4):
        a.word(add=g10_or(W_VPM, acc(G10_ACC_AVEC), acc(G10_ACC_AVEC)))
    a.ldi(dma, R5, ws=1, note='probe vdw 4 rows x 16 words')
    a.word(add=g10_addi(ADD_ADD, W_VPW_SETUP, acc(5), acc(5), ws=1))
    a.ldi(0xC0010000, W_VPW_SETUP, ws=1)
    a.word(add=g10_or(W_VPW_ADDR, areg(base_reg), areg(base_reg), ws=1))
    a.word(add=g10_or(W_NOP, (REGB, R_VPW_WAIT), (REGB, R_VPW_WAIT)))
    a.nop(), a.nop(), a.nop(), a.nop()


def build_gemm10(M, N, K, nqpu=12, probe=None, single=False, act=0,
                 compact=0):
    """The asm10 GEMM for arbitrary M (8-aligned), N (64-aligned), K (16-aligned).

    `act` is an activation epilogue on the 8x64 C tile before it is stored
    (`kops.ACT_*`).  `relu` and `clip(0,6)` are offered: the bound 6.0 is a
    real float, and the only B register free after the k loop is the column
    block's 4-row step, which the next column block reloads anyway.

    `compact` writes C as one dense 8x64 tile per (row block, column block)
    instead of a row-major [M][N] result.  The store's memory stride between
    C rows is a 16-bit field, so a row pitch above 16384 floats cannot be
    written; with a compact tile the pitch is 64 floats and (64-16)*4 = 192
    fits, at the cost of a tile copy into the caller's matrix.  The tile
    layout is [row block][column block][row][64 floats], and vc4_gemm.c's
    unpack_compact() reproduces it.
    """
    assert M % G10_NROWS == 0 and N % G10_NCOLS == 0 and K % 16 == 0, \
        "gemm10 needs M%%8==0, N%%64==0, K%%16==0 (got %d,%d,%d)" % (M, N, K)
    TR, NCB = M // G10_NROWS, N // G10_NCOLS
    NQ = min(nqpu, TR)
    KPAIRS = K // 2
    NBODY, REM = divmod(KPAIRS, 3)
    drain = (REM == 0)
    nloop = NBODY - 1 if drain else NBODY
    assert nloop >= 1, "gemm10 needs K >= 16"
    assert REM in (0, 1, 2)
    RBCNT = (TR + NQ - 1) // NQ
    if compact:
        # 64-float C rows: 4-row store stride 192, row-half offset 1024,
        # one 2048-byte tile per column block (the tile base is scaled in
        # cb_top below), and one tile set per row block per QPU iteration.
        stride = (G10_NCOLS - 16) * 4
        c_half = G10_NROWS // 2 * G10_NCOLS * 4
        cstride = NQ * N * 32
    else:
        stride = (N - 16) * 4
        c_half = 4 * N * 4
        cstride = NQ * G10_NROWS * N * 4
    astride = NQ * G10_NROWS * K * 4

    a = G10Asm()

    if probe == 'lane':
        # debug build: dump acc3 = elem_num<<2 through the (proven) store path
        for i in range(8):
            a.word(add=g10_or(i, areg(R_UNIF), areg(R_UNIF), ws=0),
                   note='u%d' % i)
        a.word(add=g10_addi(ADD_SHL, 32 + G10_ACC_SCR, areg(R_ELEM_NUM), imm(2)),
               note='r3 = elem_num*4')
        a.nop(), a.nop()
        a.word(add=g10_or(0, acc(G10_ACC_SCR), acc(G10_ACC_SCR), ws=0),
               note='A0 = lane*4')
        a.word(add=g10_or(G10_RA_CADR, areg(1), areg(1)), note='C base = u1')
        a.nop(), a.nop()
        g10_store(a, stride)
        a.label('tdone')
        a.word(sig=SIG_END_PROGRAM)
        a.nop(), a.nop(), a.nop()
        a.check()
        a.verify()
        return a
    if probe == 'unif':
        # debug build: dump u0..u7 into C through the (proven) store path
        for i in range(8):
            a.word(add=g10_or(i, areg(R_UNIF), areg(R_UNIF), ws=0),
                   note='dump u%d' % i)
        a.word(add=g10_or(G10_RA_CADR, areg(1), areg(1)), note='C base = u1')
        a.nop(), a.nop()
        g10_store(a, stride)
        a.label('tdone')
        a.word(sig=SIG_END_PROGRAM)
        a.nop(), a.nop(), a.nop()
        a.check()
        a.verify()
        return a

    # ---------------------------------------------------------------- setup
    # The ALU reads one A-file and one B-file register per word, so the live
    # values are split between the files to keep every address computation a
    # single word: A file = A/C tile addresses + the column-block offset, B
    # file = the C row-block base, the B base, the constants and the stride
    # temporaries.
    # Read all eight uniforms first and only then combine them.  A GP register
    # written by a uniform read is NOT visible to the next instruction on this
    # silicon (measured: u3 landed in B r30 and the very next word read B r30
    # one instruction too early, so the A row-block base came out 255 bytes
    # high and every A k-pair was read 8 k out of place).  asm10 kept >= 6
    # words between each uniform read and its first use; do the same.
    a.word(add=g10_or(36, imm(1), imm(1)), note='tmu_noswap')
    a.word(add=g10_or(G10_RA_ARB, areg(R_UNIF), areg(R_UNIF)), note='u0 panel')
    a.word(add=g10_or(G10_RB_CARB, areg(R_UNIF), areg(R_UNIF), ws=1), note='u1 C')
    a.word(add=g10_or(G10_RB_BLANE, areg(R_UNIF), areg(R_UNIF), ws=1), note='u2 B')
    a.word(add=g10_or(G10_RB_TMP, areg(R_UNIF), areg(R_UNIF), ws=1),
           note='u3 A rb offset')
    a.word(add=g10_or(G10_RB_O64, areg(R_UNIF), areg(R_UNIF), ws=1),
           note='u4 A rb stride (re-derived, sink only)')
    a.word(add=g10_or(G10_RA_CTMP, areg(R_UNIF), areg(R_UNIF)), note='u5 C rb offset')
    a.word(add=g10_or(G10_RB_BST, areg(R_UNIF), areg(R_UNIF), ws=1),
           note='u6 C rb stride (re-derived, sink only)')
    a.word(add=g10_or(G10_RA_RBIDX, areg(R_UNIF), areg(R_UNIF)), note='u7 first rb')
    a.nop(), a.nop(), a.nop()
    a.word(add=g10_addi(ADD_ADD, G10_RA_ARB, areg(G10_RA_ARB), (REGB, G10_RB_TMP)),
           note='A rb base')
    a.word(add=g10_addi(ADD_ADD, G10_RB_CARB, breg(G10_RB_CARB), areg(G10_RA_CTMP),
                        ws=1), note='C rb base')
    a.nop(), a.nop()
    a.ldi(N * 4, G10_RB_BST, ws=1, note='B row stride')
    a.ldi(64, G10_RB_O64, ws=1)
    a.ldi(128, G10_RB_O128, ws=1)
    a.ldi(192, G10_RB_O192, ws=1)
    a.ldi(256, G10_RB_O256, ws=1)
    a.ldi((0 - TR) & 0xFFFFFFFF, G10_RB_NEGTR, ws=1, note='-TR')
    a.ldi(RBCNT, G10_RB_RBCNT, ws=1, note='row-block bound')
    a.ldi(0, G10_RA_CBOFF, note='column-block offset')
    # asm10's exact spacing: the accumulator read must be 2 words after the
    # write (measured: a 3-word gap reads a different rotation slot and puts
    # the A base 255 bytes off).
    a.word(add=g10_addi(ADD_SHL, 32 + G10_ACC_SCR, areg(R_ELEM_NUM), imm(2)),
           note='r3 = lane*4')
    a.nop()
    a.word(add=g10_addi(ADD_ADD, G10_RA_ARB, areg(G10_RA_ARB),
                        acc(G10_ACC_SCR)), note='A + lane*4')
    a.word(add=g10_addi(ADD_ADD, G10_RB_BLANE, breg(G10_RB_BLANE),
                        acc(G10_ACC_SCR), ws=1), note='B + lane*4')
    a.nop(), a.nop()

    # ------------------------------------------------------- row block loop
    a.label('rb_top')
    a.word(add=g10_addi(ADD_ADD, 32 + G10_ACC_SCR, areg(G10_RA_RBIDX),
                        (REGB, G10_RB_NEGTR), sf=1), note='rb - TR')
    a.nop(), a.nop()
    a.branch_to('rb_body', cond=BR_ALL_N_SET)
    a.nop(), a.nop(), a.nop()
    a.branch_to('tdone', cond=BR_ALWAYS)
    a.nop(), a.nop(), a.nop()
    a.label('rb_body')
    a.ldi(NCB, G10_RA_CBCNT, note='column blocks')
    a.word(add=g10_or(G10_RA_CBOFF, imm(0), imm(0)), note='cb offset = 0')
    a.nop(), a.nop()

    # ------------------------------------------------------ column block loop
    a.label('cb_top')
    a.word(add=g10_or(G10_RA_AADR, areg(G10_RA_ARB), areg(G10_RA_ARB)),
           note='A tile base')
    if compact:
        # CBOFF is the B column offset (64 columns = 256 B); a compact C tile
        # is 2048 B, so the tile base is CBOFF*8 + the row-block base
        a.word(add=g10_addi(ADD_SHL, G10_RA_CADR, areg(G10_RA_CBOFF), imm(3)),
               note='C tile base = 8 * column-block offset')
        a.nop(), a.nop()
        a.word(add=g10_addi(ADD_ADD, G10_RA_CADR, areg(G10_RA_CADR),
                            (REGB, G10_RB_CARB)))
    else:
        a.word(add=g10_addi(ADD_ADD, G10_RA_CADR, areg(G10_RA_CBOFF),
                            (REGB, G10_RB_CARB)), note='C tile base')
    a.word(add=g10_addi(ADD_ADD, 32 + G10_ACC_BADR, areg(G10_RA_CBOFF),
                        (REGB, G10_RB_BLANE)), note='B tile base')
    a.ldi(c_half, G10_RB_TMP, ws=1, note='4 C rows')
    a.nop(), a.nop()
    a.word(add=g10_addi(ADD_ADD, G10_RA_CADR2, areg(G10_RA_CADR),
                        (REGB, G10_RB_TMP)), note='+ 4 C rows')
    a.nop(), a.nop()
    if probe == 'addrs':
        # dump AADR, CADR, CADR2, CBOFF, BLANE, C_ARB, A_ARB, RBIDX through the
        # (proven) store, to the dump address in u8 (so the store does not
        # depend on the very addresses being measured)
        a.word(add=g10_or(G10_RA_CADR2, areg(R_UNIF), areg(R_UNIF)),
               note='u8 dump address')
        a.nop(), a.nop()
        a.word(add=g10_or(G10_RA_CADR, areg(G10_RA_CADR2), areg(G10_RA_CADR2)),
               note='CADR = u8')
        a.nop(), a.nop()
        for src, dst in ((G10_RA_AADR, 0), (G10_RA_AADR, 2), (G10_RA_CADR2, 4),
                         (G10_RA_CBOFF, 6), (G10_RB_BLANE, 1), (G10_RB_CARB, 3),
                         (G10_RA_ARB, 5), (G10_RA_RBIDX, 7)):
            if src in (G10_RB_BLANE, G10_RB_CARB):
                a.word(add=g10_or(dst, breg(src), breg(src), ws=0))
            else:
                a.word(add=g10_or(dst, areg(src), areg(src), ws=0))
            a.nop(), a.nop()
        a.branch_to('store_x', note='probe: dump addresses')
        a.nop(), a.nop(), a.nop()
    for r in range(G10_NROWS):
        for j in range(4):
            f, addr = g10_acc_addr(r, j)
            a.word(add=g10_or(addr, imm(0), imm(0), ws=f))
    a.nop()
    a.word(add=g10_or(32 + G10_ACC_TMP, imm(0), imm(0)), note='r2 = 0 (mul temp)')
    a.nop()
    a.ldi(nloop, G10_RA_KCNT, note='k-loop iterations (3 k pairs each)')

    # ---------------------------------------------------------- tile prime
    a.word(add=g10_or(W_TMU0_S, areg(G10_RA_AADR), areg(G10_RA_AADR)),
           note='prime issue A kp0')
    a.word(add=g10_addi(ADD_ADD, G10_RA_AADR, areg(G10_RA_AADR),
                        (REGB, G10_RB_O64)), note='AADR += 64')
    g10_prime_issue(a, 'prime s0')
    for _ in range(8):
        a.nop()
    a.word(sig=SIG_LOAD_TMU0, note='prime POP A')
    a.word(add=g10_copy_add(0, 32 + G10_ACC_AVEC), note='prime r0 = A')
    g10_prime_pop(a, G10_SETV[0], 'prime s0')
    g10_prime_issue(a, 'prime s1 (left in flight)')
    a.nop()
    a.word(mul=g10_rot(g10_rot_for(0, 0)), note='prime rot(p0 row 0)')

    if probe == 'const':
        # debug build: dump a known constant to validate the dump path itself
        a.word(add=g10_or(32 + G10_ACC_AVEC, imm(21), imm(21)))
        a.nop(), a.nop()
        g10_dump_avec(a, G10_RA_CADR)
        for _ in range(2):
            for t in (0, 1):
                a.word(sig=SIG_LOAD_TMU1 if t else SIG_LOAD_TMU0, note='probe drain')
                a.word(add=g10_copy_add(0, 32 + G10_ACC_AVEC))
        a.label('tdone')
        a.word(sig=SIG_END_PROGRAM)
        a.nop(), a.nop(), a.nop()
        a.check()
        a.verify()
        return a
    if probe == 'prime_a':
        # debug build: copy the A vector into the store's row-0 inputs and use
        # the (proven) C store to report it
        a.word(add=g10_or(0, acc(G10_ACC_AVEC), acc(G10_ACC_AVEC), ws=0),
               note='A0 = A vector')
        a.nop(), a.nop()
        g10_store(a, stride)
        # drain the four requests of set 1 so nothing is left in flight
        for _ in range(2):
            for t in (0, 1):
                a.word(sig=SIG_LOAD_TMU1 if t else SIG_LOAD_TMU0, note='probe drain')
                a.word(add=g10_copy_add(0, 32 + G10_ACC_AVEC))
        a.label('tdone')
        a.word(sig=SIG_END_PROGRAM)
        a.nop(), a.nop(), a.nop()
        a.check()
        a.verify()
        return a

    # -------------------------------------------------------------- k loop
    g10_kloop_body(a, 'kloop')
    a.branch_to('kloop', cond=BR_ALL_Z_CLEAR, note='k loop')
    a.word(mul=dict(mul_op=MUL_V8MIN, mul_out=32 + G10_ACC_AVEC, ws=1,
                    mul_a=acc(G10_ACC_TMU), mul_b=acc(G10_ACC_TMU)),
           note='delay1: r0 = A vector of the next k pair')
    a.word(add=g10_addi(ADD_ADD, G10_RA_AADR, areg(G10_RA_AADR),
                        (REGB, G10_RB_O64)), note='delay2: AADR += 64')
    a.word(mul=g10_rot(g10_rot_for(0, 0)),
           note='delay3: rot(row0) of the next k pair')

    # ---------------------------------------------------- k-loop tail
    # The last main-loop iteration prefetched set 0 (next k even) and set 1
    # (next k odd); REM = 1 uses them as they are, REM = 2 also fills set 2.
    a.nop(note='tail entry pad (rot->rep >= 2 on the loop-exit path)')
    if drain:
        # KPAIRS % 3 == 0: the last group is emitted here with the issues of
        # its last two phases suppressed, so every pop has an issue and the
        # TMUs are empty at the store.
        for p in range(6):
            g10_phase(a, p, p & 1, 'd%d' % p, do_pop=(p < 5), do_issue=(p < 4),
                      rot_next=(p in (0, 2, 4)), a_issue=(p in (0, 2)))
            if p in (1, 3):
                g10_boundary(a, p, counter=False)
    elif REM == 1:
        g10_phase(a, 6, 0, 't0', do_pop=True, do_issue=False, rot_next=True)
        g10_phase(a, 7, 1, 't1', do_pop=False, do_issue=False, rot_next=False)
    else:
        g10_phase(a, 6, 0, 't0', do_pop=True, do_issue=True, rot_next=True,
                  a_issue=True)
        g10_phase(a, 7, 1, 't1', do_pop=True, do_issue=True, rot_next=False)
        g10_boundary(a, 7, counter=False)
        g10_phase(a, 8, 0, 't2', do_pop=True, do_issue=False, rot_next=True)
        g10_phase(a, 9, 1, 't3', do_pop=False, do_issue=False, rot_next=False)
    a.nop()

    # -------------------------------------------------------------- store
    a.label('store_x')
    if probe == 'regs':
        # overwrite the accumulator inputs of the (proven) store with address
        # registers so the store itself reports them
        for src, dst in ((G10_RA_AADR, 0), (G10_RA_CADR, 2), (G10_RA_CADR2, 4),
                         (G10_RA_CBOFF, 6), (G10_RA_ARB, 1), (G10_RA_RBIDX, 3),
                         (G10_RB_BLANE, 5), (G10_RB_CARB, 7)):
            if src in (G10_RB_BLANE, G10_RB_CARB):
                a.word(add=g10_or(dst, breg(src), breg(src), ws=0))
            else:
                a.word(add=g10_or(dst, areg(src), areg(src), ws=0))
            a.nop(), a.nop()
    g10_epilogue(a, act)
    g10_store(a, stride)

    if single:
        # debug build: exactly one tile, no tile loop
        a.branch_to('tdone', note='single tile')
        a.nop(), a.nop(), a.nop()
        a.label('tdone')
        a.word(sig=SIG_END_PROGRAM)
        a.nop(), a.nop(), a.nop()
        a.check()
        a.verify()
        return a

    # ------------------------------------------------- next column / row block
    a.word(add=g10_addi(ADD_ADD, G10_RA_CBOFF, areg(G10_RA_CBOFF),
                        (REGB, G10_RB_O256)), note='next column block')
    a.word(add=g10_addi(ADD_SUB, G10_RA_CBCNT, areg(G10_RA_CBCNT), imm(1), sf=1),
           note='cb counter')
    a.branch_to('cb_top', cond=BR_ALL_Z_CLEAR)
    a.nop(), a.nop(), a.nop()
    a.ldi(astride, G10_RB_TMP, ws=1, note='A rb stride')
    a.nop(), a.nop()
    a.word(add=g10_addi(ADD_ADD, G10_RA_ARB, areg(G10_RA_ARB),
                        (REGB, G10_RB_TMP)))
    a.nop(), a.nop()
    a.ldi(cstride, G10_RA_CTMP, ws=0, note='C rb stride')
    a.nop(), a.nop()
    a.word(add=g10_addi(ADD_ADD, G10_RB_CARB, breg(G10_RB_CARB),
                        areg(G10_RA_CTMP), ws=1))
    a.nop()
    a.word(add=g10_addi(ADD_ADD, G10_RA_RBIDX, areg(G10_RA_RBIDX), imm(NQ)),
           note='next row block')
    # the B file cannot hold a register and a small immediate in one word, so
    # the counter decrement borrows the A-file stride temporary
    a.ldi(1, G10_RA_CTMP, note='1')
    a.nop(), a.nop()
    a.word(add=g10_addi(ADD_SUB, G10_RB_RBCNT, breg(G10_RB_RBCNT),
                        areg(G10_RA_CTMP), sf=1, ws=1))
    a.branch_to('rb_top', cond=BR_ALL_Z_CLEAR)
    a.nop(), a.nop(), a.nop()

    a.label('tdone')
    a.word(sig=SIG_END_PROGRAM)
    a.nop(), a.nop(), a.nop()

    a.check()
    a.verify()
    return a


# =============================================================== pack/transpose
def build_pack(kblocks, vpitch=1, dstride=0):
    """K-major panel builder: PANEL[(rb*K + k)*16 + r] = SRC[rb*16 + r][k].

    The asm3 packer (VDR + vertical VDW, no ALU data movement) with the source
    and destination strides as uniforms, so the same blob builds the A panel
    and a k-major B panel from a [Cout][K] weight matrix.

    dstride != 0 turns the 1 KB transposed block into a strided store: each of
    the 16 rows of the transposed block is written dstride bytes further into
    memory than the previous one (the field is *additional* to the 64 B a row
    writes; emit_store16 uses the same field).  With dstride = dst_row_pitch-64
    and the per-kblock/per-rowblock strides set by the caller, the same kernel
    is a dense 16x16 block transpose (vc4__tpose_run).
    """
    A = dict(RL=17, SRCB=18, PB=19, SRCP=20, DSTP=21, SRC=22, DST=23,
             CNT=24, KB=25, VDRW=26, VDWW=27, TMP=28, VDRS=29, VDWS=30, PITCH=31)
    B = dict(OFF=16, ST=17, ST64=18, NEG1=19, DKB=20, DRB=21, Q=22, RBT=23,
             DOFF=24)

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A['RL'])                                      # u0 row length (floats)
    b.read_uni(B['OFF'], ws=1)                               # u1 src rb offset
    b.read_uni(A['SRCB'])                                    # u2 src base
    b.read_uni(B['ST'], ws=1)                                # u3 src rb stride
    b.read_uni(A['PB'])                                      # u4 dst base
    b.read_uni(A['CNT'])                                     # u5 row blocks
    b.read_uni(16)                                           # u6 qpu index (A16)
    b.read_uni(B['DKB'], ws=1)                               # u7 dst k-block stride
    b.read_uni(B['DRB'], ws=1)                               # u8 dst rb stride
    b.read_uni(B['DOFF'], ws=1)                              # u9 dst rb offset

    b.e(add_(ADD_SHL, A['PITCH'], ws=1, a=areg(A['RL']), b=imm(2)), nop())  # *4
    b.e(add_(ADD_SHL, B['RBT'], ws=1, a=areg(16), b=imm(8)))          # q<<8
    b.e(ldi(V.vdr_basic(0, vpitch), A['VDRW']), nop())
    b.e(add_(ADD_ADD, A['VDRW'], areg(A['VDRW']), (REGB, B['RBT'])), nop())
    b.e(add_(ADD_SHL, B['RBT'], ws=1, a=areg(16), b=imm(11)))         # q<<11
    b.e(ldi(V.vdw_basic(0, 16, 16, horizontal=0), A['VDWW']), nop())
    b.e(add_(ADD_ADD, A['VDWW'], areg(A['VDWW']), (REGB, B['RBT'])), nop(), nop())
    b.e(ldi(V.vdr_stride(0) & ~0xFFF, A['TMP']), nop(), nop())
    b.e(add_(ADD_ADD, A['VDRS'], areg(A['TMP']), (REGB, A['PITCH'])), nop())
    b.e(ldi(V.vdw_stride(dstride), A['VDWS']), nop())
    b.e(add_(ADD_ADD, A['SRCP'], areg(A['SRCB']), (REGB, B['OFF'])), nop())
    # destination row blocks can have a different stride than the source
    # (the conv weight panel includes the folded bias k-block)
    b.e(add_(ADD_ADD, A['DSTP'], areg(A['PB']), (REGB, B['DOFF'])), nop())
    b.e(ldi(64, B['ST64'], ws=1))
    b.e(ldi(0xFFFFFFFF, B['NEG1'], ws=1))
    b.e(nop(), nop())

    p._builder = b
    p.label('rb')
    b.e(add_or(A['SRC'], areg(A['SRCP']), areg(A['SRCP'])))
    b.e(add_or(A['DST'], areg(A['DSTP']), areg(A['DSTP'])))
    p.emit(ldi(kblocks, A['TMP'], ws=0))                     # compile-time k blocks
    b.e(nop(), nop())
    p.label('kb')
    b.e(add_or(W_VPR_SETUP, areg(A['VDRW']), areg(A['VDRW'])))
    b.e(add_or(W_VPR_SETUP, areg(A['VDRS']), areg(A['VDRS'])))
    b.e(add_or(W_VPR_ADDR, areg(A['SRC']), areg(A['SRC'])))
    b.e(add_or(W_NOP, areg(50), areg(50)))                       # vpr_wait
    b.e(add_or(W_VPW_SETUP, areg(A['VDWW']), areg(A['VDWW']), ws=1))
    b.e(add_or(W_VPW_SETUP, areg(A['VDWS']), areg(A['VDWS']), ws=1))
    b.e(add_or(W_VPW_ADDR, areg(A['DST']), areg(A['DST']), ws=1))
    b.e(add_or(W_NOP, (REGB, R_VPW_WAIT), (REGB, R_VPW_WAIT)))   # vpw_wait
    b.e(add_(ADD_ADD, A['TMP'], (REGB, B['NEG1']), areg(A['TMP']), sf=1))
    p.branch_to('kb', cond=BR_ALL_Z_CLEAR)
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), (REGB, B['ST64'])))
    b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), (REGB, B['DKB'])))
    b.e(nop())
    b.e(add_(ADD_ADD, A['SRCP'], areg(A['SRCP']), (REGB, B['ST'])))
    b.e(add_(ADD_ADD, A['DSTP'], areg(A['DSTP']), (REGB, B['DRB'])))
    b.e(add_(ADD_ADD, A['CNT'], (REGB, B['NEG1']), areg(A['CNT']), sf=1))
    p.branch_to('rb', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# =============================================================== pack (asm10)
def build_pack10(K, vpitch=1):
    """K-major panel builder: asm10's layout and work assignment.

        PANEL[(rb*K + k)*8 + r] = SRC[rb*8 + r][k]

    This is asm10/pack10.py in its adopted configuration (single mode: 8 A
    rows and KL=16 words per VDR command, the one proven 8x8-word VDW shape per
    256 B half, grid-stride work assignment) and it is *instruction-identical*
    to asm10's `pack10_<K>_k16_single_vp1_us.bin`: at N=256 that kernel builds
    the panel in 382 us instead of 458 us for the same bytes, and the panel is
    bit-exact (asm10/RESULTS10.md).

    KERNEL ABI (uniforms u0..u7, 64 B block per QPU)
      u0 source row length in floats (K)
      u1 this QPU's first work-unit byte offset (source and panel)
      u2 source base bus
      u3 one work-unit byte stride (32*K; the kernel re-derives it)
      u4 panel base bus
      u5 work units for this QPU
      u6 QPU launch index (VPM row base = 8*q)
      u7 work-unit byte step (grid stride = pnq * 32*K)

    A work unit is 8 A rows x K: 32*K bytes of source and of panel, so the same
    byte offset applies to both when the source is the padded A copy.
    """
    assert K % 16 == 0, "pack10 needs K % 16 == 0"
    kl = 16
    nrow = 8
    kiter = K // kl
    srcstep = kl * 4                # bytes per k strip (one A row)
    dststep = kl * nrow * 4         # bytes per k strip in the panel
    le1 = nrow.bit_length() - 1
    vdws = [(g, c) for g in range(nrow // 8) for c in range(kl // 8)]

    RA_D2, RA_A, RA_P = 16, 17, 18
    RA_VD1, RA_VD2, RA_SRC, RA_DST = 19, 20, 21, 22
    RA_KB, RA_CNT, RA_VDRW = 23, 24, 25
    RA_VD0, RA_D3, RA_VDRS, RA_VDWS = 26, 27, 28, 29
    RA_VD3, RA_D4 = 30, 31
    RB_OFF, RB_ST, RB_KL = 16, 17, 18
    RB_VECB, RB_NEG1, RB_UNIT = 19, 20, 22
    RB_BLKB, RB_RO, RB_C = 23, 24, 26

    vdwreg = [RA_VD0, RA_VD1, RA_VD2, RA_VD3][:len(vdws)]
    dstreg = [RA_DST, RA_D2, RA_D3, RA_D4][:len(vdws)]
    assert len(vdws) <= 4

    p = Prog()

    def e(*ws):
        for w in ws:
            p.emit(_ops(**w) if isinstance(w, dict) else w)

    # ---------------- prologue -------------------------------------------
    e(add_or(36, imm(1), imm(1)))                                # tmu_noswap
    e(add_(ADD_SHL, RB_ST, ws=1, a=areg(R_UNIF), b=imm(2)))      # u0 -> K*4 pitch
    e(add_or(RB_OFF, ws=1, a=areg(R_UNIF), b=areg(R_UNIF)))      # u1 = byte offset
    e(add_or(RA_A, areg(R_UNIF), areg(R_UNIF)))                  # u2 = A base
    e(add_or(RB_KL, ws=1, a=areg(R_UNIF), b=areg(R_UNIF)))       # u3 (unused)
    e(add_or(RA_P, areg(R_UNIF), areg(R_UNIF)))                  # u4 = panel base
    e(add_or(RA_CNT, areg(R_UNIF), areg(R_UNIF)))                # u5 = units
    e(add_or(RA_D3, areg(R_UNIF), areg(R_UNIF)))                 # u6 = QPU index
    e(add_or(RB_UNIT, ws=1, a=areg(R_UNIF), b=areg(R_UNIF)))     # u7 = unit step

    # VDR basic: ID=1, row base nrow*q (row field at bit 4), nrow rows, KL words
    e(add_(ADD_SHL, RB_RO, ws=1, a=areg(RA_D3), b=imm(le1 + 4)))
    e(ldi(V.vdr_basic(0, vpitch, numrows=nrow, rowlen=kl), RA_VDRW))
    e(nop(), nop())
    e(add_(ADD_ADD, RA_VDRW, areg(RA_VDRW), (REGB, RB_RO)))
    # VDW (one proven shape: depth 8 words = 32 B, units 8 = 256 B contiguous)
    e(add_(ADD_SHL, RB_RO, ws=1, a=areg(RA_D3), b=imm(le1 + 7)))
    e(ldi(V.vdw_basic(0, 8, 8, horizontal=0, col=0), RA_VD0))
    e(nop(), nop())
    e(add_(ADD_ADD, RA_VD0, areg(RA_VD0), (REGB, RB_RO)))
    for i, (g, c) in enumerate(vdws):
        if i == 0:
            continue                     # RA_VD0 is the (0,0) setup already
        e(ldi(g * 1024 + c * 64, RB_C, ws=1))    # +8 VPM rows / +8 words (col)
        e(nop(), nop())
        e(add_(ADD_ADD, vdwreg[i], areg(RA_VD0), (REGB, RB_C)))
    # strides
    e(ldi(V.vdr_stride(0) & ~0xFFF, RA_KB))                 # ID nibble only
    e(nop(), nop())
    e(add_(ADD_ADD, RA_VDRS, areg(RA_KB), (REGB, RB_ST)))   # ID=9 | pitch
    e(ldi(V.vdw_stride(0), RA_VDWS))                        # ID=3, block mode
    e(ldi(srcstep, RB_KL, ws=1))
    e(ldi(dststep, RB_VECB, ws=1))
    e(ldi(K * nrow * 4, RB_BLKB, ws=1))                     # one work unit
    e(ldi(0xFFFFFFFF, RB_NEG1, ws=1))                       # -1
    e(ldi(256, RB_C, ws=1))                                 # 8 k columns of panel
    e(nop(), nop())

    # ---------------- work-unit loop (an 8-row block) ---------------------
    p.label('rb')
    e(ldi(kiter, RA_KB))                                    # K/KL k strips
    e(add_(ADD_ADD, RA_SRC, areg(RA_A), (REGB, RB_OFF)))
    e(add_(ADD_ADD, RA_DST, areg(RA_P), (REGB, RB_OFF)))
    e(nop(), nop())

    # ---------------- KL-word strip loop ---------------------------------
    p.label('kb')
    e(add_or(W_VPR_SETUP, areg(RA_VDRW), areg(RA_VDRW), ws=0))
    e(add_or(W_VPR_SETUP, areg(RA_VDRS), areg(RA_VDRS), ws=0))
    e(add_or(W_VPR_ADDR, areg(RA_SRC), areg(RA_SRC), ws=0))
    e(add_or(W_NOP, areg(50), areg(50)))                    # vpr_wait
    # per-strip panel destinations (each VDW writes 256 B)
    if len(vdws) > 1:
        e(add_(ADD_ADD, RA_D2, areg(RA_DST), (REGB, RB_C)))     # +8 k
        if len(vdws) > 2:
            e(add_(ADD_ADD, RA_D3, areg(RA_DST), (REGB, RB_BLKB)))   # + one block
            e(nop())
            e(add_(ADD_ADD, RA_D4, areg(RA_D3), (REGB, RB_C)))
    for i in range(len(vdws)):
        e(add_or(W_VPW_SETUP, areg(vdwreg[i]), areg(vdwreg[i]), ws=1))
        e(add_or(W_VPW_SETUP, areg(RA_VDWS), areg(RA_VDWS), ws=1))
        e(add_or(W_VPW_ADDR, areg(dstreg[i]), areg(dstreg[i]), ws=1))
        e(add_or(W_NOP, (REGB, R_VPW_WAIT), (REGB, R_VPW_WAIT)))   # vpw_wait
    e(add_(ADD_ADD, RA_KB, (REGB, RB_NEG1), areg(RA_KB), sf=1))  # KB -= 1
    p.branch_to('kb', cond=BR_ALL_Z_CLEAR)
    e(add_(ADD_ADD, RA_SRC, areg(RA_SRC), (REGB, RB_KL)))       # delay 1
    e(add_(ADD_ADD, RA_DST, areg(RA_DST), (REGB, RB_VECB)))     # delay 2
    e(nop())                                                    # delay 3

    # ---------------- next work unit -------------------------------------
    e(add_(ADD_ADD, RA_CNT, (REGB, RB_NEG1), areg(RA_CNT), sf=1))   # CNT -= 1
    p.branch_to('rb', cond=BR_ALL_Z_CLEAR)
    e(add_(ADD_ADD, RA_A, areg(RA_A), (REGB, RB_UNIT)))          # delay 1
    e(add_(ADD_ADD, RA_P, areg(RA_P), (REGB, RB_UNIT)))          # delay 2
    e(nop())                                                     # delay 3

    e(end_program())
    e(nop(), nop(), nop())
    return p


# =============================================================== im2col
def build_im2col(Cin, K, KH, KW, vpitch=1, vout="k"):
    """Build the packed A panel straight from a padded NCHW image.

    One row block = 16 output pixels that are contiguous in the padded image.
    For one filter tap, a single VDR loads 16 channels x 16 pixels (pitch = the
    padded plane size) and the vertical VDW writes the transposed 1 KB block
    PANEL[rb][tap*Cin + c*16 .. +15][0..15].  No im2col matrix is ever
    materialised and no ARM arithmetic is involved.

    Requires Cin % 16 == 0 and H*Wp*4 <= 8191 (13-bit VDR pitch field).
    """
    assert Cin % 16 == 0 and K == Cin * KH * KW, "im2col expects K = Cin*KH*KW"
    nseg = KH * KW

    A = dict(SRCB=16, PB=17, SRC=18, DST=19, SEGSRC=20, CNT=21, KB=22,
             PITCH=23, VDRW=24, VDWW=25, TMP=26, VDRS=27, VDWS=28, DSTP=30)
    B = dict(OFF=16, ST=17, DKB=18, DRB=19, NEG1=20, C4=21, P16=22,
             Q=23, T=24, WP4=25, PIT=26, DOFF=27)

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A['PITCH'])                                   # u0 plane byte pitch
    b.read_uni(B['OFF'], ws=1)                               # u1 src rb offset
    b.read_uni(A['SRCB'])                                    # u2 padded base
    b.read_uni(B['ST'], ws=1)                                # u3 rb stride
    b.read_uni(A['PB'])                                      # u4 panel base
    b.read_uni(A['CNT'])                                     # u5 row blocks
    b.read_uni(29)                                           # u6 qpu index (A29)
    b.read_uni(B['DKB'], ws=1)                               # u7 1024
    b.read_uni(B['DRB'], ws=1)                               # u8 64*K
    b.read_uni(B['WP4'], ws=1)                               # u9  Wp*4
    b.read_uni(B['DOFF'], ws=1)                              # u10 dst rb offset

    b.e(add_(ADD_SHL, B['P16'], ws=1, a=areg(A['PITCH']), b=imm(4)))   # 16*pitch
    b.e(add_or(B['PIT'], ws=1, a=areg(A['PITCH']), b=areg(A['PITCH'])), nop())
    b.e(ldi(4, B['C4'], ws=1))
    b.e(ldi(0xFFFFFFFF, B['NEG1'], ws=1), nop())
    b.e(add_(ADD_SHL, B['T'], ws=1, a=areg(29), b=imm(8)))             # q<<8
    b.e(ldi(V.vdr_basic(0, vpitch), A['VDRW']), nop())
    b.e(add_(ADD_ADD, A['VDRW'], areg(A['VDRW']), (REGB, B['T'])), nop())
    b.e(add_(ADD_SHL, B['T'], ws=1, a=areg(29), b=imm(11)))            # q<<11
    # horizontal: the VDR rows are the channels (the panel's k) and the columns
    # are the 16 pixels (the panel's r), so the panel must not be transposed.
    # (A vertical VDW would store it as [pixel][channel].)
    # vout=k writes the k-major GEMM panel [k][r]; vout=r writes the
    # row-major im2col matrix [r][k] (the dW path needs that form).
    b.e(ldi(V.vdw_basic(0, 16, 16, horizontal=(1 if vout == "k" else 0)),
            A['VDWW']), nop())
    b.e(add_(ADD_ADD, A['VDWW'], areg(A['VDWW']), (REGB, B['T'])), nop(), nop())
    b.e(ldi(V.vdr_stride(0) & ~0xFFF, A['TMP']), nop(), nop())
    b.e(add_(ADD_ADD, A['VDRS'], areg(A['TMP']), (REGB, B['PIT'])), nop())
    b.e(ldi(V.vdw_stride(0 if vout == "k" else (K * 4 - 64)),
            A['VDWS']), nop())
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRCB']), (REGB, B['OFF'])), nop())
    # the destination row block is a full k-major panel (64*nk bytes), so its
    # offset is independent of the 64-byte source row block
    b.e(add_(ADD_ADD, A['DSTP'], areg(A['PB']), (REGB, B['DOFF'])), nop(), nop())

    p._builder = b
    p.label('rb')
    b.e(add_or(A['DST'], areg(A['DSTP']), areg(A['DSTP'])), nop())
    for s in range(nseg):
        ky, kx = divmod(s, KW)
        b.e(add_or(A['SEGSRC'], areg(A['SRC']), areg(A['SRC'])))
        for _ in range(ky):
            b.e(add_(ADD_ADD, A['SEGSRC'], areg(A['SEGSRC']), (REGB, B['WP4'])))
        for _ in range(kx):
            b.e(add_(ADD_ADD, A['SEGSRC'], areg(A['SEGSRC']), (REGB, B['C4'])))
        b.e(add_or(A['TMP'], areg(A['SEGSRC']), areg(A['SEGSRC'])))
        p.emit(ldi(Cin // 16, A['KB'], ws=0))          # compile-time ci blocks
        b.e(nop(), nop())
        p.label('cib%d' % s)
        b.e(add_or(W_VPR_SETUP, areg(A['VDRW']), areg(A['VDRW'])))
        b.e(add_or(W_VPR_SETUP, areg(A['VDRS']), areg(A['VDRS'])))
        b.e(add_or(W_VPR_ADDR, areg(A['TMP']), areg(A['TMP'])))
        b.e(add_or(W_NOP, areg(50), areg(50)))                   # vpr_wait
        b.e(add_or(W_VPW_SETUP, areg(A['VDWW']), areg(A['VDWW']), ws=1))
        b.e(add_or(W_VPW_SETUP, areg(A['VDWS']), areg(A['VDWS']), ws=1))
        b.e(add_or(W_VPW_ADDR, areg(A['DST']), areg(A['DST']), ws=1))
        b.e(add_or(W_NOP, (REGB, R_VPW_WAIT), (REGB, R_VPW_WAIT)))
        b.e(add_(ADD_ADD, A['TMP'], areg(A['TMP']), (REGB, B['P16'])))
        b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), (REGB, B['DKB'])))
        b.e(add_(ADD_ADD, A['KB'], (REGB, B['NEG1']), areg(A['KB']), sf=1))
        p.branch_to('cib%d' % s, cond=BR_ALL_Z_CLEAR)
        b.e(nop(), nop(), nop())
    # next row block
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), (REGB, B['ST'])))
    b.e(add_(ADD_ADD, A['DSTP'], areg(A['DSTP']), (REGB, B['DRB'])))
    b.e(add_(ADD_ADD, A['CNT'], (REGB, B['NEG1']), areg(A['CNT']), sf=1))
    p.branch_to('rb', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# =============================================================== col2im
def _read_uni_b(b, dst):
    """Read the next uniform word into a B-file register."""
    b.e(dict(add_op=ADD_OR, add_out=dst, ws=1,
             add_a=areg(R_UNIF), add_b=areg(R_UNIF)))
    b.e(nop(), nop())


def _tmu_issue(b, tmu, addr_reg):
    """Issue one TMU request and hold the address register for two words."""
    b.e(add_or(W_TMU0_S if tmu == 0 else W_TMU1_S,
               areg(addr_reg), areg(addr_reg), ws=1))
    b.e(nop(), nop())


def _tmu_load(b, tmu, addr_reg, dst):
    """One serialised TMU load: issue, wait 8 words, pop into dst.

    dst < 6 is an accumulator (rN); dst >= 6 is an A-file register.
    """
    sig = SIG_LOAD_TMU0 if tmu == 0 else SIG_LOAD_TMU1
    b.e(add_or(W_TMU0_S if tmu == 0 else W_TMU1_S,
               areg(addr_reg), areg(addr_reg), ws=1))
    b.e(nop(), nop(), nop(), nop(), nop(), nop(), nop(), nop())
    b.e(alu(sig=sig, cond_add=COND_NEVER, cond_mul=COND_NEVER))
    if dst < 6:
        b.e(add_or(32 + dst, acc(4), acc(4)))
    else:
        b.e(add_or(dst, acc(4), acc(4)))


def _store4(b, vpmq4, vpmq9, dst_reg, stride, base=0):
    """The verified 4-row VPM->DMA store (emit_store16, one chunk).

    Writes four A-file vectors A[base..base+3] into VPM rows [4q..4q+3]
    (already filled) and DMA-stores them to four consecutive 64 B rows at
    dst_reg, `stride` bytes between rows (0 = contiguous).  A QPU's VPM
    slice is only four rows wide, so a second chunk (nvec=8) reuses the same
    rows with base=4, exactly like emit_store16's four chunks.
    """
    b.e(ldi(0x1A00, R5, ws=1))
    b.e(dict(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
             add_a=acc(5), add_b=breg(vpmq4)))
    for r in range(4):
        b.e(add_or(W_VPM, areg(base + r), areg(base + r)))
    b.e(ldi((2 << 30) | (4 << 23) | (16 << 16) | (1 << 14), R5, ws=1))
    b.e(dict(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
             add_a=acc(5), add_b=breg(vpmq9)))
    b.e(ldi(0xC0010000 | (stride & 0xFFFF), W_VPW_SETUP, ws=1))
    b.e(add_or(W_VPW_ADDR, areg(dst_reg), areg(dst_reg), ws=1))
    b.e(add_or(W_NOP, breg(R_VPW_WAIT), breg(R_VPW_WAIT)))
    b.e(nop(), nop(), nop(), nop())


def build_col2im(Cin, K, KH, KW, Wp, Hp):
    """Scatter-add the im2col gradient back into the padded input image.

    One QPU = one (row-block, channel-block) task; no loop, no branch.  The
    host launches ceil(tasks/12) times (the softmax kernel's shape).

    The forward im2col panel is PANEL[(rb*K + k)*16 + r] = A[rb*16+r][k] with
    k = tap*Cin + ci.  conv's dX is dXpad[ci][d] = sum_tap dA[d-tap_off][k].
    For one tap the 16 source pixels are contiguous, shifted by kx, so each
    (channel, tap) row is one 64 B gather; kx != 0 makes lane L < kx read the
    previous 16-pixel block (one AND with a per-lane mask).

    Each task owns a disjoint 16x16 destination block and accumulates the taps
    in fixed order in registers, then stores once (the verified 4-chunk store).
    Deterministic, no read-modify-write, no cross-QPU accumulation.

    ABI: u0 panel task base, u1 destination block base, u2 qpu index.
    compile-time: Cin, K, KH, KW, Wp, Hp
    """
    assert Cin % 16 == 0 and K == Cin * KH * KW, "col2im expects K = Cin*KH*KW"
    assert Wp % 16 == 0
    taps = KH * KW
    K64 = 64 * K
    plane = Hp * Wp * 4

    ACC = [0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    A_PANEL, A_DST, A_QID, A_ADDR, A_RB, A_LANE = 17, 18, 19, 20, 21, 22
    A_DC = 23
    B_DELTA, B_64, B_OFF, B_4PL, B_V4, B_V9, B_L4 = 0, 1, 2, 3, 4, 5, 6
    B_M1, B_M2 = 7, 8

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))                    # tmu_noswap
    b.read_uni(A_PANEL)
    b.read_uni(A_DST)
    b.read_uni(A_QID)

    b.e(add_or(A_LANE, areg(R_ELEM_NUM), areg(R_ELEM_NUM)), nop())
    b.e(add_(ADD_SHL, 32 + 0, areg(A_LANE), imm(2)))           # lane*4
    b.e(add_or(B_L4, ws=1, a=acc(0), b=acc(0)))
    b.e(ldi((64 - K64) & 0xFFFFFFFF, B_DELTA, ws=1))
    b.e(ldi(64, B_64, ws=1))
    b.e(ldi(4 * plane, B_4PL, ws=1))
    for kx, reg in ((1, B_M1), (2, B_M2)):
        b.e(add_(ADD_SUB, 32 + 0, areg(A_LANE), imm(kx)))
        b.e(add_(ADD_ASR, 32 + 0, acc(0), imm(31)))
        b.e(add_(ADD_AND, reg, ws=1, a=acc(0), b=breg(B_DELTA)))
    b.e(add_(ADD_SHL, B_V4, ws=1, a=areg(A_QID), b=imm(2)))    # 4q
    b.e(add_(ADD_SHL, B_V9, ws=1, a=areg(A_QID), b=imm(9)))    # 4q<<7
    b.e(nop(), nop())

    p._builder = b
    for r in ACC:
        b.e(add_or(r, imm(0), imm(0)))
    b.e(add_or(A_RB, areg(A_PANEL), areg(A_PANEL)))
    b.e(add_or(A_DC, areg(A_DST), areg(A_DST)))
    b.e(nop(), nop())

    for s in range(taps):
        ky, kx = divmod(s, KW)
        off = s * Cin * 64 - ky * (Wp // 16) * K64 - kx * 4
        b.e(ldi(off & 0xFFFFFFFF, B_OFF, ws=1))
        b.e(add_(ADD_ADD, A_ADDR, areg(A_RB), breg(B_OFF)))
        b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_L4)))
        if kx:
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR),
                     breg(B_M1 if kx == 1 else B_M2)))
        for _ in range(3):
            _tmu_issue(b, 0, A_ADDR)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_64)))
        b.e(nop(), nop(), nop())
        for c in range(16):
            b.e(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER))
            b.e(dict(add_op=ADD_FADD, add_out=ACC[c],
                     add_a=areg(ACC[c]), add_b=acc(4)))
            if c + 3 < 16:
                _tmu_issue(b, 0, A_ADDR)
                b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_64)))
            else:
                b.e(nop(), nop())
    # verified 4-chunk store: rows 12..15, 8..11, 4..7, 0..3 (memory ascending)
    for chunk in range(4):
        b.e(ldi(0x1A00, R5, ws=1))
        b.e(dict(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
                 add_a=acc(5), add_b=breg(B_V4)))
        for k in range(4):
            r = ACC[4 * chunk + k]
            b.e(add_or(W_VPM, areg(r), areg(r)))
        b.e(ldi((2 << 30) | (4 << 23) | (16 << 16) | (1 << 14), R5, ws=1))
        b.e(dict(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
                 add_a=acc(5), add_b=breg(B_V9)))
        b.e(ldi(0xC0010000 | ((plane - 64) & 0xFFFF), W_VPW_SETUP, ws=1))
        b.e(add_or(W_VPW_ADDR, areg(A_DC), areg(A_DC), ws=1))
        b.e(add_or(W_NOP, breg(R_VPW_WAIT), breg(R_VPW_WAIT)))
        b.e(nop(), nop(), nop(), nop())
        b.e(add_(ADD_ADD, A_DC, areg(A_DC), breg(B_4PL)))
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# ================================================= maxpool NxN / stride S (generic)
def build_pooln(N, S, Wp, op):
    """NxN max pool, stride S, on a host-padded [C][Hp][Wp] image.

    One task = 4 output rows x 16 output columns, so the store can reuse the
    verified 4-row VPM->DMA sequence.  The host builds the border (pad) with
    -inf, which is a byte-level copy: the kernel then has no bounds check, no
    loop and no branch.

    Lane L of a task is output column chunk*16+L; its window is
        rows 4*ry*S + j*S + ky,  columns chunk*16*S + L*S + kx.
    Four output rows share one task so `_store4`'s 4x64 B shape is used.

    ABI: u0 input base (row 4*ry*S, col chunk*16*S)
         u1 output base (row 4*ry, col chunk*16)
         u2 QPU index, u3 chunk
    compile-time: N, S, Wp (input row pitch in floats), op (output pitch)
    """
    assert N >= 1 and S >= 1 and op % 16 == 0

    b = Builder()
    p = b.p
    A_IN, A_OUT, A_Q, A_CHUNK = 17, 18, 19, 20
    A_LANE, A_ADDR, A_KY, A_TMP, A_SADR = 21, 22, 23, 24, 25
    A_V0 = 0

    B_W4, B_S4, B_OFF, B_V4, B_V9 = 0, 1, 2, 6, 7

    b.e(add_or(36, imm(1), imm(1)))                    # tmu_noswap
    b.read_uni(A_IN)
    b.read_uni(A_OUT)
    b.read_uni(A_Q)
    b.read_uni(A_CHUNK)
    b.e(add_or(A_LANE, areg(R_ELEM_NUM), areg(R_ELEM_NUM)), nop())
    b.e(ldi(Wp * 4, B_W4, ws=1))
    b.e(ldi(S * 4, B_S4, ws=1))
    b.e(add_(ADD_SHL, B_V4, ws=1, a=areg(A_Q), b=imm(2)))       # 4q
    b.e(add_(ADD_SHL, B_V9, ws=1, a=areg(A_Q), b=imm(9)))       # 4q<<7
    b.e(add_(ADD_SHL, 32 + 0, areg(A_CHUNK), imm(6 + (S.bit_length() - 1))))
    #                                                   chunk*S*16*4 = chunk*S*64
    b.e(add_(ADD_ADD, A_ADDR, areg(A_IN), acc(0)))
    b.e(add_(ADD_SHL, 32 + 0, areg(A_LANE), imm(2 + (S.bit_length() - 1))))
    #                                                   lane*S*4
    b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), acc(0)), nop(), nop())

    p._builder = b
    for j in range(4):
        if j:
            # one output row = S input rows (A_ADDR advances cumulatively)
            b.e(ldi(S * Wp * 4, B_OFF, ws=1))
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_OFF)), nop(), nop())
        for ky in range(N):
            # A_KY = A_ADDR + ky*Wp*4
            if ky == 0:
                b.e(add_or(A_KY, areg(A_ADDR), areg(A_ADDR)), nop(), nop())
            else:
                b.e(ldi(ky * Wp * 4, B_OFF, ws=1))
                b.e(add_(ADD_ADD, A_KY, areg(A_ADDR), breg(B_OFF)), nop(), nop())
            b.e(add_or(A_TMP, areg(A_KY), areg(A_KY)), nop(), nop())
            for kx in range(N):
                # first load of the row seeds the running max
                _tmu_load(b, 0, A_TMP, 0 if (ky == 0 and kx == 0) else 1)
                if kx == 0 and ky == 0:
                    pass
                else:
                    b.e(add_(ADD_FMAX, 32 + 0, acc(0), acc(1)))
                if kx != N - 1:
                    b.e(add_(ADD_ADD, A_TMP, areg(A_TMP), imm(4)))
                    b.e(nop(), nop())
        b.e(add_or(A_V0 + j, acc(0), acc(0)), nop(), nop())

    b.e(add_or(A_SADR, areg(A_OUT), areg(A_OUT)))
    _store4(b, B_V4, B_V9, A_SADR, op * 4 - 64)

    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# =============================================================== maxpool 2x2/2
def build_pool(H, W, op, mode):
    """2x2 stride-2 max pool ('fwd') and its argmax-mask backward ('bwd').

    One QPU = one task of FOUR 64 B rows (4 output rows forward, 4 input rows
    backward).  Computing four rows at once lets the kernel use the verified
    4-row VPM->DMA store (emit_store16's shape) instead of an unproven
    single-row DMA.  No loop, no branch; the host enumerates the tasks.

      fwd: out[c][y][x0..x0+15] = max of the 2x2 group; lanes past Wo are 0.
      bwd: dx[c][i][x] = dy[c][i/2][x/2] at the group maximum (ties share).

    Forward ABI: u0 input group base (row 4*ry), u1 output base (row 4*ry),
                 u2 q, u3 chunk
    Backward ABI: u0 pair-row base (row 4*r), u1 own-row base (row 4*r),
                  u2 q, u3 dy base (row 2*r), u4 chunk, u5 dx base (row 4*r)
    compile-time: H, W, op, mode
    """
    Ho, Wo = H // 2, W // 2
    assert W % 2 == 0 and H % 2 == 0

    b = Builder()
    p = b.p
    A_IN, A_OUT, A_Q, A_CHUNK = 17, 18, 19, 20
    A_LANE, A_ADDR, A_MASK, A_OWN, A_VAL = 21, 22, 23, 24, 25
    A_SADR, A_MX, A_DY, A_DX = 26, 27, 16, 28
    A_V0, A_T1, A_T2, A_T3 = 0, 13, 14, 15
    A_OWNAD, A_DYAD = 29, 30

    B_L4, B_L8, B_L24, B_CWM, B_C64, B_C32, B_V4, B_V9 = \
        0, 1, 2, 3, 4, 5, 6, 7
    B_OM1 = 9

    b.e(add_or(36, imm(1), imm(1)))                    # tmu_noswap
    b.read_uni(A_IN)
    b.read_uni(A_OUT)
    b.read_uni(A_Q)
    if mode == 'fwd':
        b.read_uni(A_CHUNK)                            # u3
    else:
        b.read_uni(A_DY)                               # u3
        b.read_uni(A_CHUNK)                            # u4
        b.read_uni(A_DX)                               # u5
    b.e(add_or(A_LANE, areg(R_ELEM_NUM), areg(R_ELEM_NUM)), nop())
    for sh, dst in ((2, B_L4), (3, B_L8)):
        b.e(add_(ADD_SHL, 32 + 0, areg(A_LANE), imm(sh)))
        b.e(add_or(dst, ws=1, a=acc(0), b=acc(0)))
    b.e(add_(ADD_SHR, 32 + 0, areg(A_LANE), imm(1)))
    b.e(add_(ADD_SHL, 32 + 0, acc(0), imm(2)))
    b.e(add_or(B_L24, ws=1, a=acc(0), b=acc(0)))
    b.e(ldi(W * 4 - 4, B_CWM, ws=1))
    b.e(ldi(64, B_C64, ws=1))
    b.e(ldi(32, B_C32, ws=1))
    b.e(add_(ADD_SHL, B_V4, ws=1, a=areg(A_Q), b=imm(2)))      # 4q
    b.e(add_(ADD_SHL, B_V9, ws=1, a=areg(A_Q), b=imm(9)))      # 4q<<7

    if mode == 'fwd':
        b.e(nop(), nop())
        # active mask: lane < Wo - chunk*16
        b.e(add_(ADD_SHL, 32 + 0, areg(A_CHUNK), imm(4)))      # chunk*16
        b.e(add_(ADD_SUB, 32 + 1, imm(Wo - 1), acc(0)))
        b.e(add_(ADD_SUB, 32 + 0, acc(1), areg(A_LANE)))
        b.e(add_(ADD_ASR, 32 + 0, acc(0), imm(31)))
        b.e(add_(ADD_NOT, A_MASK, acc(0), acc(0)))
        b.e(nop(), nop())
        p._builder = b
        for j in range(4):
            # group base = u0 + j*2*W*4 + chunk*128 + lane*8
            b.e(add_(ADD_SHL, 32 + 0, areg(A_CHUNK), imm(7)))  # chunk*128
            b.e(add_(ADD_ADD, A_ADDR, areg(A_IN), acc(0)))
            if j:
                b.e(ldi(j * 2 * W * 4, B_C64, ws=1))
                b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_C64)))
                b.e(ldi(64, B_C64, ws=1))
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_L8)))
            _tmu_load(b, 0, A_ADDR, 0)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), imm(4)))
            _tmu_load(b, 0, A_ADDR, 1)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_CWM)))
            _tmu_load(b, 0, A_ADDR, 2)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), imm(4)))
            _tmu_load(b, 0, A_ADDR, 3)
            # r4 is the TMU result register (the ALU cannot write it): keep
            # the running max in r0 after consuming the four loads.
            b.e(add_(ADD_FMAX, 32 + 0, acc(0), acc(1)))
            b.e(add_(ADD_FMAX, 32 + 0, acc(0), acc(2)))
            b.e(add_(ADD_FMAX, 32 + 0, acc(0), acc(3)))
            b.e(add_(ADD_AND, 32 + j, acc(0), areg(A_MASK)))
            b.e(add_or(A_V0 + j, acc(j), acc(j)))
            b.e(nop(), nop())
        b.e(add_or(A_SADR, areg(A_OUT), areg(A_OUT)))
        _store4(b, B_V4, B_V9, A_SADR, op * 4 - 64)
    else:
        assert mode == 'bwd'
        b.e(nop(), nop())
        p._builder = b
        for j in range(4):
            # own: u1 + j*W*4 + lane*4
            b.e(add_or(A_OWNAD, areg(A_OUT), areg(A_OUT)))
            if j:
                b.e(ldi(j * W * 4, B_C64, ws=1))
                b.e(add_(ADD_ADD, A_OWNAD, areg(A_OWNAD), breg(B_C64)))
                b.e(ldi(64, B_C64, ws=1))
            b.e(add_(ADD_ADD, A_OWNAD, areg(A_OWNAD), breg(B_L4)))
            # dy: u3 + (j/2)*op*4 + chunk*32 + (lane/2)*4
            b.e(add_(ADD_SHL, 32 + 0, areg(A_CHUNK), imm(5)))
            b.e(add_(ADD_ADD, A_DYAD, areg(A_DY), acc(0)))
            if j >= 2:
                b.e(ldi(op * 4, B_C32, ws=1))
                b.e(add_(ADD_ADD, A_DYAD, areg(A_DYAD), breg(B_C32)))
                b.e(ldi(32, B_C32, ws=1))
            b.e(add_(ADD_ADD, A_DYAD, areg(A_DYAD), breg(B_L24)))
            # group: u0 + (j&~1)*W*4 + chunk*64 + (lane&~1)*4
            b.e(add_(ADD_SHL, 32 + 0, areg(A_CHUNK), imm(6)))
            b.e(add_(ADD_ADD, A_ADDR, areg(A_IN), acc(0)))
            if j >= 2:
                b.e(ldi(2 * W * 4, B_C64, ws=1))
                b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_C64)))
                b.e(ldi(64, B_C64, ws=1))
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_L4)))
            b.e(ldi(0xFFFFFFFB, B_OM1, ws=1))
            b.e(add_(ADD_AND, A_ADDR, areg(A_ADDR), breg(B_OM1)))
            _tmu_load(b, 0, A_ADDR, A_MX)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), imm(4)))
            _tmu_load(b, 0, A_ADDR, A_T1)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_CWM)))
            _tmu_load(b, 0, A_ADDR, A_T2)
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), imm(4)))
            _tmu_load(b, 0, A_ADDR, A_T3)
            b.e(add_or(32 + 0, areg(A_T1), areg(A_T1)))
            b.e(add_or(32 + 1, areg(A_T2), areg(A_T2)))
            b.e(add_or(32 + 2, areg(A_T3), areg(A_T3)))
            b.e(nop(), nop())
            b.e(add_(ADD_FMAX, A_MX, areg(A_MX), acc(0)))
            b.e(add_(ADD_FMAX, A_MX, areg(A_MX), acc(1)))
            b.e(add_(ADD_FMAX, A_MX, areg(A_MX), acc(2)))
            _tmu_load(b, 0, A_OWNAD, A_OWN)
            _tmu_load(b, 0, A_DYAD, A_VAL)
            b.e(add_or(32 + 0, areg(A_MX), areg(A_MX)))
            b.e(nop(), nop())
            b.e(add_(ADD_XOR, 32 + 1, areg(A_OWN), acc(0)))
            b.e(add_(ADD_SUB, 32 + 2, imm(0), acc(1)))
            b.e(add_(ADD_OR, 32 + 1, acc(1), acc(2)))
            b.e(add_(ADD_SHR, 32 + 1, acc(1), imm(31)))
            b.e(add_(ADD_SUB, 32 + 1, acc(1), imm(1)))
            b.e(add_(ADD_AND, 32 + 3, areg(A_VAL), acc(1)))
            b.e(add_or(A_V0 + j, acc(3), acc(3)))
            b.e(nop(), nop())
        b.e(add_or(A_SADR, areg(A_DX), areg(A_DX)))
        _store4(b, B_V4, B_V9, A_SADR, W * 4 - 64)

    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# =============================================================== elementwise
OP_ADD, OP_MUL, OP_RELU, OP_SIGMOID, OP_SILU, OP_RELU_BWD, OP_RSQRT = 0, 1, 2, 3, 4, 5, 6
# FP32 comparison / predicate family (exact, IEEE bit tests; 0.0/1.0 output).
# Codes 7..99 are unused by the harness and by kops.py (100 = generic unary,
# 200 = generic binary/backward), so they are free for fixed bodies.
OP_CMP_EQ, OP_CMP_GT, OP_CMP_GE, OP_CMP_LT, OP_CMP_LE = 10, 11, 12, 13, 14
OP_ISNAN, OP_ISINF = 15, 16
OP_CMP_ALL = (OP_CMP_EQ, OP_CMP_GT, OP_CMP_GE, OP_CMP_LT, OP_CMP_LE, OP_ISNAN,
              OP_ISINF)

E_AB, E_BB, E_OB = 16, 17, 18
E_CNT, E_LANE = 19, 20
E_AA, E_AB2, E_AO = 21, 22, 23
E_TMP, E_VPMQ, E_AV, E_T8 = 24, 25, 26, 27
E_CADR = 28
E_T9, E_T10, E_T11 = 29, 30, 31

B_VB = 8
B_K = dict(C1=9, C2=10, C3=11, C4=12, C5=13, NLOG2E=14, MAGIC=15,
           CLAMP_LO=16, CLAMP_HI=17, ONE=18, TWO=19, RCPMAGIC=20,
           C4INT=21, STEP=22, VPMQ7=23, CSTEP=24, C16=25, ACOPY=26,
           QOFF=27, LOFF=28, GAP=29, HALF=27)


def _tmu_load_a(b, tmu, addr_reg, dst):
    """Serialised TMU load, popping into A-file register `dst` (0..31)."""
    sig = SIG_LOAD_TMU0 if tmu == 0 else SIG_LOAD_TMU1
    b.e(add_or(W_TMU0_S if tmu == 0 else W_TMU1_S,
               areg(addr_reg), areg(addr_reg), ws=1))
    b.e(nop(), nop(), nop(), nop(), nop(), nop(), nop(), nop())
    b.e(alu(sig=sig, cond_add=COND_NEVER, cond_mul=COND_NEVER))
    b.e(add_or(dst, acc(4), acc(4)))


def _tmu_load_b(b, tmu, addr_reg, dst):
    """Serialised TMU load, popping into B-file register `dst` (16..31)."""
    sig = SIG_LOAD_TMU0 if tmu == 0 else SIG_LOAD_TMU1
    b.e(add_or(W_TMU0_S if tmu == 0 else W_TMU1_S,
               areg(addr_reg), areg(addr_reg), ws=1))
    b.e(nop(), nop(), nop(), nop(), nop(), nop(), nop(), nop())
    b.e(alu(sig=sig, cond_add=COND_NEVER, cond_mul=COND_NEVER))
    b.e(add_or(dst, acc(4), acc(4), ws=1))


def build_im2col_nhwc(Cin, KH, KW, stride=1, vpitch=1, dilation=1):
    """K-major GEMM panel straight from a zero-padded NHWC image.

    One row block = 16 consecutive OUTPUT pixels of one output row, so the
    source pixels of one tap are 16 words at a constant step of
    stride*Cin*4 bytes - the VDR pitch.  The VDR loads [pixel][channel] into
    the VPM and the vertical VDW stores it transposed, giving the panel block
    PANEL[(rb*K + tap*Cin + ci)*16 + p] directly.

    Per row block the kernel unrolls the KH*KW taps at generation time and
    loops over the Cin/16 channel blocks; nx (16-pixel blocks per row) and the
    rows per QPU are uniforms, so one blob serves every spatial size.

    ``stride`` decimates on the QPU: the VDR reads 16 output pixels whose
    source pixels are ``stride`` apart (pitch ``stride*Cin*4``) and the row
    advance is ``stride`` input rows, so a stride-2 conv uses the plain
    kernel - no phase images.  ``dilation`` (compile-time, 1..4) spaces the
    taps of one kernel row by ``dilation`` pixels and the kernel rows by
    ``dilation`` input rows.

    KERNEL ABI (u0..u10)
      u0 src base bus                       u1 panel base bus
      u2 src 16-pixel block step (16*stride*Cin*4)
      u3 dst panel block step (64*nk)
      u4 output rows for this QPU
      u5 source offset of the first row  (y0*stride*row_pitch)
      u6 panel offset of the first block (y0*nx*64*nk)
      u7 VDR pitch (stride*Cin*4)           u8 QPU index
      u9 padded-image row stride            u10 nx (blocks per row)
      u11 source advance per output row (stride*row stride)
      u12 pixel step in bytes (Cin_pitch*4*dilation)
    """
    assert Cin % 16 == 0
    nseg = KH * KW
    A = dict(SRCB=16, PB=17, SRC=18, SEG0=19, DSTX=20, DSTB=21,
             CNT=22, TMP=23, VDRW=24, VDWW=25, VDRS=26, VDWS=27,
             Q=28, KB=29, XCNT=30, SEGSRC=31)
    B = dict(C4=16, BLK=17, DBLK=18, PIT=19, PLANE=20, C64=21, D1K=22,
             SOFF=23, DOFF=24, NX=25, T=26, RADV=27)

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))                     # tmu_noswap
    b.read_uni(A['SRCB'])                               # u0
    b.read_uni(A['PB'])                                 # u1
    b.read_uni(B['BLK'], ws=1)                          # u2
    b.read_uni(B['DBLK'], ws=1)                         # u3
    b.read_uni(A['CNT'])                                # u4
    b.read_uni(B['SOFF'], ws=1)                         # u5
    b.read_uni(B['DOFF'], ws=1)                         # u6
    b.read_uni(B['PIT'], ws=1)                          # u7
    b.read_uni(A['Q'])                                  # u8
    b.read_uni(B['PLANE'], ws=1)                        # u9
    b.read_uni(B['NX'], ws=1)                           # u10
    b.read_uni(B['RADV'], ws=1)                         # u11 stride*row_pitch
    b.read_uni(B['C4'], ws=1)                           # u12 pixel step*dil

    b.e(ldi(V.vdr_basic(0, vpitch), A['VDRW']), nop())
    b.e(ldi(V.vdw_basic(0, 16, 16, horizontal=0), A['VDWW']), nop())
    b.e(add_(ADD_SHL, B['T'], ws=1, a=areg(A['Q']), b=imm(8)))
    b.e(add_(ADD_ADD, A['VDRW'], areg(A['VDRW']), breg(B['T'])), nop())
    b.e(add_(ADD_SHL, B['T'], ws=1, a=areg(A['Q']), b=imm(11)))
    b.e(add_(ADD_ADD, A['VDWW'], areg(A['VDWW']), breg(B['T'])), nop())
    b.e(ldi(V.vdr_stride(0) & ~0xFFF, A['TMP']), nop())
    b.e(add_(ADD_ADD, A['VDRS'], areg(A['TMP']), breg(B['PIT'])), nop())
    b.e(ldi(V.vdw_stride(0), A['VDWS']), nop())
    b.e(ldi(64, B['C64'], ws=1), nop())
    b.e(ldi(1024, B['D1K'], ws=1), nop())
    # u12 is the per-kx pixel step: Cin_pitch*4*dilation.  It is a uniform,
    # not a constant, because a grouped conv reads Cin/groups of the
    # Cin_pitch channels that a pixel actually stores.
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRCB']), breg(B['SOFF'])), nop())
    b.e(add_(ADD_ADD, A['DSTX'], areg(A['PB']), breg(B['DOFF'])), nop(), nop())

    p.label('row')
    b.e(add_or(A['SEG0'], areg(A['SRC']), areg(A['SRC'])), nop())
    b.e(add_or(A['XCNT'], breg(B['NX']), breg(B['NX'])), nop(), nop())
    p.label('xb')
    b.e(add_or(A['DSTB'], areg(A['DSTX']), areg(A['DSTX'])), nop(), nop())
    for s in range(nseg):
        ky, kx = divmod(s, KW)
        b.e(add_or(A['SEGSRC'], areg(A['SEG0']), areg(A['SEG0'])), nop())
        for _ in range(ky * dilation):
            b.e(add_(ADD_ADD, A['SEGSRC'], areg(A['SEGSRC']), breg(B['PLANE'])))
        for _ in range(kx):
            b.e(add_(ADD_ADD, A['SEGSRC'], areg(A['SEGSRC']), breg(B['C4'])))
        b.e(add_or(A['TMP'], areg(A['SEGSRC']), areg(A['SEGSRC'])), nop(), nop())
        p.emit(ldi(Cin // 16, A['KB']))
        b.e(nop(), nop())
        p.label('cib%d' % s)
        b.e(add_or(W_VPR_SETUP, areg(A['VDRW']), areg(A['VDRW'])))
        b.e(add_or(W_VPR_SETUP, areg(A['VDRS']), areg(A['VDRS'])))
        b.e(add_or(W_VPR_ADDR, areg(A['TMP']), areg(A['TMP'])))
        b.e(add_or(W_NOP, areg(50), areg(50)))              # vpr_wait
        b.e(add_or(W_VPW_SETUP, areg(A['VDWW']), areg(A['VDWW']), ws=1))
        b.e(add_or(W_VPW_SETUP, areg(A['VDWS']), areg(A['VDWS']), ws=1))
        b.e(add_or(W_VPW_ADDR, areg(A['DSTB']), areg(A['DSTB']), ws=1))
        b.e(add_or(W_NOP, breg(R_VPW_WAIT), breg(R_VPW_WAIT)))  # vpw_wait
        b.e(add_(ADD_ADD, A['TMP'], areg(A['TMP']), breg(B['C64'])))
        b.e(add_(ADD_ADD, A['DSTB'], areg(A['DSTB']), breg(B['D1K'])))
        b.e(add_(ADD_SUB, A['KB'], areg(A['KB']), imm(1), sf=1))
        p.branch_to('cib%d' % s, cond=BR_ALL_Z_CLEAR)
        b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, A['SEG0'], areg(A['SEG0']), breg(B['BLK'])))
    b.e(add_(ADD_ADD, A['DSTX'], areg(A['DSTX']), breg(B['DBLK'])))
    b.e(add_(ADD_SUB, A['XCNT'], areg(A['XCNT']), imm(1), sf=1))
    p.branch_to('xb', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), breg(B['RADV'])))
    b.e(add_(ADD_SUB, A['CNT'], areg(A['CNT']), imm(1), sf=1))
    p.branch_to('row', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_im2col_nhwc_flat2(Cin, KH, KW, stride=1, dilation=1):
    """Flat-panel im2col: 16 flat output pixels per block, four 4-pixel groups.

    The row-padded panel pass (`build_im2col_nhwc`) reads 16 consecutive
    output pixels of one row per block, so a layer whose output width is not a
    multiple of 16 pays for the pad pixels in every row: at 160x160 the
    model's 64 conv layers run 33,952 panel rows for 26,352 real pixels.  This
    kernel keeps the 16-pixel block but takes its pixels from the *flat*
    output plane, so the panel has `align16(ho * align4(wo))` rows instead.

    A block is four groups of four consecutive pixels of one padded row: the
    output width is rounded to `align4(wo)` and a group of four can never
    straddle a row.  Each group is one 4-row VDR at the pixel pitch, writing
    VPM rows `4*g .. 4*g+3`, so the four groups fill the 16 rows that the
    panel's own transposing store reads: one 16 x 16 VDW with a zero stride,
    the word the row kernel already stores with.  No new store shape is used,
    and the four loads are the only new VPM shape.  A running group counter
    walks the row and adds the row adjustment at the wrap; there is no divide.

    KERNEL ABI (u0..u13)
      u0  src base bus                    u1  panel base bus
      u2  group advance bytes (4*stride*Cin_pitch*4)
      u3  panel block advance (64*nk)
      u4  real groups this QPU may process
      u5  source offset of the first group
      u6  panel offset of the first block
      u7  VDR pitch (stride*Cin_pitch*4)
      u8  QPU index                       u9  padded row pitch bytes
      u10 groups per row (Wf/4)           u11 row wrap (RADV - GPR*GADV)
      u12 pixel step bytes (Cin_pitch*4*dilation)
      u13 groups left in the first row
      compile-time: Cin, KH, KW, stride, dilation

    The host owns the two derived values: `SOFF` is
    `y0*stride*row_pitch + x0*stride*C4` for the first group, and
    `GCNT0 = GPR - x0/4`.  Blocks are contiguous per QPU, so the real-group
    count ends the kernel.  The last block's pad groups are still loaded and
    stored: the store writes panel words for pixels the GEMM never keeps, and
    the loads over-read at most 12 pixels past the plane, the same order as
    the row kernel's 15-pixel pad read at the end of a row.

    SILICON STATUS (2026-11-23): the panel is exact with one QPU on it and
    corrupt with the committed four-QPU split.  One QPU reproduces the
    schedule word for word (13,600/13,600 words on an 8x8x16 3x3 dump, and a
    5x5 conv to 9.8e-05), and a QPU given a distinct window produces its own
    tile, so the walk, the row fields, the store shape and the destination
    are right.  Four QPUs read later taps and other QPUs' sources.  That is
    not uniform staging (a probe reads each QPU's own 16 words back), not the
    store wait (a second wait changes nothing) and not the uniform count (the
    row kernel with 14 is exact across four).  The untested difference is
    four VPM loads before one store where every proven kernel issues one, so
    the next attempt should use a single 16-row load where the block lies in
    one output row (every layer whose align4(wo) is a multiple of 16) or keep
    one load in flight.  VC4_CONV_FLAT stays refused.
    """
    assert Cin % 16 == 0
    nseg = KH * KW
    ncb = Cin // 16
    # the channel-block loop leaves the group address at the last block's
    # base, so the per-tap step carries that back-step
    adj = Cin * 4 if ncb > 1 else 0

    A = dict(SRCB=16, PB=17, S0=18, S1=19, S2=20, S3=21,
             Q0=22, Q1=23, Q2=24, Q3=25, DSTX=26, DSTB=27,
             KB=0, GR=1, GCNT=2, QID=3, T=4,
             VDRW0=5, VDRW1=6, VDRW2=7, VDRW3=8,
             VDRS=9, VDWW=10, VDWS=11)
    B = dict(GADV=16, SOFF=17, DOFF=18, PIT=19, PLANE=20, GPR=21,
             ROWADJ=22, C4D=23, DBLK=24, STY=25, C64=26, D1K=27,
             ADJ=28, Q8=30, Q11=31)

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))                     # tmu_noswap
    for dst, ws in ((A['SRCB'], 0), (A['PB'], 0), (B['GADV'], 1),
                    (B['DBLK'], 1), (A['GR'], 0), (B['SOFF'], 1),
                    (B['DOFF'], 1), (B['PIT'], 1), (A['QID'], 0),
                    (B['PLANE'], 1), (B['GPR'], 1), (B['ROWADJ'], 1),
                    (B['C4D'], 1), (A['GCNT'], 0)):
        b.read_uni(dst, ws=ws)                          # u0..u13

    # VPM control words.  VDR: four pixels at the source pitch, four VPM rows,
    # group k starting at row 4*k of this QPU's 16-row window.  VDW: the
    # panel's own 16 k rows x 16 pixel words, transposing, zero stride.
    b.e(ldi(V.vdr_basic(0, 1, numrows=4, rowlen=16), A['VDRW0']))
    b.e(add_(ADD_SHL, B['Q8'], ws=1, a=areg(A['QID']), b=imm(8)))  # q<<8: row 16q
    b.e(add_(ADD_ADD, A['VDRW0'], areg(A['VDRW0']), breg(B['Q8'])))
    b.e(ldi(64, B['C64'], ws=1))
    b.e(add_(ADD_ADD, A['VDRW1'], areg(A['VDRW0']), breg(B['C64'])))
    b.e(add_(ADD_ADD, A['VDRW2'], areg(A['VDRW1']), breg(B['C64'])))
    b.e(add_(ADD_ADD, A['VDRW3'], areg(A['VDRW2']), breg(B['C64'])))
    b.e(ldi(V.vdr_stride(0) & ~0xFFF, A['T']))               # ID nibble only
    b.e(add_(ADD_ADD, A['VDRS'], areg(A['T']), breg(B['PIT'])))
    b.e(ldi(V.vdw_basic(0, 16, 16, horizontal=0), A['VDWW']))
    b.e(add_(ADD_SHL, B['Q11'], ws=1, a=areg(A['QID']), b=imm(11)))  # row 16q
    b.e(add_(ADD_ADD, A['VDWW'], areg(A['VDWW']), breg(B['Q11'])))
    b.e(ldi(V.vdw_stride(0), A['VDWS']))
    b.e(ldi(1024, B['D1K'], ws=1))

    # Tap walk of the four group addresses: within a kernel row the pixel
    # step, at a new kernel row the dilated row step less the KW-1 pixels the
    # walk already covered, both less the channel-block back-step.
    b.e(add_or(A['T'], breg(B['PLANE']), breg(B['PLANE'])))
    for _ in range(dilation - 1):
        b.e(add_(ADD_ADD, A['T'], areg(A['T']), breg(B['PLANE'])))
    for _ in range(KW - 1):
        b.e(add_(ADD_SUB, A['T'], areg(A['T']), breg(B['C4D'])))
    if adj:
        b.e(ldi(adj, B['ADJ'], ws=1))
        b.e(add_(ADD_SUB, A['T'], areg(A['T']), breg(B['ADJ'])))
    b.e(add_or(B['STY'], areg(A['T']), areg(A['T']), ws=1))

    b.e(add_or(A['S0'], areg(A['SRCB']), breg(B['SOFF'])))   # walk cursor
    b.e(add_or(A['DSTX'], areg(A['PB']), breg(B['DOFF'])))

    def step_group(src, dst):
        """One group on: dst = src + GADV, or + RADV when the row ends.

        Branch-free: the counter decrement sets the flags, and the wrap add
        and the counter reload both ride on the zero flag.  S0 is the walk
        cursor, so a block costs three steps to reach its four groups and one
        more at the end to reach the next block's first group.
        """
        b.e(add_(ADD_SUB, A['GCNT'], areg(A['GCNT']), imm(1), sf=1))
        b.e(add_(ADD_ADD, A[dst], areg(A[src]), breg(B['GADV'])))
        b.e(dict(add_op=ADD_ADD, add_out=A[dst], ws=0,
                 add_a=areg(A[dst]), add_b=breg(B['ROWADJ']),
                 cond_add=COND_ZERO_SET))
        b.e(dict(add_op=ADD_OR, add_out=A['GCNT'], ws=0,
                 add_a=breg(B['GPR']), add_b=breg(B['GPR']),
                 cond_add=COND_ZERO_SET))

    p.label('blk_top')
    step_group('S0', 'S1')
    step_group('S1', 'S2')
    step_group('S2', 'S3')
    for k in range(4):
        b.e(add_or(A['Q%d' % k], areg(A['S%d' % k]), areg(A['S%d' % k])))
    b.e(add_or(A['DSTB'], areg(A['DSTX']), areg(A['DSTX'])))
    for s in range(nseg):
        ky, kx = divmod(s, KW)
        if s:
            step = B['C4D'] if kx else B['STY']
            for k in range(4):
                b.e(add_(ADD_ADD, A['Q%d' % k], areg(A['Q%d' % k]),
                         breg(step)))
        if ncb > 1:
            b.e(ldi(ncb, A['KB']))
        p.label('cib%d' % s)
        for k in range(4):
            b.e(add_or(W_VPR_SETUP, areg(A['VDRW%d' % k]),
                       areg(A['VDRW%d' % k])))
            b.e(add_or(W_VPR_SETUP, areg(A['VDRS']), areg(A['VDRS'])))
            b.e(add_or(W_VPR_ADDR, areg(A['Q%d' % k]), areg(A['Q%d' % k])))
            b.e(add_or(W_NOP, areg(50), areg(50)))          # vpr_wait
        b.e(add_or(W_VPW_SETUP, areg(A['VDWW']), areg(A['VDWW']), ws=1))
        b.e(add_or(W_VPW_SETUP, areg(A['VDWS']), areg(A['VDWS']), ws=1))
        b.e(add_or(W_VPW_ADDR, areg(A['DSTB']), areg(A['DSTB']), ws=1))
        b.e(add_or(W_NOP, breg(R_VPW_WAIT), breg(R_VPW_WAIT)))
        # one k block on: the channel loop leaves the destination at the next
        # tap's first block, and with a single channel block there is no loop
        # to do it, so the advance belongs to every (tap, channel block)
        b.e(add_(ADD_ADD, A['DSTB'], areg(A['DSTB']), breg(B['D1K'])))
        if ncb > 1:
            b.e(add_(ADD_ADD, A['Q0'], areg(A['Q0']), breg(B['C64'])))
            b.e(add_(ADD_SUB, A['KB'], areg(A['KB']), imm(1), sf=1))
            p.branch_to('cib%d' % s, cond=BR_ALL_Z_CLEAR)
            for k in (1, 2, 3):         # delay slots: advance the other groups
                b.e(add_(ADD_ADD, A['Q%d' % k], areg(A['Q%d' % k]),
                         breg(B['C64'])))

    # Next block: the cursor reaches its first group.  GR is the real-group
    # count, so the kernel ends once the block leaves none; T = GR-5 is the
    # continue test (GR >= 5 groups before this block means one more block).
    step_group('S3', 'S0')
    b.e(add_(ADD_SUB, A['T'], areg(A['GR']), imm(5), sf=1))
    b.e(add_(ADD_SUB, A['GR'], areg(A['GR']), imm(4)))
    p.branch_to('blk_top', cond=BR_ALL_N_CLEAR)
    b.e(add_(ADD_ADD, A['DSTX'], areg(A['DSTX']), breg(B['DBLK'])), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_probe_seq(seq):
    """Diagnostic: one 16-lane vector in, the raw 16-lane result out.

    ``seq`` is ``<kind>_<nops>`` and names a minimal dependency sequence:
    one product, then a controllable number of nops, then the second
    operation.  It exists to measure the QPU write->read hazard for the
    multiply ALU without any other instruction in the way (docs/NUMERICS.md).

        acc_N      t = fmul(x,2) -> accumulator, N nops, y = fmul(t,3)
        bmov_N     t -> acc, 2 nops, add-mov -> B register, N nops, fmul(B,3)
        bmul_N     t = fmul(x,2) -> B register, N nops, fmul(B,3)
        amul_N     t = fmul(x,2) -> A register, N nops, fmul(A,3)
        add_N      t -> acc, N nops, y = fadd(t,1)
        packmul_N  first word packs fmul(x,2) with an independent fadd, N
                   nops, y = fmul(t,3)
        packfadd_N t -> acc, N nops, then one word packs fmul(t,3) with
                   fadd(t,1): both ALUs consume the product at the same time

    The result is replicated into all four store rows (the verified 4-row
    VPM->DMA store); the first 16 words are the answer.
    ABI: u0 a bus, u1 unused, u2 out bus.  One QPU.
    """
    A_IN, A_OUT, A_ADDR, A_T = 26, 27, 28, 16
    B_C2, B_C3, B_L4, B_V4, B_V9 = 0, 1, 2, 3, 4

    head, _, tail = seq.partition('_')
    n = int(tail) if tail else 0

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A_IN)                       # u0: source
    b.read_uni(A_T)                        # u1: unused (ABI stability)
    b.read_uni(A_OUT)                      # u2: destination
    b.e(ldi(0x40000000, B_C2, ws=1))       # 2.0
    b.e(ldi(0x40400000, B_C3, ws=1))       # 3.0
    b.e(ldi(0, B_V4, ws=1))
    b.e(ldi(0, B_V9, ws=1))
    b.e(add_(ADD_SHL, B_L4, ws=1, a=areg(R_ELEM_NUM), b=imm(2)))
    b.e(add_(ADD_ADD, A_ADDR, areg(A_IN), breg(B_L4)), nop())
    b.e(nop(), nop())
    _tmu_load_a(b, 0, A_ADDR, A_IN)

    b.check = False
    if head == 'exp2':
        # diagnostic: the 16 input lanes are t; out = core_exp2(t)
        import kops
        mod = sys.modules[__name__]
        mod._kops_consts = {}
        code = kops.UOP_ORDER.index('exp')
        kops.ew_consts(mod, b, code)
        ctx = kops.Ctx(mod._kops_consts[code])
        e = kops.E(mod, b, ctx)
        kops.core_exp2(e, A_IN, 0, ctx.tb(), ctx.tb())
        # B3/B4 were the store offsets, but ew_consts just overwrote them with
        # exp constants; use B30/B31 (free for a zero-parameter op)
        b.e(ldi(0, 30, ws=1))
        b.e(ldi(0, 31, ws=1))
        b.e(nop(), nop(), nop(), nop())
        _store4(b, 30, 31, A_OUT, 0)
        b.e(end_program())
        b.e(nop(), nop(), nop())
        return p
    if head == 'store':
        # diagnostic: four known rows through the verified _store4, no math
        for i, val in enumerate((0x3F800000, 0x40000000, 0x40400000,
                                 0x40800000)):
            b.e(ldi(val, 5 + i, ws=1))
            b.e(nop(), nop(), nop())
            b.e(add_or(i, breg(5 + i), breg(5 + i)), nop(), nop())
        _store4(b, B_V4, B_V9, A_OUT, 0)
        b.e(end_program())
        b.e(nop(), nop(), nop())
        return p
    if head == 'storeacc':
        # four rows produced through the E.mul path (mul -> ACC3 -> mov A_i)
        b.e(ldi(0x3F800000, 5, ws=0))     # A5 = 1.0
        b.e(nop(), nop(), nop())
        for i, val in enumerate((0x3F800000, 0x40000000, 0x40400000,
                                 0x40800000)):
            b.e(ldi(val, 7, ws=1))
            b.e(nop(), nop(), nop())
            b.e(dict(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0,
                     mul_a=breg(7), mul_b=areg(5)))
            b.e(nop(), nop())
            b.e(add_or(i, acc(3), acc(3)), nop(), nop())
        _store4(b, B_V4, B_V9, A_OUT, 0)
        b.e(end_program())
        b.e(nop(), nop(), nop())
        return p
    if head == 'pipe4':
        # the build_ew TMU pipeline for nvec=4, copy-only (no body)
        A_ADDR2 = 17
        B_C64 = 10
        b.e(ldi(64, B_C64, ws=1))
        b.e(nop(), nop(), nop())
        b.e(add_or(A_ADDR2, areg(A_ADDR), areg(A_ADDR)), nop(), nop())
        for _ in range(2):
            b.e(add_or(W_TMU0_S, areg(A_ADDR), areg(A_ADDR), ws=1))
            b.e(add_or(W_TMU1_S, areg(A_ADDR2), areg(A_ADDR2), ws=1))
            b.e(nop(), nop())
            b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_C64)))
            b.e(add_(ADD_ADD, A_ADDR2, areg(A_ADDR2), breg(B_C64)))
            b.e(nop(), nop())
        for j in range(4):
            if j + 2 < 4:
                b.e(add_or(W_TMU0_S, areg(A_ADDR), areg(A_ADDR), ws=1))
                b.e(add_or(W_TMU1_S, areg(A_ADDR2), areg(A_ADDR2), ws=1))
                b.e(nop(), nop())
                b.e(add_(ADD_ADD, A_ADDR, areg(A_ADDR), breg(B_C64)))
                b.e(add_(ADD_ADD, A_ADDR2, areg(A_ADDR2), breg(B_C64)))
                b.e(nop(), nop())
            b.e(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
            b.e(add_or(A_IN, acc(4), acc(4)), nop())
            b.e(alu(sig=SIG_LOAD_TMU1, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
            b.e(add_or(B_VB, ws=1, a=acc(4), b=acc(4)), nop())
            b.e(add_or(j, areg(A_IN), areg(A_IN)), nop(), nop())
        _store4(b, B_V4, B_V9, A_OUT, 0)
        b.e(end_program())
        b.e(nop(), nop(), nop())
        return p
    if head in ('acc', 'bmov', 'add', 'packfadd'):
        b.e(dict(mul_op=MUL_FMUL, mul_out=32 + 0, ws=0,
                 mul_a=areg(A_IN), mul_b=breg(B_C2)))
    elif head == 'packmul':
        # producer word: fmul plus an unrelated fadd, like the GEMM's packed
        # fmul+fadd (the add reads only the source, not the product)
        b.e(dict(mul_op=MUL_FMUL, mul_out=32 + 0, ws=0,
                 add_op=ADD_FADD, add_out=32 + 1,
                 mul_a=areg(A_IN), mul_b=breg(B_C2),
                 add_a=areg(A_IN), add_b=imm(1)))
    elif head == 'bmul':
        b.e(dict(mul_op=MUL_FMUL, mul_out=16, ws=0,
                 mul_a=areg(A_IN), mul_b=breg(B_C2)))
    elif head == 'amul':
        b.e(dict(mul_op=MUL_FMUL, mul_out=16, ws=1,
                 mul_a=areg(A_IN), mul_b=breg(B_C2)))
    else:
        raise ValueError('bad probe sequence %r' % seq)

    if head == 'bmov':
        b.e(nop(), nop())                  # the emitter's staging gap
        b.e(add_or(16, acc(0), acc(0), ws=1))   # acc -> B16
    for _ in range(n):
        b.e(nop())

    if head == 'add':
        b.e(dict(add_op=ADD_FADD, add_out=32 + 1,
                 add_a=acc(0), add_b=imm(1)))
    elif head == 'packfadd':
        b.e(dict(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0,
                 add_op=ADD_FADD, add_out=32 + 2,
                 mul_a=acc(0), mul_b=breg(B_C3),
                 add_a=acc(0), add_b=imm(1)))
    elif head in ('bmul', 'amul'):
        b.e(dict(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0,
                 mul_a=breg(16) if head == 'bmul' else areg(16),
                 mul_b=breg(B_C3)))
    else:
        b.e(dict(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0,
                 mul_a=acc(0), mul_b=breg(B_C3)))

    b.check = True
    b.e(add_or(0, acc(1), acc(1)))
    b.e(add_or(1, areg(0), areg(0)), nop(), nop())
    b.e(add_or(2, areg(0), areg(0)), nop(), nop())
    b.e(add_or(3, areg(0), areg(0)), nop(), nop())
    _store4(b, B_V4, B_V9, A_OUT, 0)
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p

def build_probe_lane():
    """Diagnostic: one TMU gather of 16 4-byte words at src + lane*4.

    The result is replicated into the four store rows so the destination shows
    the per-lane mapping of one gather (4 x 64 B at stride 0).
    """
    A = dict(SRC=16, DST=17, Q=18, KADDR=19)
    B = dict(V4=20, V9=21, L4=22)
    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A['SRC'])            # u0
    b.read_uni(A['DST'])            # u1
    b.read_uni(A['Q'])              # u2
    b.e(add_(ADD_SHL, B['L4'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)))
    b.e(add_(ADD_ADD, A['KADDR'], areg(A['SRC']), breg(B['L4'])), nop())
    _tmu_load_a(b, 0, A['KADDR'], 0)
    b.e(add_or(1, areg(0), areg(0)))
    b.e(add_or(2, areg(0), areg(0)))
    b.e(add_or(3, areg(0), areg(0)), nop(), nop())
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['Q']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['Q']), b=imm(9)))
    _store4(b, B['V4'], B['V9'], A['DST'], 0)
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_probe_lane_b():
    """Diagnostic: same gather, but popped into a B register (fmax path)."""
    A = dict(SRC=16, DST=17, Q=18, KADDR=19, VAL=20)
    B = dict(V4=21, V9=22, L4=23, BV=24)
    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A['SRC'])
    b.read_uni(A['DST'])
    b.read_uni(A['Q'])
    b.e(add_(ADD_SHL, B['L4'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)))
    b.e(add_(ADD_ADD, A['KADDR'], areg(A['SRC']), breg(B['L4'])), nop())
    _tmu_load_b(b, 0, A['KADDR'], B['BV'])
    b.e(add_or(A['VAL'], breg(B['BV']), breg(B['BV'])))
    b.e(add_or(0, areg(A['VAL']), areg(A['VAL'])))
    b.e(add_or(1, areg(A['VAL']), areg(A['VAL'])))
    b.e(add_or(2, areg(A['VAL']), areg(A['VAL'])))
    b.e(add_or(3, areg(A['VAL']), areg(A['VAL'])), nop(), nop())
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['Q']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['Q']), b=imm(9)))
    _store4(b, B['V4'], B['V9'], A['DST'], 0)
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_probe_pool(C):
    """Diagnostic: 8 column gathers + fmax + store (pool inner loop shape)."""
    A = dict(SRC=16, DST=17, Q=18, KADDR=19)
    B = dict(V4=24, V9=25, L4=26, C4=27)
    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A['SRC'])
    b.read_uni(A['DST'])
    b.read_uni(A['Q'])
    b.e(add_(ADD_SHL, B['L4'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)))
    b.e(ldi(C * 4, B['C4'], ws=1))
    b.e(add_(ADD_ADD, A['KADDR'], areg(A['SRC']), breg(B['L4'])), nop())
    for k in range(8):
        if k:
            b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['C4'])))
        _tmu_load_b(b, 0, A['KADDR'], 16 + k)
    for j in range(4):
        b.e(add_(ADD_OR, 32 + j, breg(16 + j), breg(16 + j)))
        for k in range(1, 5):
            b.e(add_(ADD_FMAX, 32 + j, acc(j), breg(16 + j + k)))
    for j in range(4):
        b.e(add_or(j, acc(j), acc(j)))
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['Q']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['Q']), b=imm(9)))
    _store4(b, B['V4'], B['V9'], A['DST'], 0)
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_depthwise_nhwc(C):
    """3x3 depthwise conv, NHWC, stride 1, from a zero-padded NHWC image.

    Lanes are the 16 channels of one channel block, so a tap is one coalesced
    64 B gather.  A group of four output pixels shares the six input columns
    of a row, so a group needs 18 loads (not 36) for 108 MACs; the four
    results leave through the verified 4-row VPM->DMA store.

    Weights are pre-permuted on the host to WP[tap][C] (tap = ky*3+kx), so the
    nine per-lane weight vectors are nine contiguous 64 B lines and are loaded
    once per task into A16..A24.

    KERNEL ABI (u0..u12)
      u0 src base bus (padded image)      u1 dst base bus
      u2 output rows for this QPU         u3 src first-row offset
      u4 dst first-row offset             u5 QPU index
      u6 pixel stride (C*4)               u7 src row stride
      u8 dst row stride                   u9 groups of 4 pixels per row
      u10 channel-block byte offset       u11 weight bus (this block)
      u12 weight tap stride (C*4)
    """
    assert C % 16 == 0
    A = dict(SRC=25, DST=26, SEG=27, DSTG=28, KADDR=29, CNT=30, XCNT=31)
    B = dict(C4=22, ROWSTR=23, DROWSTR=24, WSTR=25, V4=31, V9=27,
             G4=28, NX4=29, CBO=30, T=26)
    # A0..A3 store rows, A16..A24 weights, B16..B21 six input vectors

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(B['T'], ws=1)            # u0 src bus
    b.read_uni(B['WSTR'], ws=1)         # u1 dst bus (parked, overwritten)
    b.read_uni(A['CNT'])                # u2 rows
    b.read_uni(A['XCNT'])               # u3 src row offset
    b.read_uni(A['DSTG'])               # u4 dst row offset
    b.read_uni(A['SEG'])                # u5 q
    b.e(add_(ADD_ADD, A['SRC'], breg(B['T']), areg(A['XCNT'])), nop())
    b.e(add_(ADD_ADD, A['DST'], breg(B['WSTR']), areg(A['DSTG'])), nop())
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['SEG']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['SEG']), b=imm(9)))
    b.read_uni(A['SEG'])                # u6 pixel stride (A temp)
    b.e(add_(ADD_OR, B['C4'], areg(A['SEG']), areg(A['SEG']), ws=1), nop())
    b.e(add_(ADD_SHL, B['G4'], ws=1, a=areg(A['SEG']), b=imm(2)), nop())
    b.read_uni(B['ROWSTR'], ws=1)       # u7
    b.read_uni(B['DROWSTR'], ws=1)      # u8
    b.read_uni(B['NX4'], ws=1)          # u9
    b.read_uni(B['CBO'], ws=1)          # u10
    b.read_uni(A['KADDR'])              # u11 weight bus
    b.read_uni(B['WSTR'], ws=1)         # u12

    # per-lane TMU offset: lane L reads channel (cb*16 + L), i.e. base + L*4
    b.e(add_(ADD_SHL, B['T'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)), nop())
    if os.environ.get('KGEN_L4_CONST'):
        b.e(ldi(int(os.environ['KGEN_L4_CONST']), B['T'], ws=1), nop())
    b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['T'])), nop())
    for t in range(9):
        _tmu_load_a(b, 0, A['KADDR'], A['SEG'])
        b.e(add_or(16 + t, areg(A['SEG']), areg(A['SEG'])))
        if t != 8:
            b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['WSTR'])))

    p.label('row')
    b.e(add_(ADD_ADD, A['SEG'], areg(A['SRC']), breg(B['T'])), nop())
    b.e(add_(ADD_ADD, A['DSTG'], areg(A['DST']), breg(B['CBO'])), nop())
    b.e(add_or(A['XCNT'], breg(B['NX4']), breg(B['NX4'])), nop(), nop())
    p.label('grp')
    for ky in range(3):
        b.e(add_or(A['KADDR'], areg(A['SEG']), areg(A['SEG'])), nop())
        for _ in range(ky):
            b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['ROWSTR'])))
        for k in range(6):
            if k:
                b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['C4'])))
            _tmu_load_b(b, 0, A['KADDR'], 16 + k)
        for j in range(4):
            for kx in range(3):
                s = 16 + j + kx
                w = 16 + ky * 3 + kx
                if ky == 0 and kx == 0:
                    b.e(mul_fmul(j, areg(w), breg(s)))
                else:
                    # r4 is the TMU result register AND the TMU config latch:
                    # writing it (any mul into r4) changes the lane addressing
                    # of the following gathers, so the product goes to r5.
                    b.e(mul_fmul(5, areg(w), breg(s)))
                    b.e(nop())
                    b.e(add_(ADD_FADD, 32 + j, acc(j), acc(5)))
    for j in range(4):
        b.e(add_or(j, acc(j), acc(j)))
    _store4(b, B['V4'], B['V9'], A['DSTG'], C * 4 - 64)
    b.e(add_(ADD_ADD, A['SEG'], areg(A['SEG']), breg(B['G4'])))
    b.e(add_(ADD_ADD, A['DSTG'], areg(A['DSTG']), breg(B['G4'])))
    b.e(add_(ADD_SUB, A['XCNT'], areg(A['XCNT']), imm(1), sf=1))
    p.branch_to('grp', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), breg(B['ROWSTR'])))
    b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), breg(B['DROWSTR'])))
    b.e(add_(ADD_SUB, A['CNT'], areg(A['CNT']), imm(1), sf=1))
    p.branch_to('row', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_pool_nhwc(C, K):
    """KxK stride-1 max pool, NHWC, from a zero-padded NHWC image.

    SPPF-style (K=5, pad 2) as well as 3x3.  Lanes are 16 channels.  A group
    of four output pixels needs 4+K-1 input columns per row, so K=5 costs 40
    coalesced gathers for 100 fmax and one 4-row store.

    KERNEL ABI (u0..u10)
      u0 src base bus (padded image)  u1 dst base bus
      u2 output rows for this QPU     u3 src first-row offset
      u4 dst first-row offset         u5 QPU index
      u6 pixel stride (C*4)           u7 src row stride
      u8 dst row stride               u9 groups of 4 pixels per row
      u10 channel-block byte offset
    """
    A = dict(SRC=16, DST=17, SEG=18, DSTG=19, KADDR=20, CNT=21, XCNT=22,
             NX4=23)
    B = dict(C4=24, ROWSTR=25, DROWSTR=26, G4=27, L4=28, CBO=29,
             V4=30, V9=31)
    # A0..A3 store rows, B16..B23 the 4+K-1 input vectors
    ncol = 4 + K - 1

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(B['V4'], ws=1)       # u0 src bus (parked in B30, overwritten)
    b.read_uni(B['V9'], ws=1)       # u1 dst bus (parked in B31, overwritten)
    b.read_uni(A['CNT'])            # u2 rows
    b.read_uni(A['XCNT'])           # u3 src row offset
    b.read_uni(A['DSTG'])           # u4 dst row offset
    b.read_uni(A['SEG'])            # u5 q
    b.e(add_(ADD_ADD, A['SRC'], breg(B['V4']), areg(A['XCNT'])), nop())
    b.e(add_(ADD_ADD, A['DST'], breg(B['V9']), areg(A['DSTG'])), nop())
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['SEG']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['SEG']), b=imm(9)))
    b.read_uni(A['KADDR'])          # u6 pixel stride (A temp; == last tap addr)
    b.e(add_(ADD_OR, B['C4'], areg(A['KADDR']), areg(A['KADDR']), ws=1), nop())
    b.e(add_(ADD_SHL, B['G4'], ws=1, a=areg(A['KADDR']), b=imm(2)), nop())
    b.read_uni(B['ROWSTR'], ws=1)   # u7
    b.read_uni(B['DROWSTR'], ws=1)  # u8
    b.read_uni(A['NX4'])            # u9 groups per row
    b.read_uni(B['CBO'], ws=1)      # u10 channel-block offset

    p.label('row')
    b.e(add_(ADD_SHL, B['L4'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)))
    b.e(add_(ADD_ADD, A['SEG'], areg(A['SRC']), breg(B['L4'])), nop())
    b.e(add_(ADD_ADD, A['DSTG'], areg(A['DST']), breg(B['CBO'])), nop())
    b.e(add_or(A['XCNT'], areg(A['NX4']), areg(A['NX4'])), nop(), nop())
    p.label('grp')
    for ky in range(K):
        b.e(add_or(A['KADDR'], areg(A['SEG']), areg(A['SEG'])), nop())
        for _ in range(ky):
            b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['ROWSTR'])))
        for k in range(ncol):
            if k:
                b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['C4'])))
            _tmu_load_b(b, 0, A['KADDR'], 16 + k)
        for j in range(4):
            if ky == 0:
                b.e(add_(ADD_OR, 32 + j, breg(16 + j), breg(16 + j)))
                for k in range(1, K):
                    b.e(add_(ADD_FMAX, 32 + j, acc(j), breg(16 + j + k)))
            else:
                for k in range(K):
                    b.e(add_(ADD_FMAX, 32 + j, acc(j), breg(16 + j + k)))
    for j in range(4):
        b.e(add_or(j, acc(j), acc(j)))
    _store4(b, B['V4'], B['V9'], A['DSTG'], C * 4 - 64)
    b.e(add_(ADD_ADD, A['SEG'], areg(A['SEG']), breg(B['G4'])))
    b.e(add_(ADD_ADD, A['DSTG'], areg(A['DSTG']), breg(B['G4'])))
    b.e(add_(ADD_SUB, A['XCNT'], areg(A['XCNT']), imm(1), sf=1))
    p.branch_to('grp', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), breg(B['ROWSTR'])))
    b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), breg(B['DROWSTR'])))
    b.e(add_(ADD_SUB, A['CNT'], areg(A['CNT']), imm(1), sf=1))
    p.branch_to('row', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_up2_nhwc(C):
    """Nearest-neighbour 2x upsample of a contiguous NHWC tensor.

    One task = a row-pair range.  Destination (y,x) <- source (y/2, x/2), so a
    group of four destination pixels is two source pixels stored twice; both
    destination rows of the pair are written from the same two gathers.

    KERNEL ABI (u0..u9)
      u0 src base bus                 u1 dst base bus
      u2 destination row pairs for this QPU
      u3 src first-row offset (y0/2 * src row stride)
      u4 dst first-row offset (y0 * dst row stride)
      u5 QPU index                    u6 pixel stride (C*4)
      u7 src row stride               u8 dst row stride
      u9 groups of 4 dst pixels per row
    """
    assert C % 16 == 0
    A = dict(SRC=16, DST=17, SGP=18, DGP=19, CNT=20, XCNT=21, KADDR=22,
             TMP=23)
    B = dict(C4=16, SROWSTR=17, DROWSTR=18, G4=19, NX4=20, SG2=21,
             V4=22, V9=23, T=24, T2=25, CBT=26, L4=27, LIM=28)

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(B['T'], ws=1)        # u0 src bus
    b.read_uni(B['T2'], ws=1)       # u1 dst bus
    b.read_uni(A['CNT'])            # u2 pairs
    b.read_uni(A['KADDR'])          # u3 src row offset
    b.read_uni(A['XCNT'])           # u4 dst row offset
    b.read_uni(A['DGP'])            # u5 q
    b.e(add_(ADD_ADD, A['SRC'], breg(B['T']), areg(A['KADDR'])), nop())
    b.e(add_(ADD_ADD, A['DST'], breg(B['T2']), areg(A['XCNT'])), nop())
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['DGP']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['DGP']), b=imm(9)))
    b.read_uni(A['TMP'])            # u6 pixel stride (A temp)
    b.e(add_(ADD_OR, B['C4'], areg(A['TMP']), areg(A['TMP']), ws=1), nop())
    b.e(add_(ADD_SHL, B['G4'], ws=1, a=areg(A['TMP']), b=imm(2)))
    b.e(add_(ADD_SHL, B['SG2'], ws=1, a=areg(A['TMP']), b=imm(1)), nop())
    b.read_uni(B['SROWSTR'], ws=1)  # u7
    b.read_uni(B['DROWSTR'], ws=1)  # u8
    b.read_uni(B['NX4'], ws=1)      # u9
    b.e(add_(ADD_SHL, B['L4'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)), nop())
    # The channel-block loop is a runtime loop, not an unrolled one: at C=512
    # the unrolled form was 21440 B against the 16384 B client code slot, and
    # the instruction sequence per block does not depend on the block index.
    # A['TMP'] becomes the 64 B step, B CBT the block's byte offset inside the
    # pixel and ACC2 the end offset: the ALU reads one A and one B register
    # per word, so a B-register address add needs both operands outside the A
    # file, and the compare against the end offset needs a staged value.
    b.e(ldi(C * 4, B['LIM'], ws=1))
    b.e(add_(ADD_OR, 34, breg(B['LIM']), breg(B['LIM'])), nop(), nop())
    b.e(ldi(64, A['TMP']))

    p.label('pair')
    # every row pair starts at channel block 0; the block loop leaves CBT at
    # C*4, and a QPU that handles several pairs must not start the next one
    # past the end of the pixel (the second pair then went unwritten)
    b.e(add_or(B['CBT'], imm(0), imm(0), ws=1))
    p.label('blk')
    b.e(add_(ADD_ADD, A['SGP'], areg(A['SRC']), breg(B['CBT'])))
    b.e(add_(ADD_ADD, A['DGP'], areg(A['DST']), breg(B['CBT'])))
    b.e(add_(ADD_ADD, A['SGP'], areg(A['SGP']), breg(B['L4'])), nop())
    b.e(add_or(A['XCNT'], breg(B['NX4']), breg(B['NX4'])), nop(), nop())
    p.label('grp')
    b.e(add_or(A['KADDR'], areg(A['SGP']), areg(A['SGP'])), nop())
    _tmu_load_a(b, 0, A['KADDR'], 0)
    b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['C4'])))
    _tmu_load_a(b, 0, A['KADDR'], 2)
    b.e(add_or(1, areg(0), areg(0)))
    b.e(add_or(3, areg(2), areg(2)), nop(), nop())
    _store4(b, B['V4'], B['V9'], A['DGP'], C * 4 - 64)
    b.e(add_(ADD_ADD, A['KADDR'], areg(A['DGP']), breg(B['DROWSTR'])))
    _store4(b, B['V4'], B['V9'], A['KADDR'], C * 4 - 64)
    b.e(add_(ADD_ADD, A['SGP'], areg(A['SGP']), breg(B['SG2'])))
    b.e(add_(ADD_ADD, A['DGP'], areg(A['DGP']), breg(B['G4'])))
    b.e(add_(ADD_SUB, A['XCNT'], areg(A['XCNT']), imm(1), sf=1))
    p.branch_to('grp', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, B['CBT'], breg(B['CBT']), areg(A['TMP']), ws=1))
    b.e(add_(ADD_SUB, A['KADDR'], breg(B['CBT']), acc(2), sf=1))
    p.branch_to('blk', cond=BR_ALL_N_SET)
    b.e(nop(), nop(), nop())
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), breg(B['SROWSTR'])))
    b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), breg(B['DROWSTR'])))
    b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), breg(B['DROWSTR'])))
    b.e(add_(ADD_SUB, A['CNT'], areg(A['CNT']), imm(1), sf=1))
    p.branch_to('pair', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def build_copy_nhwc(Csrc, Cdst):
    """Copy Csrc channels (Csrc/16 blocks) into a Cdst-channel NHWC tensor.

    Used for channel concat: one launch per source tensor, each task copies a
    range of 4-pixel groups.  A group is four coalesced 64 B gathers per
    channel block and one verified 4-row store.

    KERNEL ABI (u0..u7)
      u0 src base bus (+ pixel offset)  u1 dst base bus (+ pixel offset)
      u2 src pixel stride               u3 dst pixel stride
      u4 groups of 4 pixels for this QPU  u5 QPU index
      u6 src channel byte offset        u7 dst channel byte offset
    """
    assert Csrc % 16 == 0 and Cdst % 16 == 0
    nblk = Csrc // 16
    A = dict(SRC=16, DST=17, CNT=18, KADDR=19, DTMP=20, T=21, T2=22,
             T3=23, T4=24)
    B = dict(SRCPIX=16, DSTPIX=17, G4S=18, G4D=19, V4=20, V9=21, CBT=22,
             SCB=23, DCB=24, L4=25)

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(A['T'])              # u0 src bus
    b.read_uni(A['T2'])             # u1 dst bus
    b.read_uni(A['T3'])             # u2 src pixel stride
    b.read_uni(A['T4'])             # u3 dst pixel stride
    b.read_uni(A['CNT'])            # u4 groups
    b.read_uni(A['KADDR'])          # u5 q
    b.read_uni(B['SCB'], ws=1)      # u6
    b.read_uni(B['DCB'], ws=1)      # u7
    b.e(add_(ADD_SHL, B['L4'], ws=1, a=areg(R_ELEM_NUM), b=imm(2)))
    b.e(add_(ADD_ADD, A['SRC'], areg(A['T']), breg(B['L4'])), nop())
    b.e(add_or(A['DST'], areg(A['T2']), areg(A['T2'])), nop())
    b.e(add_(ADD_SHL, B['V4'], ws=1, a=areg(A['KADDR']), b=imm(2)))
    b.e(add_(ADD_SHL, B['V9'], ws=1, a=areg(A['KADDR']), b=imm(9)))
    b.e(add_(ADD_OR, B['SRCPIX'], areg(A['T3']), areg(A['T3']), ws=1))
    b.e(add_(ADD_OR, B['DSTPIX'], areg(A['T4']), areg(A['T4']), ws=1))
    b.e(add_(ADD_SHL, B['G4S'], ws=1, a=areg(A['T3']), b=imm(2)))
    b.e(add_(ADD_SHL, B['G4D'], ws=1, a=areg(A['T4']), b=imm(2)), nop())

    p.label('grp')
    for cb in range(nblk):
        b.e(ldi(cb * 64, B['CBT'], ws=1))
        b.e(add_(ADD_ADD, A['KADDR'], areg(A['SRC']), breg(B['SCB'])))
        if cb:
            b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['CBT'])))
        for px in range(4):
            if px:
                b.e(add_(ADD_ADD, A['KADDR'], areg(A['KADDR']), breg(B['SRCPIX'])))
            _tmu_load_a(b, 0, A['KADDR'], px)
        b.e(add_(ADD_ADD, A['DTMP'], areg(A['DST']), breg(B['DCB'])))
        if cb:
            b.e(add_(ADD_ADD, A['DTMP'], areg(A['DTMP']), breg(B['CBT'])))
        _store4(b, B['V4'], B['V9'], A['DTMP'], Cdst * 4 - 64)
    b.e(add_(ADD_ADD, A['SRC'], areg(A['SRC']), breg(B['G4S'])))
    b.e(add_(ADD_ADD, A['DST'], areg(A['DST']), breg(B['G4D'])))
    b.e(add_(ADD_SUB, A['CNT'], areg(A['CNT']), imm(1), sf=1))
    p.branch_to('grp', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# =============================================================== elementwise
OP_ADD, OP_MUL, OP_RELU, OP_SIGMOID, OP_SILU, OP_RELU_BWD, OP_RSQRT = 0, 1, 2, 3, 4, 5, 6
# FP32 comparison / predicate family (exact, IEEE bit tests; 0.0/1.0 output).
# Codes 7..99 are unused by the harness and by kops.py (100 = generic unary,
# 200 = generic binary/backward), so they are free for fixed bodies.
OP_CMP_EQ, OP_CMP_GT, OP_CMP_GE, OP_CMP_LT, OP_CMP_LE = 10, 11, 12, 13, 14
OP_ISNAN, OP_ISINF = 15, 16
OP_CMP_ALL = (OP_CMP_EQ, OP_CMP_GT, OP_CMP_GE, OP_CMP_LT, OP_CMP_LE, OP_ISNAN,
              OP_ISINF)

E_AB, E_BB, E_OB = 16, 17, 18
E_CNT, E_LANE = 19, 20
E_AA, E_AB2, E_AO = 21, 22, 23
E_TMP, E_VPMQ, E_AV, E_T8 = 24, 25, 26, 27
E_CADR = 28
E_T9, E_T10, E_T11 = 29, 30, 31

def build_ew(op, depth=2, nvec=16):
    """out[i] = f(a[i], b[i]); one group = 16 vectors = 256 floats per QPU
    iteration, stored with the verified 4-chunk VPM->DMA sequence (stride 0,
    step 256 bytes so the 16 rows land contiguously)."""
    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))
    b.read_uni(E_AB)                                     # u0 a
    b.read_uni(E_BB)                                     # u1 b
    b.read_uni(E_OB)                                     # u2 out
    b.read_uni(E_CNT)                                    # u3 groups
    b.read_uni(E_TMP)                                    # u4 qpu index
    b.read_uni(E_T9)                                     # u5 nqpu
    # a group is nvec vectors of 64 B: 16 (1024 B) for the cheap ops, 4
    # (256 B) for the long transcendental bodies that would not fit the 16 KiB
    # code slot.
    _gshift = {16: 10, 8: 9, 4: 8}[nvec]
    b.e(add_(ADD_SHL, B_K['STEP'], ws=1, a=areg(E_T9), b=imm(_gshift)))
    # per-iteration gap: after the nvec vectors of a group have advanced the
    # TMU address by nvec*64, QPU i's next group is i+nqpu, so add
    # (nqpu-1)*nvec*64.
    b.e(add_(ADD_SUB, E_T8, areg(E_T9), imm(1)))
    b.e(add_(ADD_SHL, B_K['GAP'], ws=1, a=areg(E_T8), b=imm(_gshift)))
    if nvec != 16:
        # the 4-vector store (_store4) needs q<<9 (the DMA/VPM read row) in B
        b.e(add_(ADD_SHL, B_K['CSTEP'], ws=1, a=areg(E_TMP), b=imm(9)))
    b.e(add_or(E_LANE, areg(R_ELEM_NUM), areg(R_ELEM_NUM)), nop())
    b.e(add_or(E_VPMQ, breg(R_QPU_NUM), breg(R_QPU_NUM)), nop())
    b.e(add_(ADD_SHL, E_VPMQ, areg(E_VPMQ), imm(2)), nop())            # 4*qpu
    if nvec == 16:
        b.e(add_(ADD_SHL, B_K['VPMQ7'], ws=1, a=areg(E_VPMQ), b=imm(7)))
    elif nvec == 8:
        # 8 rows per QPU: write row 8q, DMA read row 8q<<7 = 4q<<8
        b.e(add_(ADD_SHL, B_K['VPMQ7'], ws=1, a=areg(E_VPMQ), b=imm(1)), nop())
        b.e(add_(ADD_SHL, B_K['CSTEP'], ws=1, a=areg(E_VPMQ), b=imm(8)), nop())
    else:
        b.e(add_or(B_K['VPMQ7'], ws=1, a=areg(E_VPMQ), b=areg(E_VPMQ)), nop())
    # per-QPU stream offset within a group: 16 vectors for the cheap ops,
    # 4 for the long bodies (which is also the VPM-row and store step)
    b.e(add_(ADD_SHL, B_K['QOFF'], ws=1, a=areg(E_TMP), b=imm(_gshift)))
    b.e(add_(ADD_SHL, B_K['LOFF'], ws=1, a=areg(E_LANE), b=imm(2)))   # lane*4
    b.e(nop(), nop())
    b.e(add_(ADD_ADD, E_AA, areg(E_AB), (REGB, B_K['QOFF'])))
    b.e(add_(ADD_ADD, E_AB2, areg(E_BB), (REGB, B_K['QOFF'])))
    b.e(add_(ADD_ADD, E_AO, areg(E_OB), (REGB, B_K['QOFF'])), nop())
    b.e(add_(ADD_ADD, E_AA, areg(E_AA), (REGB, B_K['LOFF'])))
    b.e(add_(ADD_ADD, E_AB2, areg(E_AB2), (REGB, B_K['LOFF'])))
    b.e(nop(), nop())

    if nvec == 16:
        # emit_store16's chunk step is 4 rows x 64 B; the 4-vector path keeps
        # CSTEP = q<<9 (the VPM source row of this QPU's 4 rows), set above
        b.e(ldi(256, B_K['CSTEP'], ws=1))
    b.e(ldi(64, B_K['C16'], ws=1))     # one group vector = 16 floats = 64 B
    if op == OP_MUL:
        # constants for the correctly-rounded product (see _ew_compute):
        # 12-bit mantissa mask, abs mask, 24<<23 (half-ulp exponent step),
        # exponent mask
        for name, val in (('M', 0xFFFFF000), ('A', 0x7FFFFFFF),
                          ('H', 0x0C000000), ('X', 0x7F800000)):
            b.e(ldi(val, {'M': 9, 'A': 10, 'H': 11, 'X': 15}[name], ws=1), nop())
    if op == OP_RSQRT:
        b.e(ldi(0x5F3759DF, 0, ws=1))      # B0: rsqrt magic seed
        b.e(ldi(0x3FC00000, 1, ws=1))      # B1: 1.5
        b.e(ldi(0x3F000000, 2, ws=1))      # B2: 0.5
        b.e(nop(), nop())
    if op in OP_CMP_ALL:
        # comparison / predicate constants.  B9..B12 are free for a fixed
        # body: the harness only keeps B8 (the b stream), B17..B29 (loop
        # state) and the sigmoid/mul constant blocks.
        b.e(ldi(0x7FFFFFFF, 9, ws=1))      # B9 : |x| mask
        b.e(ldi(0x7F800001, 10, ws=1))     # B10: first NaN pattern
        b.e(ldi(0x7F800000, 11, ws=1))     # B11: +inf
        b.e(ldi(0x3F800000, 12, ws=1), nop())   # B12: 1.0f
        b.e(nop(), nop())
    elif op >= 200:
        # generic binary / backward op from kops.py (op-200 indexes EWB)
        import kops
        kops.ewb_consts(sys.modules[__name__], b, op - 200)
    elif op >= 100:
        # generic unary from kops.py: the op loads its own constants and its
        # body replaces _ew_compute below; the harness stays byte-identical to
        # the verified elementwise kernel.
        import kops
        kops.ew_consts(sys.modules[__name__], b, op - 100)
    if op in (OP_SIGMOID, OP_SILU):
        for name, val in (('NLOG2E', 0xBFB8AA3B), ('MAGIC', 0x4B400000),
                          ('CLAMP_LO', 0xC2B40000), ('CLAMP_HI', 0x42B40000),
                          ('ONE', 0x3F800000), ('TWO', 0x40000000),
                          ('RCPMAGIC', 0x7EF311C3),
                          ('C1', 0x3F317218), ('C2', 0x3E75FDF0),
                          ('C3', 0x3D635847), ('C4', 0x3C1D955B),
                          ('C5', 0x3AAEC3FF), ('HALF', 0x3F000000)):
            b.e(ldi(val, B_K[name], ws=1), nop())
    b.e(nop(), nop())

    p._builder = b
    p.label('grp_top')
    b.e(add_or(E_CADR, areg(E_AO), areg(E_AO)), nop())
    if nvec == 4:
        # The pipelined sequence (2 issued ahead, the next issued before the
        # pop) puts three requests in flight with a long body.  The TMU keeps
        # two: a body that runs long enough lets the third response overwrite
        # the oldest, and the later vectors silently get the wrong 64 B - the
        # measured nvec=4 failure.  The 4-vector path therefore loads each
        # vector serially (issue, wait, pop), the sequence probes 1/3 used.
        for j in range(nvec):
            _tmu_load_a(b, 0, E_AA, E_AV)
            _tmu_load_b(b, 1, E_AB2, B_VB)
            b.e(add_(ADD_ADD, E_AA, areg(E_AA), (REGB, B_K['C16'])))
            b.e(add_(ADD_ADD, E_AB2, areg(E_AB2), (REGB, B_K['C16'])), nop())
            _ew_compute(b, op, j)
    else:
        # prime the TMU pipeline (issue/pop never share a word: the asm3 rule)
        for _ in range(depth):
            b.e(add_or(W_TMU0_S, areg(E_AA), areg(E_AA), ws=1))
            b.e(add_or(W_TMU1_S, areg(E_AB2), areg(E_AB2), ws=1))
            b.e(nop(), nop())
            b.e(add_(ADD_ADD, E_AA, areg(E_AA), (REGB, B_K['C16'])))
            b.e(add_(ADD_ADD, E_AB2, areg(E_AB2), (REGB, B_K['C16'])))
            b.e(nop(), nop())
        for j in range(nvec):
            if j + depth < nvec:
                b.e(add_or(W_TMU0_S, areg(E_AA), areg(E_AA), ws=1))
                b.e(add_or(W_TMU1_S, areg(E_AB2), areg(E_AB2), ws=1))
                b.e(nop(), nop())
                b.e(add_(ADD_ADD, E_AA, areg(E_AA), (REGB, B_K['C16'])))
                b.e(add_(ADD_ADD, E_AB2, areg(E_AB2), (REGB, B_K['C16'])))
                b.e(nop(), nop())
            b.e(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
            b.e(add_or(E_AV, acc(4), acc(4)), nop())
            b.e(alu(sig=SIG_LOAD_TMU1, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
            b.e(add_or(B_VB, ws=1, a=acc(4), b=acc(4)), nop())
            _ew_compute(b, op, j)
    b.check = False
    if nvec == 16:
        emit_store16(p, 0)
    elif nvec == 8:
        # Two 4-row chunks in the QPU's same 4-row VPM slice: chunk 0 from
        # A0..A3, chunk 1 from A4..A7 (the slice cannot hold 8 rows).
        b.e(add_or(B_K['VPMQ7'], ws=1, a=areg(E_VPMQ), b=areg(E_VPMQ)),
            nop(), nop())
        b.e(add_(ADD_SHL, B_K['CSTEP'], ws=1, a=areg(E_VPMQ), b=imm(7)),
            nop(), nop())
        _store4(b, B_K['VPMQ7'], B_K['CSTEP'], E_CADR, 0, base=0)
        b.e(add_(ADD_ADD, E_CADR, areg(E_CADR), imm(256)), nop(), nop())
        _store4(b, B_K['VPMQ7'], B_K['CSTEP'], E_CADR, 0, base=4)
    else:
        b.e(add_or(B_K['VPMQ7'], ws=1, a=areg(E_VPMQ), b=areg(E_VPMQ)),
            nop(), nop())
        b.e(add_(ADD_SHL, B_K['CSTEP'], ws=1, a=areg(E_VPMQ), b=imm(7)),
            nop(), nop())
        # _store4 takes the VPM *write* row (4q, low bits of vpw_generic) and
        # the VPM *read* row for the DMA word (q<<9, the vdw row field)
        _store4(b, B_K['VPMQ7'], B_K['CSTEP'], E_CADR, 0)
    b.check = True
    b.e(add_(ADD_ADD, E_AO, areg(E_AO), (REGB, B_K['STEP'])))
    b.e(add_(ADD_ADD, E_AA, areg(E_AA), (REGB, B_K['GAP'])))
    b.e(add_(ADD_ADD, E_AB2, areg(E_AB2), (REGB, B_K['GAP'])))
    b.e(add_(ADD_SUB, E_CNT, areg(E_CNT), imm(1), sf=1))
    p.branch_to('grp_top', cond=BR_ALL_Z_CLEAR)
    b.e(nop(), nop(), nop())
    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


def _ew_compute(b, op, j):
    """Vector j -> r(j).  Operands: r26 (a) and b8 (b)."""
    if op >= 200:
        import kops
        kops.ewb_body(sys.modules[__name__], b, op - 200, j)
        return
    if op >= 100:
        import kops
        kops.ew_body(sys.modules[__name__], b, op - 100, j)
        return
    aa = areg(E_AV)
    bb = breg(B_VB)
    K = B_K
    if op == OP_ADD:
        b.e(_ops(add_op=ADD_FADD, add_out=j, add_a=aa, add_b=bb))
    elif op == OP_MUL:
        # The QPU FPU is round-toward-zero for *both* fmul and fadd (measured:
        # 1.0 + 0.75 ulp stays 1.0).  A single fmul therefore is not IEEE
        # mul.  Build the correctly-rounded product:
        #   split a,b into 12-bit halves (exact), p = trunc(a*b),
        #   e = (ah*bh - p) + ah*bl + al*bh + al*bl   (= a*b - p exactly)
        #   inc = 1 iff |e| > half-ulp(p)  (|e| == half: tie -> away from zero)
        #   result = bits(p) + inc, i.e. round away from zero by one ulp when
        #   the discarded part is over half.  All of it is integer/bit work,
        #   so it does not depend on the FPU rounding mode.
        MASK, ABSM, HALFSUB, EXPM = 9, 10, 11, 15   # B file, free for OP_MUL
        AH, BA, AL = 16, 17, 24                     # A file, dead after prologue
        # NB: A19 is the group counter, 20..23/25/26/28/29 are loop state;
        # only 27/30/31 are dead after the prologue.
        T_ABS, T_HALF, T_C = 18, 27, 30
        T_INC, T_NZ, T_LSB = 31, 18, 17
        T_M = 20                                      # A file (E_LANE, dead)
        T_MB, T_MNOT, T_LSB2 = 16, 17, 19             # B file (free for OP_MUL;
                                                      # 15 holds EXPM every vector)
        BH, BL, ACOPY = 13, 14, 12                  # B file
        b.e(_ops(add_op=ADD_AND, add_out=AH, add_a=areg(E_AV),
                 add_b=breg(MASK)))                 # ah
        b.e(add_or(ACOPY, ws=1, a=areg(E_AV), b=areg(E_AV)))
        b.e(_ops(add_op=ADD_FSUB, add_out=AL, add_a=breg(ACOPY),
                 add_b=areg(AH)))                   # al
        b.e(add_or(BA, a=breg(B_VB), b=breg(B_VB)))
        b.e(_ops(add_op=ADD_AND, add_out=BH, ws=1, add_a=areg(BA),
                 add_b=breg(MASK)))                 # bh
        b.e(_ops(add_op=ADD_FSUB, add_out=BL, ws=1, add_a=areg(BA),
                 add_b=breg(BH)))                   # bl
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 0, ws=0, mul_a=areg(E_AV),
                 mul_b=breg(B_VB)))                 # p = trunc(a*b)
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0, mul_a=areg(AH),
                 mul_b=breg(BH)))                   # ah*bh (exact)
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=acc(1),
                 add_b=acc(0)))                     # e = ah*bh - p
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=areg(AH),
                 mul_b=breg(BL)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=acc(3)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=areg(AL),
                 mul_b=breg(BH)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=acc(3)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=areg(AL),
                 mul_b=breg(BL)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=acc(3)))
        b.e(_ops(add_op=ADD_AND, add_out=T_ABS, ws=1, add_a=acc(2),
                 add_b=breg(ABSM)))                 # |e| (B file)
        b.e(_ops(add_op=ADD_AND, add_out=T_HALF, add_a=acc(0),
                 add_b=breg(EXPM)))                 # exponent(p)
        b.e(_ops(add_op=ADD_SUB, add_out=T_HALF, add_a=areg(T_HALF),
                 add_b=breg(HALFSUB)))              # 2^(exp-24) = half ulp
        b.e(_ops(add_op=ADD_MAX, add_out=T_HALF, add_a=areg(T_HALF),
                 add_b=imm(0)))                     # clamp (p == 0 case)
        b.e(_ops(add_op=ADD_SUB, add_out=T_C, add_a=breg(T_ABS),
                 add_b=areg(T_HALF)))               # c = |e| - half
        # inc = 1 iff |e| > half; on |e| == half use round-to-even (p's LSB).
        b.e(_ops(add_op=ADD_NOT, add_out=T_INC, add_a=areg(T_C),
                 add_b=areg(T_C)))
        b.e(_ops(add_op=ADD_SHR, add_out=T_INC, add_a=areg(T_INC),
                 add_b=imm(31)))                    # >? -> 0/1 (tie counts)
        b.e(_ops(add_op=ADD_AND, add_out=T_NZ, add_a=areg(T_C),
                 add_b=breg(ABSM)))                 # nz = c & 0x7fffffff
        b.e(_ops(add_op=ADD_SUB, add_out=T_M, add_a=areg(T_NZ),
                 add_b=imm(1)))
        b.e(_ops(add_op=ADD_ASR, add_out=T_M, add_a=areg(T_M),
                 add_b=imm(31)))                    # m = (nz==0) ? -1 : 0
        b.e(_ops(add_op=ADD_AND, add_out=T_LSB, add_a=acc(0),
                 add_b=imm(1)))                     # p & 1
        b.e(add_or(T_MB, ws=1, a=areg(T_M), b=areg(T_M)))    # m in B
        b.e(_ops(add_op=ADD_NOT, add_out=T_MNOT, ws=1, add_a=areg(T_M),
                 add_b=areg(T_M)))                  # ~m in B
        b.e(_ops(add_op=ADD_AND, add_out=T_LSB2, ws=1, add_a=areg(T_LSB),
                 add_b=breg(T_MB)))                 # (p&1) & m, in B
        b.e(_ops(add_op=ADD_AND, add_out=T_INC, add_a=areg(T_INC),
                 add_b=breg(T_MNOT)))               # inc &= ~m
        b.e(_ops(add_op=ADD_OR, add_out=T_INC, add_a=areg(T_INC),
                 add_b=breg(T_LSB2)))               # inc | lsb
        b.e(_ops(add_op=ADD_ADD, add_out=j, add_a=acc(0),
                 add_b=areg(T_INC)))                # bits(p) + inc
    elif op == OP_RELU:
        b.e(_ops(add_op=ADD_FMAX, add_out=j, add_a=aa, add_b=imm(0)))
    elif op == OP_RSQRT:
        # y = 1/sqrt(a) for a > 0: bit-trick seed, then y = y*(1.5 - 0.5*a*y*y)
        b.e(_ops(add_op=ADD_SHR, add_out=32 + 1, add_a=aa, add_b=imm(1)))
        b.e(_ops(add_op=ADD_SUB, add_out=32 + 1, add_a=breg(0), add_b=acc(1)))
        for _ in range(4):
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=aa, mul_b=acc(1)))
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=acc(1)))
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=breg(2)))
            b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=breg(1), add_b=acc(2)))
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0, mul_a=acc(1), mul_b=acc(2)))
        b.e(add_or(j, acc(1), acc(1)))
    elif op == OP_RELU_BWD:
        # out = b if a > 0 else 0.  Integer mask on the bits of relu(a):
        # +0 -> 0, any positive float has a positive int pattern, a negative
        # float (sign bit set) is a negative int -> (bits-1)>>31 == -1.  The
        # mask is then all-ones or 0, so the product is a bit copy (exact).
        b.e(_ops(add_op=ADD_FMAX, add_out=32 + 0, add_a=aa, add_b=imm(0)))
        b.e(_ops(add_op=ADD_SUB, add_out=32 + 0, add_a=acc(0), add_b=imm(1)))
        b.e(_ops(add_op=ADD_ASR, add_out=32 + 0, add_a=acc(0), add_b=imm(31)))
        b.e(_ops(add_op=ADD_NOT, add_out=32 + 1, add_a=acc(0), add_b=acc(0)))
        b.e(_ops(add_op=ADD_AND, add_out=j, add_a=acc(1), add_b=bb))
    elif op in OP_CMP_ALL:
        _ew_cmp(b, op, j, aa, bb)
    elif op in (OP_SIGMOID, OP_SILU):
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 0, ws=0, mul_a=aa,
                 mul_b=breg(K['NLOG2E'])))
        b.e(_ops(add_op=ADD_FMAX, add_out=32 + 0, add_a=acc(0),
                 add_b=breg(K['CLAMP_LO'])))
        b.e(_ops(add_op=ADD_FMIN, add_out=32 + 0, add_a=acc(0),
                 add_b=breg(K['CLAMP_HI'])))
        # The QPU fadd truncates, so t + 2^23 floors instead of rounding.  Add
        # 0.5 first so n = round(t) and f = t - n stays in [-0.5,0.5], the
        # interval the minimax polynomial was fitted on.
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 1, add_a=acc(0),
                 add_b=breg(K['HALF'])))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 3, add_a=acc(1),
                 add_b=breg(K['MAGIC'])))
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=acc(3),
                 add_b=breg(K['MAGIC'])))          # n
        # convert r1 (still in acc3) to the 2^n scale before the polynomial
        # overwrites acc3 with p
        b.e(_ops(add_op=ADD_FTOI, add_out=E_T10, add_a=acc(3), add_b=acc(3)))
        b.e(_ops(add_op=ADD_SHL, add_out=E_T10, add_a=areg(E_T10), add_b=imm(8)))
        b.e(_ops(add_op=ADD_SHL, add_out=E_T10, add_a=areg(E_T10), add_b=imm(15)))
        b.e(_ops(add_op=ADD_ADD, add_out=E_T10, add_a=areg(E_T10),
                 add_b=breg(K['ONE'])))
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 1, add_a=acc(0),
                 add_b=acc(2)))                    # f
        b.e(add_or(32 + 3, breg(K['C5']), breg(K['C5'])))
        for c in ('C4', 'C3', 'C2', 'C1'):
            # Horner: p = p*f + c  (multiply first; the old emit did
            # (p + c)*f, which is a different polynomial)
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=acc(3),
                     mul_b=acc(1)))
            b.e(_ops(add_op=ADD_FADD, add_out=32 + 3, add_a=acc(3),
                     add_b=breg(K[c])))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=acc(3),
                 mul_b=acc(1)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 3, add_a=acc(3),
                 add_b=breg(K['ONE'])))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=acc(3),
                 mul_b=areg(E_T10)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 0, add_a=acc(3),
                 add_b=breg(K['ONE'])))
        b.e(_ops(add_op=ADD_SUB, add_out=E_T11, add_a=breg(K['RCPMAGIC']),
                 add_b=acc(0)))
        for _ in range(3):
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=areg(E_T11),
                     mul_b=acc(0)))
            b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=breg(K['TWO']),
                     add_b=acc(2)))
            b.e(_ops(mul_op=MUL_FMUL, mul_out=E_T11, ws=1, mul_a=areg(E_T11),
                     mul_b=acc(2)))
        if op == OP_SILU:
            b.e(add_or(B_K['ACOPY'], ws=1, a=areg(E_AV), b=areg(E_AV)))
            b.e(_ops(mul_op=MUL_FMUL, mul_out=j, ws=1, mul_a=areg(E_T11),
                     mul_b=breg(B_K['ACOPY'])))
        else:
            b.e(add_or(j, areg(E_T11), areg(E_T11)))
    else:
        raise ValueError("bad ew op %r" % (op,))


# =============================================================== softmax+CE

def _ew_cmp(b, op, j, aa, bb):
    """Exact FP32 comparison / predicate, 0.0 or 1.0 out (vector j).

    Pure integer ALU work on IEEE-754 bit patterns: no floating-point
    operation is used, so nothing is rounded and nothing is flushed (the QPU
    FPU flushes denormals, ONNX.md 11.1, and a comparison must not).  The
    result is the ONNX answer for every input: NaN compares false everywhere
    including Equal, -0.0 == +0.0, +-inf compare by value, denormals compare
    by value.

    Ordering uses the monotonic integer key of a float:

        key(x) = bits(x) ^ ((bits(x) >> 31) & 0x7FFFFFFF)     (arithmetic >>)

    which maps -inf .. +inf onto a strictly increasing *signed* int32, so the
    key is injective and key(x) >= 0 exactly when x >= 0.0.  Two keys of the
    same sign cannot overflow when subtracted, and across signs the answer is
    the sign of the first operand, so no overflow correction is needed.

    Register map (all dead once the group loop starts): A16 both-zero term,
    A17 dneg/sb scratch, A18 lt, A20 key(a), A24 both-non-NaN, A27 eq,
    A30 lt&mn, A31 scratch; B13 sign(a), B14 key(b), B15 |b|; constants B9
    |x| mask, B10 first NaN pattern, B11 +inf, B12 1.0f; accumulators r0..r3.
    """
    ACC0, ACC1, ACC2, ACC3 = 100, 101, 102, 103   # kops scheme
    ABSM, NANP1, INFB, ONEB = 9, 10, 11, 12
    A_Z, A_DNEG, A_LT, A_KA, A_MN, A_EQ, A_LTm, A_T = 16, 17, 18, 20, 24, 27, 30, 31
    B_SA, B_KB, B_AB = 13, 14, 15

    def emit(aop, out, a, c=None, ws=0):
        d = dict(add_op=aop, add_out=(32 + out - 100 if out >= 100 else out),
                 ws=ws, add_a=a)
        if c is not None:
            d["add_b"] = c
        b.e(d)

    def eqzero_or(src, out):
        """-1 iff src == 0 (src must be a non-negative int register)."""
        emit(ADD_OR, ACC2, src, src)
        emit(ADD_SUB, ACC2, acc(2), imm(1))        # -1 iff src <= 0
        emit(ADD_ASR, ACC2, acc(2), imm(31))
        emit(ADD_OR, out, acc(2), acc(2))

    if op == OP_ISNAN:
        emit(ADD_AND, ACC0, areg(E_AV), breg(ABSM))
        emit(ADD_SUB, ACC0, acc(0), breg(NANP1))
        emit(ADD_ASR, ACC0, acc(0), imm(31))       # -1 iff not NaN
        emit(ADD_NOT, ACC2, acc(0), acc(0))
        emit(ADD_AND, ACC2, acc(2), breg(ONEB))
        emit(ADD_OR, j, acc(2), acc(2))
        return
    if op == OP_ISINF:
        emit(ADD_AND, ACC0, areg(E_AV), breg(ABSM))
        emit(ADD_SUB, ACC0, acc(0), breg(INFB))    # signed: 0 iff +-inf
        emit(ADD_OR, A_T, acc(0), acc(0))
        emit(ADD_OR, ACC2, acc(0), acc(0))
        emit(ADD_SUB, ACC2, acc(2), imm(1))        # -1 iff <= 0
        emit(ADD_ASR, ACC2, acc(2), imm(31))
        emit(ADD_ASR, ACC3, areg(A_T), imm(31))    # -1 iff < 0
        emit(ADD_NOT, ACC3, acc(3), acc(3))
        emit(ADD_AND, ACC2, acc(2), acc(3))        # -1 iff == 0
        emit(ADD_AND, ACC2, acc(2), breg(ONEB))
        emit(ADD_OR, j, acc(2), acc(2))
        return

    # ---- |b| (B15) and |a| (A31), then the "both operands are zero" term
    emit(ADD_OR, ACC3, breg(B_VB), breg(B_VB))
    emit(ADD_AND, ACC3, acc(3), breg(ABSM))
    emit(ADD_OR, B_AB, acc(3), acc(3), ws=1)
    emit(ADD_AND, ACC0, areg(E_AV), breg(ABSM))
    emit(ADD_OR, A_T, acc(0), acc(0))
    emit(ADD_OR, ACC2, areg(A_T), breg(B_AB))
    eqzero_or(acc(2), A_Z)                        # -1 iff both are zero
    # ---- monotonic keys
    emit(ADD_ASR, ACC0, areg(E_AV), imm(31))       # sign(a)
    emit(ADD_AND, ACC0, acc(0), breg(ABSM))
    emit(ADD_OR, B_SA, acc(0), acc(0), ws=1)
    emit(ADD_XOR, A_KA, areg(E_AV), acc(0))       # key(a)
    emit(ADD_OR, ACC3, breg(B_VB), breg(B_VB))
    emit(ADD_ASR, ACC0, acc(3), imm(31))          # sign(b)
    emit(ADD_AND, ACC0, acc(0), breg(ABSM))
    emit(ADD_OR, A_DNEG, acc(0), acc(0))          # sb, scratch
    emit(ADD_XOR, ACC3, acc(3), acc(0))           # key(b)
    emit(ADD_OR, B_KB, acc(3), acc(3), ws=1)
    # ---- d, sign difference, lt
    emit(ADD_SUB, ACC1, areg(A_KA), breg(B_KB))   # d = key(a) - key(b)
    emit(ADD_XOR, ACC0, breg(B_SA), areg(A_DNEG))  # signs differ?
    emit(ADD_ASR, A_DNEG, acc(1), imm(31))        # -1 iff d < 0
    emit(ADD_NOT, ACC2, acc(0), acc(0))           # same sign
    emit(ADD_AND, ACC2, areg(A_DNEG), acc(2))     # d < 0 and same sign
    emit(ADD_AND, A_LT, acc(0), breg(B_SA))       # signs differ and a < 0
    emit(ADD_OR, A_LT, acc(2), areg(A_LT))        # lt
    emit(ADD_NOT, ACC2, areg(A_Z), areg(A_Z))     # not both zero (-0.0 == +0.0)
    emit(ADD_AND, A_LT, areg(A_LT), acc(2))       # lt, zero-pair excluded
    # ---- both non-NaN
    emit(ADD_AND, ACC0, areg(E_AV), breg(ABSM))
    emit(ADD_SUB, ACC0, acc(0), breg(NANP1))
    emit(ADD_ASR, ACC0, acc(0), imm(31))
    emit(ADD_NOT, ACC2, acc(0), acc(0))           # not NaN(a)
    emit(ADD_OR, ACC3, breg(B_VB), breg(B_VB))
    emit(ADD_AND, ACC3, acc(3), breg(ABSM))
    emit(ADD_SUB, ACC3, acc(3), breg(NANP1))
    emit(ADD_ASR, ACC3, acc(3), imm(31))
    emit(ADD_NOT, ACC3, acc(3), acc(3))           # not NaN(b)
    emit(ADD_OR, A_T, acc(3), acc(3))
    emit(ADD_OR, ACC2, acc(2), areg(A_T))
    emit(ADD_NOT, A_MN, acc(2), acc(2))           # both non-NaN
    # ---- equality: (d == 0) | both-zero, then & non-NaN
    emit(ADD_OR, ACC2, acc(1), acc(1))
    emit(ADD_SUB, ACC2, acc(2), imm(1))           # -1 iff d <= 0
    emit(ADD_ASR, ACC2, acc(2), imm(31))
    emit(ADD_NOT, A_DNEG, areg(A_DNEG), areg(A_DNEG))
    emit(ADD_AND, ACC2, acc(2), areg(A_DNEG))     # -1 iff d == 0
    emit(ADD_OR, ACC2, acc(2), areg(A_Z))         # | both zero
    emit(ADD_AND, A_EQ, acc(2), areg(A_MN))       # eq
    # ---- select
    emit(ADD_OR, ACC2, areg(A_LT), areg(A_LT))
    emit(ADD_AND, A_LTm, acc(2), areg(A_MN))      # lt, NaN-safe
    if op == OP_CMP_EQ:
        emit(ADD_OR, ACC2, areg(A_EQ), areg(A_EQ))
    elif op == OP_CMP_LT:
        emit(ADD_OR, ACC2, areg(A_LTm), areg(A_LTm))
    elif op == OP_CMP_LE:                         # lt | eq
        emit(ADD_OR, ACC3, areg(A_LTm), areg(A_LTm))
        emit(ADD_OR, ACC3, acc(3), areg(A_EQ))
        emit(ADD_OR, ACC2, acc(3), acc(3))
    elif op == OP_CMP_GT:                         # mn & ~(lt | eq)
        emit(ADD_OR, ACC3, areg(A_LTm), areg(A_LTm))
        emit(ADD_OR, ACC3, acc(3), areg(A_EQ))
        emit(ADD_SUB, ACC2, areg(A_MN), acc(3))
    else:                                         # OP_CMP_GE: mn & ~lt
        emit(ADD_OR, ACC2, areg(A_MN), areg(A_MN))
        emit(ADD_SUB, ACC2, acc(2), areg(A_LTm))
    emit(ADD_AND, j, acc(2), breg(ONEB))

def build_softmax(depth=2, probe=None):
    """Fused row softmax + cross-entropy backward, ONE 8-row group per launch.

    Each QPU owns exactly one group of 8 rows, so the kernel has no loop and
    no branch: the group count is the launch's QPU count (the host launches
    ceil(rows/8/12) times).  A row is one 16-lane vector (the model output is
    padded to 16 columns with a very negative bias, which contributes exp=0).

      max  = horizontal max over 16 lanes (rotate + fmax, 4 steps)
      e    = 2^((z-max)*log2e)  (degree-5 2^f polynomial + magic exponent,
                                 the constants proven in build_ew)
      S    = horizontal sum (rotate + fadd, 4 steps)
      p    = e * (1/S)          (bit-trick reciprocal + 3 Newton steps)
      dl   = (p - onehot(label)) * (1/B)

    plus, per row, loss = (max - z_y) + ln2*log2(S) and
    correct = (z_y == max).  Each QPU writes its totals (lane 0 loss, lane 1
    correct rows) as one 64 B slot; the host reduces the slots with a GPU
    GEMM (ones^T * partial), never on the CPU.

    KERNEL ABI (uniforms u0..u5, 64 B block per QPU)
      u0 logits group bus (8 rows x 16 floats = 512 B)
      u1 dlogits group bus
      u2 labels group bus (8 x int32 = 32 B)
      u3 partial slot bus (64 B)
      u4 QPU index (VPM row base = 4*q)
      u5 1/B as float bits
    """
    # A file
    A_LOG, A_DL, A_LB, A_PART = 16, 17, 18, 19
    A_INV, A_LN2, A_L2E, A_QID = 20, 21, 22, 23
    A_LANE, A_SADDR, A_M0, A_M1 = 24, 25, 26, 27
    A_EXP = 28
    # B file: constants and running totals
    B_HALF, B_MAGIC, B_RCPM, B_ONE, B_TWO, B_MANT = 0, 1, 2, 3, 4, 5
    B_C64, B_C256, B_ABS, B_CLAMP = 6, 7, 8, 9
    B_LOSS, B_CORR = 10, 11
    B_L0, B_L1, B_L2, B_L3, B_L4, B_L5, B_L6 = 12, 13, 14, 15, 16, 17, 18
    EXPC = (19, 20, 21, 22, 23)
    B_T0, B_T1, B_T2, B_T3 = 24, 25, 26, 27
    B_Q4, B_Q9 = 28, 29
    # exp polynomial (same constants as build_ew: 2^f on [-0.5, 0.5])
    EXP = (0x3AAEC3FF, 0x3C1D955B, 0x3D635847, 0x3E75FDF0, 0x3F317218)
    # log2(1+f) on [0,1], degree 6 (max |err| = 2.1e-6, fitted offline)
    LOG2 = (0x360E8598, 0x3FB8A308, 0xBF37B1DF, 0x3EE93AD9,
            0xBE8C9B6B, 0x3DF452A2, 0xBCCDCF2D)
    RPG = 8

    b = Builder()
    p = b.p
    b.e(add_or(36, imm(1), imm(1)))                    # tmu_noswap
    b.read_uni(A_LOG)                                  # u0
    b.read_uni(A_DL)                                   # u1
    b.read_uni(A_LB)                                   # u2
    b.read_uni(A_PART)                                 # u3
    b.read_uni(A_QID)                                  # u4
    b.read_uni(A_INV)                                  # u5
    b.e(ldi(0x3F000000, B_HALF, ws=1))
    b.e(ldi(0x4B400000, B_MAGIC, ws=1))
    b.e(ldi(0x7EF311C3, B_RCPM, ws=1))
    b.e(ldi(0x3F800000, B_ONE, ws=1))
    b.e(ldi(0x40000000, B_TWO, ws=1))
    b.e(ldi(0x007FFFFF, B_MANT, ws=1))
    b.e(ldi(64, B_C64, ws=1))
    b.e(ldi(0x3727C5AC, B_C256, ws=1))          # 1e-5 (argmax tolerance)
    b.e(ldi(0x7FFFFFFF, B_ABS, ws=1))
    b.e(ldi(0xC2AE0000, B_CLAMP, ws=1))                # -87.0
    b.e(ldi(0x3F317218, A_LN2))                        # ln(2)
    b.e(ldi(0x3FB8AA3B, A_L2E))                        # log2(e)
    b.e(ldi(0x00000000, B_LOSS, ws=1))
    b.e(ldi(0x00000000, B_CORR, ws=1))
    for i, v in enumerate(EXP):
        b.e(ldi(v, EXPC[i], ws=1))
    for i, v in enumerate(LOG2):
        b.e(ldi(v, (B_L0, B_L1, B_L2, B_L3, B_L4, B_L5, B_L6)[i], ws=1))
    b.e(add_(ADD_SHL, B_Q4, ws=1, a=areg(A_QID), b=imm(2)))     # 4q
    b.e(add_(ADD_SHL, B_Q9, ws=1, a=areg(A_QID), b=imm(9)))     # q<<9
    b.e(ldi(127, A_QID))                               # 127 does not fit the
    b.e(nop(), nop())                                  # small-immediate field
    b.e(add_or(A_LANE, areg(R_ELEM_NUM), areg(R_ELEM_NUM)))
    b.e(_ops(add_op=ADD_SUB, add_out=32 + 0, add_a=areg(A_LANE), add_b=imm(1)))
    b.e(_ops(add_op=ADD_ASR, add_out=32 + 0, add_a=acc(0), add_b=imm(31)))
    b.e(_ops(add_op=ADD_AND, add_out=A_M0, add_a=acc(0), add_b=breg(B_ONE)))
    b.e(_ops(add_op=ADD_XOR, add_out=32 + 1, add_a=areg(A_LANE), add_b=imm(1)))
    b.e(_ops(add_op=ADD_SUB, add_out=32 + 1, add_a=acc(1), add_b=imm(1)))
    b.e(_ops(add_op=ADD_ASR, add_out=32 + 1, add_a=acc(1), add_b=imm(31)))
    b.e(_ops(add_op=ADD_AND, add_out=A_M1, add_a=acc(1), add_b=breg(B_ONE)))
    b.e(nop(), nop())

    p._builder = b
    p.label('grp')

    for j in range(RPG):
        # label_j: one 64 B line at the group's label base, lane 0 is row j
        b.e(add_or(W_TMU0_S, areg(A_LB), areg(A_LB), ws=1))
        b.e(nop(), nop())
        b.e(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
        b.e(add_or(37, acc(4), acc(4), ws=1))          # rep_all(label lane 0)
        b.e(add_or(B_T0, ws=1, a=acc(5), b=acc(5)))
        # z_y = logits[row][label]; all lanes read the same word (only lane 0
        # matters), so the read is harmless even near the row end (the buffer
        # carries 64 B of slack).
        b.e(add_(ADD_SHL, 32 + 2, a=acc(5), b=imm(2)))
        b.e(_ops(add_op=ADD_ADD, add_out=32 + 2, add_a=acc(2), add_b=areg(A_LOG)))
        b.e(add_or(A_SADDR, acc(2), acc(2)))
        b.e(nop(), nop())
        b.e(add_or(W_TMU0_S, areg(A_SADDR), areg(A_SADDR), ws=1))
        b.e(nop(), nop())
        b.e(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
        b.e(add_or(37, acc(4), acc(4), ws=1))          # rep_all(z_y)
        b.e(add_or(B_T1, ws=1, a=acc(5), b=acc(5)))
        if probe == 'zy':
            b.e(add_or(j, breg(B_T1), breg(B_T1)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
            b.e(nop())
            continue
        # x: the row's 16 logits, one per lane
        b.e(_ops(add_op=ADD_SHL, add_out=32 + 2, add_a=areg(A_LANE), add_b=imm(2)))
        b.e(_ops(add_op=ADD_ADD, add_out=32 + 2, add_a=acc(2), add_b=areg(A_LOG)))
        b.e(add_or(A_SADDR, acc(2), acc(2)))
        b.e(nop(), nop())
        b.e(add_or(W_TMU0_S, areg(A_SADDR), areg(A_SADDR), ws=1))
        b.e(nop(), nop())
        b.e(alu(sig=SIG_LOAD_TMU0, cond_add=COND_NEVER, cond_mul=COND_NEVER), nop())
        b.e(add_or(32 + 0, acc(4), acc(4)))            # x
        b.e(add_or(B_T3, ws=1, a=acc(0), b=acc(0)))    # keep x
        if probe and probe.startswith('rot'):
            n = int(probe[3:])
            if n:
                b.e(mul_rot(1, 0, n))
                b.e(add_or(j, acc(1), acc(1)))
            else:
                b.e(add_or(j, acc(0), acc(0)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
            b.e(nop())
            continue
        if probe == 'raw':
            b.e(add_or(j, acc(0), acc(0)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
            b.e(nop())
            continue
        # max over lanes.  mul_rot(v,n) rotates right by n (asm3 convention:
        # rep(rot(v,n)) == v[16-n]), so {8,12,14,15} covers all 16 offsets.
        # An ADD-ALU accumulator result is not visible to the MUL ALU in the
        # very next word on this board (measured), hence the 2-word gaps.
        for s in (8, 4, 2, 1):
            b.e(mul_rot(1, 0, (16 - s) & 15))
            b.e(nop(), nop())
            b.e(_ops(add_op=ADD_FMAX, add_out=32 + 0, add_a=acc(0), add_b=acc(1)))
            b.e(nop(), nop())
        b.e(add_or(B_T2, ws=1, a=acc(0), b=acc(0)))    # max
        # t = (x - max) * log2e, clamped to [-87, 0]
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 1, add_a=breg(B_T3), add_b=acc(0)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0, mul_a=acc(1), mul_b=areg(A_L2E)))
        b.e(_ops(add_op=ADD_FMAX, add_out=32 + 1, add_a=acc(1), add_b=breg(B_CLAMP)))
        b.e(_ops(add_op=ADD_FMIN, add_out=32 + 1, add_a=acc(1), add_b=imm(0)))
        # exp(t) = 2^n * poly(f)
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(1), add_b=breg(B_HALF)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 3, add_a=acc(2), add_b=breg(B_MAGIC)))
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=acc(3), add_b=breg(B_MAGIC)))
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 1, add_a=acc(1), add_b=acc(2)))   # f
        b.e(_ops(add_op=ADD_FTOI, add_out=32 + 3, add_a=acc(3), add_b=acc(3)))
        b.e(_ops(add_op=ADD_SHL, add_out=32 + 3, add_a=acc(3), add_b=imm(8)))
        b.e(_ops(add_op=ADD_SHL, add_out=32 + 3, add_a=acc(3), add_b=imm(15)))
        b.e(_ops(add_op=ADD_ADD, add_out=32 + 3, add_a=acc(3), add_b=breg(B_ONE)))
        b.e(add_or(32 + 2, breg(EXPC[0]), breg(EXPC[0])))
        for c in (EXPC[1], EXPC[2], EXPC[3], EXPC[4]):
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=acc(1)))
            b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=breg(c)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=acc(1)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=breg(B_ONE)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=acc(3)))
        b.e(add_or(A_EXP, acc(2), acc(2)))             # keep exp
        # sum over lanes
        b.e(add_or(32 + 0, areg(A_EXP), areg(A_EXP)))
        b.e(nop(), nop(), nop())
        for s in (8, 4, 2, 1):
            b.e(mul_rot(1, 0, (16 - s) & 15))
            b.e(nop(), nop())
            b.e(_ops(add_op=ADD_FADD, add_out=32 + 0, add_a=acc(0), add_b=acc(1)))
            b.e(nop(), nop())
        # S = acc0, exp = A_EXP; reciprocal
        b.e(_ops(add_op=ADD_SUB, add_out=32 + 1, add_a=breg(B_RCPM), add_b=acc(0)))
        for _ in range(3):
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(1), mul_b=acc(0)))
            b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=breg(B_TWO), add_b=acc(2)))
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0, mul_a=acc(1), mul_b=acc(2)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=areg(A_EXP), mul_b=acc(1)))
        if probe and probe.startswith('red'):
            k = int(probe[3:])
            b.e(add_or(32 + 0, areg(A_EXP), areg(A_EXP)))
            b.e(nop(), nop(), nop())
            for s in (8, 4, 2, 1)[:k]:
                b.e(mul_rot(1, 0, (16 - s) & 15))
                b.e(nop(), nop())
                b.e(_ops(add_op=ADD_FADD, add_out=32 + 0, add_a=acc(0), add_b=acc(1)))
                b.e(nop(), nop())
            b.e(add_or(j, acc(0), acc(0)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
            b.e(nop())
            continue
        if probe in ('p', 'sum', 'max', 'exp'):
            if probe == 'p':
                b.e(add_or(j, acc(2), acc(2)))
            elif probe == 'sum':
                b.e(add_or(j, acc(0), acc(0)))
            elif probe == 'max':
                b.e(add_or(j, breg(B_T2), breg(B_T2)))
            else:
                b.e(add_or(j, areg(A_EXP), areg(A_EXP)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
            b.e(nop())
            continue
        # onehot(label) via integer lane equality
        b.e(_ops(add_op=ADD_XOR, add_out=32 + 3, add_a=areg(A_LANE), add_b=breg(B_T0)))
        b.e(_ops(add_op=ADD_SUB, add_out=32 + 3, add_a=acc(3), add_b=imm(1)))
        b.e(_ops(add_op=ADD_ASR, add_out=32 + 3, add_a=acc(3), add_b=imm(31)))
        b.e(_ops(add_op=ADD_AND, add_out=32 + 3, add_a=acc(3), add_b=breg(B_ONE)))
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 2, add_a=acc(2), add_b=acc(3)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=areg(A_INV)))
        b.e(add_or(j, acc(2), acc(2)))                 # dlogits row j -> A[j]
        # log2(S): e2 = exponent-127, f = mantissa-1
        b.e(_ops(add_op=ADD_SHR, add_out=32 + 3, add_a=acc(0), add_b=imm(23)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_SUB, add_out=32 + 3, add_a=acc(3), add_b=areg(A_QID)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_ITOF, add_out=32 + 3, add_a=acc(3), add_b=acc(3)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_AND, add_out=32 + 1, add_a=acc(0), add_b=breg(B_MANT)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_OR, add_out=32 + 1, add_a=acc(1), add_b=breg(B_ONE)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 1, add_a=acc(1), add_b=breg(B_ONE)))
        b.e(nop(), nop())
        b.e(add_or(32 + 2, breg(B_L6), breg(B_L6)))
        b.e(nop(), nop())
        for c in (B_L5, B_L4, B_L3, B_L2, B_L1, B_L0):
            b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 2, ws=0, mul_a=acc(2), mul_b=acc(1)))
            b.e(nop())
            b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=breg(c)))
            b.e(nop(), nop())
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 2, add_a=acc(2), add_b=acc(3)))
        b.e(nop(), nop())
        # lse = max + ln2*log2(S); loss = lse - z_y
        b.e(add_or(32 + 0, breg(B_T2), breg(B_T2)))
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 1, add_a=acc(0), add_b=breg(B_T1)))
        b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 3, ws=0, mul_a=acc(2), mul_b=areg(A_LN2)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 1, add_a=acc(1), add_b=acc(3)))
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 1, add_a=acc(1), add_b=breg(B_LOSS)))
        b.e(add_or(B_LOSS, ws=1, a=acc(1), b=acc(1)))
        # correct += (z_y ~= max).  The hardware vector rotate used by the
        # reduction is 1-ulp lossy on this board (measured), so the argmax is
        # an absolute-tolerance test on the logit scale: |z_y - max| <= 1e-5.
        # d >= 0, so the bit pattern of d is monotonic in d; compare
        # bits(d) with bits(1e-5) as integers.
        b.e(add_or(32 + 0, breg(B_T1), breg(B_T1)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_FSUB, add_out=32 + 1, add_a=acc(0), add_b=breg(B_T2)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_AND, add_out=32 + 1, add_a=acc(1), add_b=breg(B_ABS)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_SUB, add_out=32 + 1, add_a=acc(1), add_b=breg(B_C256)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_ASR, add_out=32 + 1, add_a=acc(1), add_b=imm(31)))
        b.e(nop(), nop())
        b.e(_ops(add_op=ADD_AND, add_out=32 + 1, add_a=acc(1), add_b=breg(B_ONE)))
        b.e(nop(), nop())
        if probe == 'cor':
            b.e(add_or(j, acc(1), acc(1)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
            b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
            b.e(nop())
            continue
        b.e(_ops(add_op=ADD_FADD, add_out=32 + 1, add_a=acc(1), add_b=breg(B_CORR)))
        b.e(nop(), nop())
        b.e(add_or(B_CORR, ws=1, a=acc(1), b=acc(1)))
        b.e(_ops(add_op=ADD_ADD, add_out=A_LOG, add_a=areg(A_LOG), add_b=breg(B_C64)))
        b.e(_ops(add_op=ADD_ADD, add_out=A_LB, add_a=areg(A_LB), add_b=imm(4)))
        b.e(nop())

    # ---- store the group's 8 dlogits rows (verified 2-chunk store) --------
    b.e(ldi(256, B_C256, ws=1))                    # restore the store step
    b.e(nop(), nop())
    b.e(add_or(A_SADDR, areg(A_DL), areg(A_DL)))
    for c in range(RPG // 4):
        b.e(ldi(0x1A00, R5, ws=1))
        b.e(_ops(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
                 add_a=acc(5), add_b=breg(B_Q4)))
        for r in range(4):
            b.e(add_or(W_VPM, areg(4 * c + r), areg(4 * c + r)))
        b.e(ldi(0x82104000, R5, ws=1))
        b.e(_ops(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
                 add_a=acc(5), add_b=breg(B_Q9)))
        b.e(ldi(0xC0010000, W_VPW_SETUP, ws=1))
        b.e(add_or(W_VPW_ADDR, areg(A_SADDR), areg(A_SADDR), ws=1))
        b.e(_ops(add_op=ADD_OR, add_out=W_NOP,
                 add_a=(REGB, R_VPW_WAIT), add_b=(REGB, R_VPW_WAIT)))
        b.e(nop(), nop(), nop(), nop())
        b.e(_ops(add_op=ADD_ADD, add_out=A_SADDR, add_a=areg(A_SADDR), add_b=breg(B_C256)))

    # ---- this QPU's totals: lane0 = loss, lane1 = correct rows ------------
    b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 0, ws=0, mul_a=breg(B_LOSS), mul_b=areg(A_M0)))
    b.e(_ops(mul_op=MUL_FMUL, mul_out=32 + 1, ws=0, mul_a=breg(B_CORR), mul_b=areg(A_M1)))
    b.e(_ops(add_op=ADD_FADD, add_out=32 + 0, add_a=acc(0), add_b=acc(1)))
    b.e(add_or(0, acc(0), acc(0)))
    b.e(ldi(0x1A00, R5, ws=1))
    b.e(_ops(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
             add_a=acc(5), add_b=breg(B_Q4)))
    b.e(add_or(W_VPM, areg(0), areg(0)))
    b.e(ldi(0x80904000, R5, ws=1))
    b.e(_ops(add_op=ADD_ADD, add_out=W_VPW_SETUP, ws=1,
             add_a=acc(5), add_b=breg(B_Q9)))
    b.e(ldi(0xC0010000, W_VPW_SETUP, ws=1))
    b.e(add_or(W_VPW_ADDR, areg(A_PART), areg(A_PART), ws=1))
    b.e(_ops(add_op=ADD_OR, add_out=W_NOP,
             add_a=(REGB, R_VPW_WAIT), add_b=(REGB, R_VPW_WAIT)))
    b.e(nop(), nop(), nop(), nop())

    b.e(end_program())
    b.e(nop(), nop(), nop())
    return p


# =============================================================== CLI
def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 2
    kind, out = argv[1], argv[2]
    opts = {}
    used = set()
    i = 3
    while i < len(argv):
        opts[argv[i].lstrip('-')] = argv[i + 1]
        i += 2

    def g(k, d=None):
        used.add(k)
        return int(opts[k]) if k in opts else d

    def _opt(k, d=None):
        used.add(k)
        return opts.get(k, d)

    if kind == 'gemm':
        # the asm10 kernel: 8x64 tiles, 3-phase k loop (build_gemm above is the
        # asm3 16x16 generator, kept as 'gemm3' for A/B and reference)
        p = build_gemm10(g('M'), g('N'), g('K'), g('nqpu', 12),
                         _opt('probe'), bool(g('single', 0)), g('act', 0),
                         g('compact', 0))
    elif kind == 'gemm3':
        p = build_gemm(g('M'), g('N'), g('K'), g('nqpu', 12), g('bmode', 0),
                       g('depth', 3), g('cstride', None), g('act', 0))
    elif kind == 'pack':
        p = build_pack10(g('k'))
    elif kind == 'pack3':
        p = build_pack(g('kblocks'), g('vpitch', 1), g('dstride', 0))
    elif kind == 'im2col':
        p = build_im2col(g('cin'), g('k'), g('kh'), g('kw'), g('vpitch', 1),
                         _opt('vout', 'k'))
    elif kind == 'col2im':
        p = build_col2im(g('cin'), g('k'), g('kh'), g('kw'),
                         g('wp'), g('hp'))
    elif kind == 'pool':
        p = build_pool(g('h'), g('w'), g('op'), _opt('mode', 'fwd'))
        g('c', 0)        # the caller also passes the channel count; the kernel
                         # is per image and the launch loop owns C
    elif kind == 'pooln':
        p = build_pooln(g('n'), g('s'), g('wp'), g('op'))
    elif kind == 'im2col_nhwc':
        p = build_im2col_nhwc(g('cin'), g('kh'), g('kw'), g('stride', 1),
                              dilation=g('dil', 1))
    elif kind == 'im2col_nhwc_flat2':
        p = build_im2col_nhwc_flat2(g('cin'), g('kh'), g('kw'),
                                    g('stride', 1), dilation=g('dil', 1))
    elif kind == 'probe_lane':
        p = build_probe_lane()
    elif kind == 'probe_lane_b':
        p = build_probe_lane_b()
    elif kind == 'probe_pool':
        p = build_probe_pool(g('cin'))
    elif kind == 'probe_seq':
        p = build_probe_seq(_opt('seq'))
        used.update(('seq',))
    elif kind == 'depthwise':
        p = build_depthwise_nhwc(g('cin'))
    elif kind == 'pool_nhwc':
        p = build_pool_nhwc(g('cin'), g('k'))
    elif kind == 'up2':
        p = build_up2_nhwc(g('cin'))
    elif kind == 'copy':
        p = build_copy_nhwc(g('cin'), g('cout'))
    elif kind == 'ew':
        p = build_ew(g('op'))
    elif kind in ('uop', 'ewb', 'sel3', 'gather', 'blit', 'reduce', 'cumsum',
                  'copy2d'):
        # generic kernels for the numeric op long tail (kops.py): they reuse
        # build_ew's verified harness and only replace the body.
        import kops
        p = kops.build(sys.modules[__name__], kind, opts)
        used.update(('op', 'nvec', 'fill', 'units', 'depth'))
    elif kind == 'softmax':
        pr = _opt('probe')
        p = build_softmax(probe=None if pr in (None, 'full') else pr)
    elif kind in ('uop', 'sel3', 'gather', 'reduce', 'cumsum', 'blit'):
        # generic kernels for the numeric op long tail (kops.py)
        import kops
        p = kops.build(sys.modules[__name__], kind, opts)
    else:
        print("unknown kernel kind %r" % kind, file=sys.stderr)
        return 2
    unknown = set(opts) - used
    if unknown:
        print("kgen: %s: unknown option(s) %s: the caller expects a kernel this "
              "generator cannot build, refusing to emit a silently different one"
              % (kind, ", ".join(sorted(unknown))), file=sys.stderr)
        return 2
    # Size gate: a blob over one code slot cannot be uploaded, and the
    # engine's loader would only say so after the graph reached the op.
    nwords = len(p.finish()) if hasattr(p, 'finish') else len(p.words())
    if nwords * 8 > CODE_SLOT_BYTES:
        print("kgen: %s: %d instructions (%d B) exceed the %d B client code "
              "slot; split the kernel or move work out of its generated "
              "unrolling" % (kind, nwords, nwords * 8, CODE_SLOT_BYTES),
              file=sys.stderr)
        return 4
    if hasattr(p, '_builder'):
        n = p._builder.report(out)
        if n and os.environ.get('KGEN_STRICT'):
            print("kgen: %d read-after-write violations" % n, file=sys.stderr)
            return 3
    w = p.write(out)
    print("%s: %d instructions -> %s" % (kind, len(w), out))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
