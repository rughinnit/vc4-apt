#!/usr/bin/env python3
"""ctypes binding for libvc4infer.

Same API surface as the C library; the arena is addressed with integer
offsets, so a caller can either keep raw bytes or hand a numpy array through
frombuffer() on the uncached host pointer.

    import vc4infer, numpy as np
    eng = vc4infer.Engine()
    a = eng.upload(np.random.rand(128,128).astype(np.float32))
    b = eng.upload(np.random.rand(128,128).astype(np.float32))
    c = eng.alloc(128*128*4)
    eng.matmul(a, b, c, 128, 128, 128)
    out = eng.download(c, 128*128*4).reshape(128,128)

Strict dispatch is preserved: an unsupported op raises Unsupported (the C
library returns VC4_ERR_UNSUPPORTED and never falls back to the CPU).
"""
import ctypes
import os
import sys

try:                       # numpy is convenient, not required
    import numpy as np
except ImportError:        # pragma: no cover
    np = None

_HERE = os.path.dirname(os.path.abspath(__file__))


def _find_lib():
    """Locate libvc4infer: $VC4INFER_LIB, the in-tree build, then the system.

    The package installs the library as /usr/lib/<triplet>/libvc4infer.so.1;
    an in-tree checkout keeps it in infer/build.  The first existing candidate
    wins, so a developer build is never shadowed by an installed one.
    """
    env = os.environ.get("VC4INFER_LIB")
    if env:
        return env
    cands = [os.path.join(_HERE, "libvc4infer.so"),
             os.path.join(_HERE, "..", "..", "build", "libvc4infer.so"),
             "/usr/lib/aarch64-linux-gnu/libvc4infer.so.1",
             "/usr/lib/libvc4infer.so.1",
             "/usr/local/lib/libvc4infer.so"]
    for c in cands:
        if os.path.isfile(c):
            return os.path.realpath(c)
    try:
        import ctypes.util
        found = ctypes.util.find_library("vc4infer")
        if found:
            return found
    except Exception:
        pass
    raise ImportError("libvc4infer.so not found (tried %s); set VC4INFER_LIB"
                      % ", ".join(cands))


_LIB = _find_lib()

_LIB_HANDLE = None


def library():
    """The shared library, opened once, for calls that need no context.

    The kernel identity (ABI tag, generator digest) and the loaded-kernel list
    have to be readable before an Engine exists: an artifact is validated
    against them before it touches the arena.
    """
    global _LIB_HANDLE
    if _LIB_HANDLE is None:
        _LIB_HANDLE = ctypes.CDLL(_LIB)
    return _LIB_HANDLE


def generator_digest():
    """sha256(kgen.py, kops.py beside it, ABI tag) as the blob cache computes it.

    ``None`` when the installed library predates ``vc4_generator_digest``; the
    caller can then fall back to hashing the generator sources itself, which is
    what the cache does (see ``vc4infer.artifact``).
    """
    lib = library()
    fn = getattr(lib, "vc4_generator_digest", None)
    if fn is None:
        return None
    fn.argtypes = [ctypes.c_char_p]
    fn.restype = None
    buf = ctypes.create_string_buffer(65)
    fn(buf)
    return buf.value.decode()


def plan_op_size():
    """sizeof(vc4_plan_op) in the loaded library, or None if it has no plan."""
    lib = library()
    fn = getattr(lib, "vc4_plan_op_size", None)
    if fn is None:
        return None
    fn.restype = ctypes.c_size_t
    return int(fn())


def kernel_abi_tag():
    """The ABI tag the generator digest hashes, or ``None`` without the symbol."""
    lib = library()
    fn = getattr(lib, "vc4_kernel_abi_tag", None)
    if fn is None:
        return None
    fn.restype = ctypes.c_char_p
    return fn().decode()

VC4_OK = 0
ERR_INVAL, ERR_NOMEM, ERR_IO, ERR_TIMEOUT = -1, -2, -3, -4
ERR_UNSUPPORTED = -5
ERR_GPU, ERR_KERNEL = -6, -7

_STATUS = {
    ERR_INVAL: "invalid argument",
    ERR_NOMEM: "out of memory: no arena (another process holds it, or CMA "
               "is exhausted)",
    ERR_IO: "I/O error: vc4d socket or /dev/mem",
    ERR_TIMEOUT: "QPU timeout; the context is dead",
    ERR_UNSUPPORTED: "unsupported operation",
    ERR_GPU: "V3D/queue error after a launch",
    ERR_KERNEL: "QPU kernel blob missing and generation failed",
}

OP_MATMUL, OP_CONV2D, OP_ADD, OP_MUL, OP_RELU, OP_SIGMOID, OP_SILU = range(7)
# exact FP32 comparisons / predicates (vc4infer.h: appended after the forward
# and training op set, so the first seven numbers never move)
OP_CMP_EQ, OP_CMP_GT, OP_CMP_GE, OP_CMP_LT, OP_CMP_LE, OP_ISNAN, OP_ISINF = \
    range(45, 52)
# the two forward ops the composition handlers name directly
OP_RELU_BWD = 7
LAYOUT_ROW_MAJOR = 0

# vc4_act: an activation a GEMM/conv applies to the value it stores
ACT_NONE, ACT_RELU, ACT_CLIP6, ACT_SILU = 0, 1, 2, 3

# vc4_uop (mirrors infer/include/vc4infer.h)
(UOP_ABS, UOP_NEG, UOP_IDENTITY, UOP_CLIP, UOP_LEAKYRELU, UOP_FLOOR,
 UOP_CEIL, UOP_ROUND, UOP_SIGN, UOP_EXP, UOP_LOG, UOP_SQRT, UOP_RECIPROCAL,
 UOP_TANH, UOP_ERF, UOP_ELU, UOP_SELU, UOP_SOFTPLUS, UOP_SOFTSIGN, UOP_GELU,
 UOP_GELU_ERF, UOP_HARDSIGMOID, UOP_HARDSWISH, UOP_SIN, UOP_COS,
 UOP_AFFINE, UOP_MISH,
 UOP_ACOS, UOP_ACOSH, UOP_ASIN, UOP_ASINH, UOP_ATAN, UOP_ATANH, UOP_TAN,
 UOP_SINH, UOP_COSH, UOP_RNG) = range(37)
SEL_WHERE, SEL_CLIP3, SEL_PRELU = range(3)
RED_SUM, RED_MEAN, RED_MAX, RED_MIN, RED_ARGMAX, RED_ARGMIN = range(6)


class Buf(ctypes.Structure):
    _fields_ = [("off", ctypes.c_uint32), ("bytes", ctypes.c_size_t)]


# Frozen execution plans: the record layout mirrors vc4_plan_op in
# vc4infer.h.  vc4_plan_op_size() is the ABI check between the two; a writer
# that gets this wrong would hand the C walker garbage offsets, so the plan
# builder refuses to run when the sizes disagree.
PLAN_ALIAS, PLAN_EW, PLAN_UNARY = 0, 1, 2
PLAN_COPY2D, PLAN_COPY2D_N, PLAN_COPY2D_X = 3, 4, 5
PLAN_FILL2D, PLAN_GATHER, PLAN_BLIT = 6, 7, 8
PLAN_REDUCE, PLAN_CUMSUM = 9, 10
PLAN_KINDS = 11

PLAN_ARGS = 14


class PlanOp(ctypes.Structure):
    _fields_ = [("kind", ctypes.c_uint16), ("flags", ctypes.c_uint16),
                ("a_off", ctypes.c_uint32), ("a_bytes", ctypes.c_uint32),
                ("b_off", ctypes.c_uint32), ("b_bytes", ctypes.c_uint32),
                ("c_off", ctypes.c_uint32), ("c_bytes", ctypes.c_uint32),
                ("n", ctypes.c_int64),
                ("p", ctypes.c_int64 * PLAN_ARGS)]


class OpInfo(ctypes.Structure):
    _fields_ = [("name", ctypes.c_char_p), ("backend", ctypes.c_char_p),
                ("supported", ctypes.c_int), ("note", ctypes.c_char_p)]


class Stats(ctypes.Structure):
    _fields_ = [("launches", ctypes.c_uint64), ("pack_ns", ctypes.c_uint64),
                ("kernel_ns", ctypes.c_uint64), ("gpu_cycles", ctypes.c_uint64),
                ("flops", ctypes.c_uint64)]


class TuneShape(ctypes.Structure):
    """Mirror of vc4_tune_shape: a matmul's m,n,k or a conv's geometry."""
    _fields_ = [("m", ctypes.c_uint32), ("n", ctypes.c_uint32),
                ("k", ctypes.c_uint32), ("cin", ctypes.c_uint32),
                ("cout", ctypes.c_uint32), ("h", ctypes.c_uint32),
                ("w", ctypes.c_uint32), ("kh", ctypes.c_uint32),
                ("kw", ctypes.c_uint32), ("pad", ctypes.c_uint32),
                ("stride", ctypes.c_uint32), ("flags", ctypes.c_uint32)]


class TuneParams(ctypes.Structure):
    _fields_ = [("pack_q", ctypes.c_uint32), ("gemm_q", ctypes.c_uint32),
                ("im2col_q", ctypes.c_uint32)]


class TuneOpts(ctypes.Structure):
    _fields_ = [("max_candidates", ctypes.c_uint32),
                ("budget_ms", ctypes.c_uint32), ("reps", ctypes.c_uint32),
                ("force", ctypes.c_uint32)]


class TuneResult(ctypes.Structure):
    _fields_ = [("params", TuneParams), ("best_ms", ctypes.c_double),
                ("default_ms", ctypes.c_double), ("max_abs", ctypes.c_double),
                ("candidates", ctypes.c_uint32), ("over_tol", ctypes.c_uint32),
                ("from_cache", ctypes.c_int), ("kernel", ctypes.c_char * 80)]


class Error(RuntimeError):
    """An engine call failed; ``code`` is the vc4_status value when known."""

    def __init__(self, msg, code=None):
        self.code = code
        super().__init__(msg)


class Unsupported(Error):
    pass


class Engine:
    def __init__(self, cache_dir=None, arena_bytes=0):
        self.lib = ctypes.CDLL(_LIB)
        L = self.lib
        L.vc4_init.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_char_p,
                               ctypes.c_size_t]
        L.vc4_init.restype = ctypes.c_int
        L.vc4_shutdown.argtypes = [ctypes.c_void_p]
        L.vc4_strerror.restype = ctypes.c_char_p
        L.vc4_last_error.argtypes = [ctypes.c_void_p]
        L.vc4_last_error.restype = ctypes.c_char_p
        L.vc4_alloc.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(Buf)]
        L.vc4_alloc.restype = ctypes.c_int
        L.vc4_upload.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf), ctypes.c_void_p,
                                 ctypes.c_size_t]
        L.vc4_upload.restype = ctypes.c_int
        L.vc4_batch_begin.argtypes = [ctypes.c_void_p]
        L.vc4_batch_begin.restype = None
        L.vc4_batch_end.argtypes = [ctypes.c_void_p]
        L.vc4_batch_end.restype = ctypes.c_int
        # Protocol 4: depth-2 request pipelining.  A library that predates it
        # makes this Optional below, and pipeline_begin() then reports
        # unsupported instead of pretending.
        try:
            L.vc4_pipeline_begin.argtypes = [ctypes.c_void_p]
            L.vc4_pipeline_begin.restype = ctypes.c_int
            L.vc4_pipeline_flush.argtypes = [ctypes.c_void_p]
            L.vc4_pipeline_flush.restype = ctypes.c_int
            L.vc4_pipeline_end.argtypes = [ctypes.c_void_p]
            L.vc4_pipeline_end.restype = ctypes.c_int
            L.vc4_pipeline_epoch.argtypes = [ctypes.c_void_p]
            L.vc4_pipeline_epoch.restype = ctypes.c_uint64
            L.vc4_pipeline_reaped.argtypes = [ctypes.c_void_p]
            L.vc4_pipeline_reaped.restype = ctypes.c_uint64
            self.pipeline_supported = True
        except AttributeError:
            self.pipeline_supported = False
        L.vc4_invalidate_buf.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)]
        L.vc4_invalidate_buf.restype = None
        L.vc4_download.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                   ctypes.c_void_p, ctypes.c_size_t]
        L.vc4_download.restype = ctypes.c_int
        L.vc4_host_ptr.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)]
        L.vc4_host_ptr.restype = ctypes.c_void_p
        L.vc4_matmul.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                 ctypes.POINTER(Buf), ctypes.POINTER(Buf),
                                 ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32,
                                 ctypes.c_int]
        L.vc4_matmul.restype = ctypes.c_int
        # ctx, in, Cin, H, W, wt, Cout, KH, KW, bias, stride, pad, out, HO, WO
        L.vc4_conv2d.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(Buf),
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(Buf),
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(Buf),
            ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(Buf),
            ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv2d.restype = ctypes.c_int
        L.vc4_elementwise.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                      ctypes.POINTER(Buf), ctypes.POINTER(Buf),
                                      ctypes.POINTER(Buf), ctypes.c_size_t]
        L.vc4_elementwise.restype = ctypes.c_int
        L.vc4_maxpooln.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + [
            ctypes.c_int] * 6 + [ctypes.POINTER(Buf),
                                 ctypes.POINTER(ctypes.c_int),
                                 ctypes.POINTER(ctypes.c_int)]
        L.vc4_maxpooln.restype = ctypes.c_int
        L.vc4_softmax_fwd.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                      ctypes.c_uint32, ctypes.c_uint32,
                                      ctypes.POINTER(Buf)]
        L.vc4_softmax_fwd.restype = ctypes.c_int
        # last-axis softmax, any class count (fused kernel <= 16 classes)
        L.vc4_softmax.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                  ctypes.c_uint32, ctypes.c_uint32,
                                  ctypes.POINTER(Buf)]
        L.vc4_softmax.restype = ctypes.c_int
        # ctx, x, gamma, beta, running_mean, running_var, out, N, C, HW, eps
        L.vc4_batchnorm_infer.argtypes = \
            [ctypes.c_void_p] + [ctypes.POINTER(Buf)] * 6 + \
            [ctypes.c_uint32] * 3 + [ctypes.c_float]
        L.vc4_batchnorm_infer.restype = ctypes.c_int
        # ctx, x, gamma, beta, out, save_mean, save_invstd, rows, cols, eps
        L.vc4_layernorm_fwd.argtypes = \
            [ctypes.c_void_p] + [ctypes.POINTER(Buf)] * 6 + \
            [ctypes.c_uint32] * 2 + [ctypes.c_float]
        L.vc4_layernorm_fwd.restype = ctypes.c_int
        L.vc4_conv_nhwc_wpanel_bytes.argtypes = [ctypes.c_int] * 5
        L.vc4_conv_nhwc_wpanel_bytes.restype = ctypes.c_size_t
        L.vc4_conv_nhwc_pack_w.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 4 + [ctypes.POINTER(Buf), ctypes.POINTER(Buf)]
        L.vc4_conv_nhwc_pack_w.restype = ctypes.c_int
        L.vc4_conv_nhwc.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf)] + [ctypes.c_int] * 5 + \
            [ctypes.POINTER(Buf), ctypes.POINTER(ctypes.c_int),
             ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc.restype = ctypes.c_int
        L.vc4_conv_nhwc_dil.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf)] + [ctypes.c_int] * 6 + \
            [ctypes.POINTER(Buf), ctypes.POINTER(ctypes.c_int),
             ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_dil.restype = ctypes.c_int
        L.vc4_conv_nhwc_pads.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf)] + [ctypes.c_int] * 4 + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_pads.restype = ctypes.c_int
        L.vc4_conv_nhwc_pads_act.argtypes = [ctypes.c_void_p,
                                             ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf)] + [ctypes.c_int] * 10 + \
            [ctypes.POINTER(Buf), ctypes.POINTER(ctypes.c_int),
             ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_pads_act.restype = ctypes.c_int
        L.vc4_conv_nhwc_group.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(ctypes.POINTER(Buf))] + \
            [ctypes.c_int] * 7 + [ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_group.restype = ctypes.c_int
        L.vc4_conv_nhwc_act.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.c_int, ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_act.restype = ctypes.c_int
        L.vc4_conv_nhwc_dil_act.argtypes = [ctypes.c_void_p,
                                            ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 6 + [ctypes.c_int, ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_dil_act.restype = ctypes.c_int
        L.vc4_conv_nhwc_group_act.argtypes = [ctypes.c_void_p,
                                              ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(ctypes.POINTER(Buf))] + \
            [ctypes.c_int] * 7 + [ctypes.c_int, ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_conv_nhwc_group_act.restype = ctypes.c_int
        L.vc4_matmul_act.argtypes = [ctypes.c_void_p] + \
            [ctypes.POINTER(Buf)] * 3 + [ctypes.c_uint32] * 3 + \
            [ctypes.c_int, ctypes.c_int]
        L.vc4_matmul_act.restype = ctypes.c_int
        L.vc4_maxpool_nhwc.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 7 + [ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_maxpool_nhwc.restype = ctypes.c_int
        L.vc4_upsample2x_nhwc.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_int] * 5 + [ctypes.POINTER(Buf),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int),
                                  ctypes.POINTER(ctypes.c_int)]
        L.vc4_upsample2x_nhwc.restype = ctypes.c_int
        L.vc4_probe.argtypes = [ctypes.c_void_p, ctypes.c_char_p,
                                ctypes.POINTER(Buf), ctypes.POINTER(Buf),
                                ctypes.c_size_t]
        L.vc4_probe.restype = ctypes.c_int
        L.vc4_unary.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                ctypes.POINTER(Buf), ctypes.POINTER(Buf),
                                ctypes.c_size_t] + [ctypes.c_float] * 3
        L.vc4_unary.restype = ctypes.c_int
        L.vc4_select3.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                  ctypes.POINTER(Buf), ctypes.POINTER(Buf),
                                  ctypes.POINTER(Buf), ctypes.POINTER(Buf),
                                  ctypes.c_size_t]
        L.vc4_select3.restype = ctypes.c_int
        L.vc4_gather.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                 ctypes.POINTER(Buf), ctypes.c_size_t,
                                 ctypes.c_float]
        L.vc4_gather.restype = ctypes.c_int
        L.vc4_blit.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                               ctypes.POINTER(Buf), ctypes.c_size_t]
        L.vc4_blit.restype = ctypes.c_int
        L.vc4_copy2d.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                 ctypes.POINTER(Buf)] + \
            [ctypes.c_uint32] * 7
        L.vc4_copy2d.restype = ctypes.c_int
        L.vc4_copy2d_n.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                   ctypes.POINTER(Buf)] + \
            [ctypes.c_uint32] * 10
        L.vc4_copy2d_n.restype = ctypes.c_int
        L.vc4_copy2d_x.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                   ctypes.POINTER(Buf)] + \
            [ctypes.c_uint32] * 13
        L.vc4_copy2d_x.restype = ctypes.c_int
        L.vc4_fill2d.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf)] + \
            [ctypes.c_uint32] * 4 + [ctypes.c_float]
        L.vc4_fill2d.restype = ctypes.c_int
        L.vc4_reduce.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                 ctypes.POINTER(Buf), ctypes.c_uint32,
                                 ctypes.c_uint32, ctypes.c_int]
        L.vc4_reduce.restype = ctypes.c_int
        L.vc4_cumsum.argtypes = [ctypes.c_void_p, ctypes.POINTER(Buf),
                                 ctypes.POINTER(Buf), ctypes.c_uint32,
                                 ctypes.c_uint32]
        L.vc4_cumsum.restype = ctypes.c_int
        # A frozen plan is one call per segment; a library that predates the
        # walker keeps working (the runner then never builds a plan).
        try:
            L.vc4_plan_run.argtypes = [ctypes.c_void_p,
                                       ctypes.POINTER(PlanOp), ctypes.c_size_t]
            L.vc4_plan_run.restype = ctypes.c_int
            self.plan_supported = True
        except AttributeError:
            self.plan_supported = False
        L.vc4_get_stats.argtypes = [ctypes.c_void_p, ctypes.POINTER(Stats)]
        L.vc4_get_stats.restype = None
        L.vc4_autotune.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                   ctypes.POINTER(TuneShape),
                                   ctypes.POINTER(TuneOpts),
                                   ctypes.POINTER(TuneResult)]
        L.vc4_autotune.restype = ctypes.c_int
        L.vc4_autotune_enabled.argtypes = [ctypes.c_void_p]
        L.vc4_autotune_enabled.restype = ctypes.c_int
        L.vc4_supported_ops.argtypes = [ctypes.POINTER(ctypes.c_size_t)]
        L.vc4_supported_ops.restype = ctypes.POINTER(OpInfo)
        L.vc4_print_supported_ops.argtypes = [ctypes.c_void_p]
        L.vc4_arena_bytes.argtypes = [ctypes.c_void_p]
        L.vc4_arena_bytes.restype = ctypes.c_size_t

        self.ctx = ctypes.c_void_p()
        # >0 while a caller (the executor's node loop) holds one batch scope
        # open; see batch_hold()/batch_release().
        self._batch_hold = 0
        # True between pipeline_begin() and pipeline_end(); Pool reads it to
        # decide whether a freed block has to be held back for a request.
        self.pipeline_armed = False
        if not arena_bytes:
            # A 320x320 YOLO needs ~91 MiB (activations + weights + the
            # per-conv im2col scratch); the daemon's default 72 MiB is too
            # small.  The client region is what the engine can see, so make
            # it settable without touching the daemon launch line.
            mb = int(os.environ.get("VC4INFER_ARENA_MB", "0"))
            if mb > 0:
                arena_bytes = mb << 20
        if cache_dir:
            # kgen.py writes the blob into the cache directory; it does not
            # create it, so the caller's cache path must exist.
            try:
                os.makedirs(cache_dir, exist_ok=True)
            except OSError:
                pass
        st = L.vc4_init(ctypes.byref(self.ctx),
                        cache_dir.encode() if cache_dir else None, arena_bytes)
        if st != VC4_OK:
            raise Error("vc4_init failed: %s (%d)"
                        % (_STATUS.get(st, "unknown error"), st), st)

    # ---- lifecycle
    def close(self):
        if self.ctx:
            self.lib.vc4_shutdown(self.ctx)
            self.ctx = None

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    # ---- helpers
    def _check(self, st, what):
        # A caller may hold a batch scope open across several C API calls (the
        # executor does this per graph node).  Inside it the queue is not
        # drained here: the calls in one node are exactly the launches whose
        # ordering the device guarantees, and the scope's release reports the
        # first failure.  Outside a scope the batch covers one C API call, so
        # the call that issued a launch also reports its timeout or error.
        if self._batch_hold:
            if st != VC4_OK:
                # Do not leave earlier launches of this node queued behind an
                # exception: complete what was issued, then raise the original.
                self.lib.vc4_batch_end(self.ctx)
            if st == VC4_OK:
                return
            msg = self.lib.vc4_last_error(self.ctx).decode()
            if st == ERR_UNSUPPORTED:
                raise Unsupported("%s: %s" % (what, msg))
            raise Error("%s: %s (%s)"
                        % (what, self.lib.vc4_strerror(st).decode(), msg), st)
        bst = self.lib.vc4_batch_end(self.ctx)
        if st == VC4_OK:
            st = bst
        if st == VC4_OK:
            self.lib.vc4_batch_begin(self.ctx)
            return
        msg = self.lib.vc4_last_error(self.ctx).decode()
        if st == ERR_UNSUPPORTED:
            raise Unsupported("%s: %s" % (what, msg))
        raise Error("%s: %s (%s)"
                    % (what, self.lib.vc4_strerror(st).decode(), msg), st)

    def batch_hold(self):
        """Open a batch scope that spans several API calls.

        The executor holds one per graph node.  Inside it launches accumulate
        and are submitted once at release; a download, upload, dirty mark,
        scratch reset or explicit invalidate still drains the queue first,
        because those are the points where the client touches memory the
        queue may be using.
        """
        if self._batch_hold == 0:
            self.lib.vc4_batch_begin(self.ctx)
        self._batch_hold += 1

    def batch_release(self):
        """Close a scope; submit its launches and raise the first failure."""
        if self._batch_hold <= 0:
            raise RuntimeError("batch_release without batch_hold")
        self._batch_hold -= 1
        if self._batch_hold:
            return
        st = self.lib.vc4_batch_end(self.ctx)
        if st != VC4_OK:
            msg = self.lib.vc4_last_error(self.ctx).decode()
            if st == ERR_UNSUPPORTED:
                raise Unsupported("batch: %s" % msg)
            raise Error("batch: %s (%s)"
                        % (self.lib.vc4_strerror(st).decode(), msg), st)

    @property
    def arena_bytes(self):
        return self.lib.vc4_arena_bytes(self.ctx)

    # ---- pipelined throughput path
    def pipeline_begin(self):
        """Arm depth-2 request pipelining; returns 0 or a VC4 error code.

        With it armed, batch_release() sends a node's launches without waiting
        for them, so the next node's setup runs while the QPUs are busy.  Every
        barrier (upload, download, invalidate, load) still completes the
        outstanding requests first, so the API stays synchronous where it
        matters.  A version-2 or version-3 daemon returns ERR_UNSUPPORTED, and
        nothing is armed.
        """
        if not getattr(self, "pipeline_supported", False):
            return ERR_UNSUPPORTED
        st = self.lib.vc4_pipeline_begin(self.ctx)
        if st == VC4_OK:
            self.pipeline_armed = True
        return st

    def pipeline_flush(self):
        """Complete every request in flight; stays armed."""
        if not self.pipeline_armed:
            return VC4_OK
        return self.lib.vc4_pipeline_flush(self.ctx)

    def pipeline_end(self):
        """Flush and disarm; returns the first failure, VC4_OK when clean."""
        if not self.pipeline_armed:
            return VC4_OK
        st = self.lib.vc4_pipeline_end(self.ctx)
        self.pipeline_armed = False
        return st

    def pipeline_watermarks(self):
        """(newest submitted epoch, newest reaped epoch), for the pool."""
        return (int(self.lib.vc4_pipeline_epoch(self.ctx)),
                int(self.lib.vc4_pipeline_reaped(self.ctx)))

    def loaded_kernels(self):
        """Names of the blobs this context has loaded (see the C API)."""
        fn = getattr(self.lib, "vc4_loaded_kernels", None)
        if fn is None:
            return []
        fn.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
        fn.restype = ctypes.c_int
        buf = ctypes.create_string_buffer(1 << 17)
        n = fn(self.ctx, buf, len(buf))
        if n <= 0:
            return []
        raw = buf.raw
        out, i = [], 0
        for _ in range(n):
            j = raw.index(b"\0", i)
            out.append(raw[i:j].decode())
            i = j + 1
        return out

    def alloc(self, nbytes):
        b = Buf()
        self._check(self.lib.vc4_alloc(self.ctx, nbytes, ctypes.byref(b)), "alloc")
        return b

    def upload(self, arr, buf=None):
        """arr: numpy array or anything exposing the buffer protocol (fp32 bytes)."""
        if np is not None and isinstance(arr, np.ndarray):
            raw = np.ascontiguousarray(arr, dtype=np.float32).tobytes()
        else:
            raw = bytes(memoryview(arr).cast("B"))
        if buf is None:
            buf = self.alloc(len(raw))
        tmp = ctypes.create_string_buffer(raw, len(raw))
        self._check(self.lib.vc4_upload(self.ctx, ctypes.byref(buf),
                                        ctypes.cast(tmp, ctypes.c_void_p),
                                        len(raw)), "upload")
        return buf

    def download(self, buf, nbytes):
        raw = ctypes.create_string_buffer(nbytes)
        self._check(self.lib.vc4_download(self.ctx, ctypes.byref(buf), raw, nbytes),
                    "download")
        return np.frombuffer(raw.raw, dtype=np.float32) if np is not None else raw.raw

    def view(self, buf, count):
        """Zero-copy view of the arena mapping (numpy required).

        The mapping is cacheable, so the bytes the QPU wrote are only visible
        after an invalidate: vc4_download does the same maintenance before it
        copies, and this does it before handing out the pointer.  The view is
        read-only in spirit -- writing through it needs the range invalidated
        first (vc4infer.upload takes care of that), otherwise the clean that
        precedes the next launch writes the whole cache line back and would
        overlay whatever the QPU has put in the rest of it.
        """
        if np is None:
            raise RuntimeError("numpy is not installed")
        # The pointer escapes to Python, so the queue has to drain before it
        # is handed out and batching resumes only once it is back.
        self.lib.vc4_batch_end(self.ctx)
        self.lib.vc4_invalidate_buf(self.ctx, ctypes.byref(buf))
        p = self.lib.vc4_host_ptr(self.ctx, ctypes.byref(buf))
        out = np.ctypeslib.as_array((ctypes.c_float * count).from_address(p))
        self.lib.vc4_batch_begin(self.ctx)
        return out

    # ---- ops
    def matmul(self, a, b, c, M, N, K, layout=LAYOUT_ROW_MAJOR,
               act=ACT_NONE):
        self._check(self.lib.vc4_matmul_act(
            self.ctx, ctypes.byref(a), ctypes.byref(b), ctypes.byref(c),
            M, N, K, layout, act), "matmul")

    def conv2d(self, x, w, out, Cin, H, W, Cout, KH, KW, bias=None, stride=1, pad=1):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        self._check(self.lib.vc4_conv2d(
            self.ctx, ctypes.byref(x), Cin, H, W, ctypes.byref(w), Cout, KH, KW,
            ctypes.byref(bias) if bias is not None else None, stride, pad,
            ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo)), "conv2d")
        return ho.value, wo.value

    def elementwise(self, op, a, out, n, b=None):
        self._check(self.lib.vc4_elementwise(
            self.ctx, op, ctypes.byref(a),
            ctypes.byref(b) if b is not None else None, ctypes.byref(out), n),
            "elementwise")

    def maxpooln(self, x, out, C, H, W, N, stride, pad):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        self._check(self.lib.vc4_maxpooln(
            self.ctx, ctypes.byref(x), C, H, W, N, stride, pad,
            ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo)), "maxpooln")
        return ho.value, wo.value

    def softmax_fwd(self, x, out, rows, cols):
        self._check(self.lib.vc4_softmax_fwd(
            self.ctx, ctypes.byref(x), rows, cols, ctypes.byref(out)),
            "softmax_fwd")

    def softmax(self, x, out, rows, cols):
        """Last-axis softmax, any class count (stable only up to |x| < 80)."""
        self._check(self.lib.vc4_softmax(
            self.ctx, ctypes.byref(x), rows, cols, ctypes.byref(out)),
            "softmax")

    def batchnorm_infer(self, x, gamma, beta, mean, var, out, N, C, HW, eps):
        """y = (x - mean)/sqrt(var + eps)*gamma + beta (fixed operand order)."""
        self._check(self.lib.vc4_batchnorm_infer(
            self.ctx, ctypes.byref(x), ctypes.byref(gamma),
            ctypes.byref(beta), ctypes.byref(mean), ctypes.byref(var),
            ctypes.byref(out), N, C, HW, float(eps)), "batchnorm_infer")

    def layernorm_fwd(self, x, gamma, beta, out, save_mean, save_invstd,
                      rows, cols, eps):
        """Standardise each row over cols columns, then *gamma + beta."""
        self._check(self.lib.vc4_layernorm_fwd(
            self.ctx, ctypes.byref(x), ctypes.byref(gamma),
            ctypes.byref(beta), ctypes.byref(out), ctypes.byref(save_mean),
            ctypes.byref(save_invstd), rows, cols, float(eps)), "layernorm")

    # ---- generic kernels (vc4_gen.c)
    def unary(self, op, a, out, n, p0=0.0, p1=0.0, p2=0.0):
        self._check(self.lib.vc4_unary(self.ctx, int(op), ctypes.byref(a),
                                       ctypes.byref(out), int(n),
                                       float(p0), float(p1), float(p2)),
                    "unary")

    def probe(self, seq, a, out, n=16):
        """Diagnostic: one 16-lane vector in, raw 16 lanes out."""
        self._check(self.lib.vc4_probe(self.ctx, seq.encode(), ctypes.byref(a),
                                       ctypes.byref(out), int(n)), "probe")

    def select3(self, op, a, b, c, out, n):
        self._check(self.lib.vc4_select3(self.ctx, int(op), ctypes.byref(a),
                                         ctypes.byref(b), ctypes.byref(c),
                                         ctypes.byref(out), int(n)), "select3")

    def gather(self, tab, out, n, fill=0.0):
        self._check(self.lib.vc4_gather(self.ctx, ctypes.byref(tab),
                                        ctypes.byref(out), int(n), float(fill)),
                    "gather")

    def blit(self, a, out, nbytes):
        self._check(self.lib.vc4_blit(self.ctx, ctypes.byref(a),
                                      ctypes.byref(out), int(nbytes)), "blit")

    def copy2d(self, a, out, rows, vpr, srow, drow, svec, dvec, slane):
        """16-lane vector copy: dst[rows][vpr][16] <- src at lane*slane."""
        self._check(self.lib.vc4_copy2d(
            self.ctx, ctypes.byref(a), ctypes.byref(out), int(rows), int(vpr),
            int(srow), int(drow), int(svec), int(dvec), int(slane)),
            "copy2d")

    def copy2d_n(self, a, out, rows, vpr, srow, drow, svec, dvec, slane,
                 nlane, units, depth):
        """copy2d with an explicit store shape and lane count."""
        self._check(self.lib.vc4_copy2d_n(
            self.ctx, ctypes.byref(a), ctypes.byref(out), int(rows), int(vpr),
            int(srow), int(drow), int(svec), int(dvec), int(slane),
            int(nlane), int(units), int(depth)), "copy2d_n")

    def copy2d_x(self, a, out, rows, vpr, srow, drow, svec, dvec, slane,
                 nlane=16, nblk=1, sbstep=64, dbstep=64, units=4, depth=16):
        """The general layout copy (see vc4infer.h)."""
        self._check(self.lib.vc4_copy2d_x(
            self.ctx, ctypes.byref(a), ctypes.byref(out), int(rows), int(vpr),
            int(srow), int(drow), int(svec), int(dvec), int(slane),
            int(nlane), int(nblk), int(sbstep), int(dbstep), int(units),
            int(depth)), "copy2d_x")

    def fill2d(self, out, rows, vpr, drow, dvec, value=0.0):
        self._check(self.lib.vc4_fill2d(
            self.ctx, ctypes.byref(out), int(rows), int(vpr), int(drow),
            int(dvec), float(value)), "fill2d")

    def reduce(self, a, out, outer, red, op):
        self._check(self.lib.vc4_reduce(self.ctx, ctypes.byref(a),
                                        ctypes.byref(out), int(outer), int(red),
                                        int(op)), "reduce")

    def cumsum(self, a, out, rows, cols):
        self._check(self.lib.vc4_cumsum(self.ctx, ctypes.byref(a),
                                        ctypes.byref(out), int(rows),
                                        int(cols)), "cumsum")

    def plan_run(self, ops):
        """Replay a frozen plan: one ctypes call, one C loop, no Python node.

        ``ops`` is a (PlanOp * n) array built once by
        ``vc4infer._plan``; it is not copied and not inspected here.
        """
        if not self.plan_supported:
            raise Unsupported("this libvc4infer has no vc4_plan_run")
        self._check(self.lib.vc4_plan_run(self.ctx, ops, len(ops)),
                    "plan_run")

    # ---- NHWC (the YOLO plane)
    def conv_nhwc_wpanel_bytes(self, Cin, Cout, KH, KW, bias=True):
        return int(self.lib.vc4_conv_nhwc_wpanel_bytes(Cin, Cout, KH, KW,
                                                      1 if bias else 0))

    def conv_nhwc_pack_w(self, wt, Cin, Cout, KH, KW, bias, wpanel):
        self._check(self.lib.vc4_conv_nhwc_pack_w(
            self.ctx, ctypes.byref(wt), Cin, Cout, KH, KW,
            ctypes.byref(bias) if bias is not None else None,
            ctypes.byref(wpanel)), "conv_nhwc_pack_w")

    def conv_nhwc(self, x, nimg, Cin, H, W, in_pitch, wpanel, Cout, KH, KW,
                  stride, pad, out, act=ACT_NONE):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        op = ctypes.c_int(0)
        self._check(self.lib.vc4_conv_nhwc_act(
            self.ctx, ctypes.byref(x), nimg, Cin, H, W, in_pitch,
            ctypes.byref(wpanel), Cout, KH, KW, stride, pad, act,
            ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo),
            ctypes.byref(op)), "conv_nhwc")
        return ho.value, wo.value, op.value

    def conv_nhwc_dil(self, x, nimg, Cin, H, W, in_pitch, wpanel, Cout, KH, KW,
                      stride, pad, dil, out, act=ACT_NONE):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        op = ctypes.c_int(0)
        self._check(self.lib.vc4_conv_nhwc_dil_act(
            self.ctx, ctypes.byref(x), nimg, Cin, H, W, in_pitch,
            ctypes.byref(wpanel), Cout, KH, KW, stride, pad, dil, act,
            ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo),
            ctypes.byref(op)), "conv_nhwc_dil")
        return ho.value, wo.value, op.value

    def conv_nhwc_pads(self, x, nimg, Cin, H, W, in_pitch, wpanel, Cout, KH,
                       KW, stride, pt, pl, pb, pr, dil, out, act=ACT_NONE):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        op = ctypes.c_int(0)
        self._check(self.lib.vc4_conv_nhwc_pads_act(
            self.ctx, ctypes.byref(x), nimg, Cin, H, W, in_pitch,
            ctypes.byref(wpanel), Cout, KH, KW, stride, pt, pl, pb, pr, dil,
            act, ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo),
            ctypes.byref(op)), "conv_nhwc_pads")
        return ho.value, wo.value, op.value

    def conv_nhwc_group(self, x, nimg, Cin, H, W, in_pitch, wpanels, Cout,
                        groups, KH, KW, stride, pad, dil, out,
                        act=ACT_NONE):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        op = ctypes.c_int(0)
        arr = (ctypes.POINTER(Buf) * len(wpanels))()
        for i, w in enumerate(wpanels):
            arr[i] = ctypes.pointer(w)
        self._check(self.lib.vc4_conv_nhwc_group_act(
            self.ctx, ctypes.byref(x), nimg, Cin, H, W, in_pitch, arr, Cout,
            groups, KH, KW, stride, pad, dil, act, ctypes.byref(out),
            ctypes.byref(ho), ctypes.byref(wo), ctypes.byref(op)),
            "conv_nhwc_group")
        return ho.value, wo.value, op.value

    def maxpool_nhwc(self, x, nimg, C, H, W, in_pitch, k, pad, out):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        op = ctypes.c_int(0)
        self._check(self.lib.vc4_maxpool_nhwc(
            self.ctx, ctypes.byref(x), nimg, C, H, W, in_pitch, k, pad,
            ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo),
            ctypes.byref(op)), "maxpool_nhwc")
        return ho.value, wo.value, op.value

    def upsample2x_nhwc(self, x, nimg, C, H, W, in_pitch, out):
        ho = ctypes.c_int(0)
        wo = ctypes.c_int(0)
        op = ctypes.c_int(0)
        self._check(self.lib.vc4_upsample2x_nhwc(
            self.ctx, ctypes.byref(x), nimg, C, H, W, in_pitch,
            ctypes.byref(out), ctypes.byref(ho), ctypes.byref(wo),
            ctypes.byref(op)), "upsample2x_nhwc")
        return ho.value, wo.value, op.value

    @property
    def stats(self):
        s = Stats()
        self.lib.vc4_get_stats(self.ctx, ctypes.byref(s))
        return s

    # ---- autotuning
    def autotune(self, op, shape, max_candidates=0, budget_ms=0, reps=0,
                 force=0):
        """Measure (or read) the launch parameters for one op and shape.

        ``op`` is a VC4_OP_* value, ``shape`` a TuneShape (or a 12-tuple of
        its fields).  Returns a dict with the chosen pack_q/gemm_q/im2col_q,
        the two medians, the correctness delta and the blob name.
        """
        sh = shape if isinstance(shape, TuneShape) else TuneShape(*shape)
        o = TuneOpts(int(max_candidates), int(budget_ms), int(reps),
                     int(force))
        r = TuneResult()
        self._check(self.lib.vc4_autotune(self.ctx, int(op),
                                          ctypes.byref(sh), ctypes.byref(o),
                                          ctypes.byref(r)), "autotune")
        return {
            "pack_q": int(r.params.pack_q),
            "gemm_q": int(r.params.gemm_q),
            "im2col_q": int(r.params.im2col_q),
            "best_ms": float(r.best_ms),
            "default_ms": float(r.default_ms),
            "max_abs": float(r.max_abs),
            "candidates": int(r.candidates),
            "over_tol": int(r.over_tol),
            "from_cache": bool(r.from_cache),
            "kernel": r.kernel.decode(),
        }

    def autotune_enabled(self):
        return bool(self.lib.vc4_autotune_enabled(self.ctx))

    # ---- registry
    def supported_ops(self):
        n = ctypes.c_size_t(0)
        t = self.lib.vc4_supported_ops(ctypes.byref(n))
        return [dict(name=t[i].name.decode(), backend=t[i].backend.decode(),
                     supported=bool(t[i].supported), note=t[i].note.decode())
                for i in range(n.value)]

    def print_supported_ops(self):
        self.lib.vc4_print_supported_ops(None if False else ctypes.c_void_p(
            ctypes.cast(sys.stdout, ctypes.c_void_p).value))


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--ops", action="store_true", help="print the op table")
    ap.add_argument("--bench", action="store_true", help="run a 256^3 matmul")
    args = ap.parse_args()
    eng = Engine()
    print("arena %.1f MiB" % (eng.arena_bytes / (1 << 20)))
    if args.ops or not args.bench:
        for o in eng.supported_ops():
            print("%-20s %-6s %-24s %s" % (o["name"],
                                           "yes" if o["supported"] else "NO",
                                           o["backend"], o["note"]))
    if args.bench:
        import time
        for n in (128, 256):
            a = eng.upload(np.random.rand(n, n).astype(np.float32) * 2 - 1)
            b = eng.upload(np.random.rand(n, n).astype(np.float32) * 2 - 1)
            c = eng.alloc(n * n * 4)
            eng.matmul(a, b, c, n, n, n)          # warm
            t0 = time.monotonic()
            reps = 5
            for _ in range(reps):
                eng.matmul(a, b, c, n, n, n)
            dt = (time.monotonic() - t0) / reps
            print("matmul %d^3: %.3f ms  %.2f GFLOP/s" %
                  (n, dt * 1e3, 2.0 * n ** 3 / dt / 1e9))
    eng.close()
